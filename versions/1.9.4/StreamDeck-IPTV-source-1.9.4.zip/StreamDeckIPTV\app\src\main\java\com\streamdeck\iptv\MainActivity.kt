package com.streamdeck.iptv

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.streamdeck.iptv.data.BackgroundRefreshScheduler
import com.streamdeck.iptv.ui.StreamDeckApp

class MainActivity : ComponentActivity() {
    private val viewModel: IptvViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        BackgroundRefreshScheduler.schedule(this)
        requestNotificationPermissionIfNeeded()
        enableEdgeToEdge()
        setContent {
            StreamDeckApp(viewModel)
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.resumePendingUpdateInstall()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return
        if (
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS,
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.POST_NOTIFICATIONS),
            NOTIFICATION_PERMISSION_REQUEST,
        )
    }

    private companion object {
        const val NOTIFICATION_PERMISSION_REQUEST = 42
    }
}

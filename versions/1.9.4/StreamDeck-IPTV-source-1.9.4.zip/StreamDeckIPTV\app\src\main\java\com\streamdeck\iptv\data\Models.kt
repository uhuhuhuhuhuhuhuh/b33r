package com.streamdeck.iptv.data

data class Credentials(val username: String, val password: String)

data class AccountInfo(
    val username: String,
    val expiresAtEpochSeconds: Long?,
) {
    val expired: Boolean
        get() = expiresAtEpochSeconds?.let { it <= currentEpochSeconds() } == true
}

data class StoredSession(
    val credentials: Credentials,
    val accountUsername: String,
    val expiresAtEpochSeconds: Long?,
) {
    val expired: Boolean
        get() = expiresAtEpochSeconds?.let { it <= currentEpochSeconds() } == true
}

data class Category(
    val id: String,
    val name: String,
)

enum class ContentKind { LIVE, MOVIE, SERIES, EPISODE }

data class StreamItem(
    val id: String,
    val name: String,
    val kind: ContentKind,
    val extension: String = "",
    val subtitle: String = "",
    val imageUrl: String = "",
    val directUrl: String = "",
)

enum class LibrarySection(val title: String) {
    LIVE("Live TV"),
    MOVIES("Movies"),
    SERIES("Series"),
}

open class XtreamException(message: String) : Exception(message)

class AccountExpiredException : XtreamException("Account expired.")

fun currentEpochSeconds(): Long = System.currentTimeMillis() / 1_000L

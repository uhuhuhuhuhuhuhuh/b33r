# The app uses platform JSON parsing and no reflection-based serializers.

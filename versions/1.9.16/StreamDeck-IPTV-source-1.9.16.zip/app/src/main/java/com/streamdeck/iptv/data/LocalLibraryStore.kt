package com.streamdeck.iptv.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class LocalLibraryStore(context: Context) {
    private val preferences = context.getSharedPreferences("local_library", Context.MODE_PRIVATE)

    fun favoriteItems(): List<StreamItem> =
        readItems(KEY_FAVORITES)

    fun favoriteKeys(): Set<String> =
        favoriteItems().map { it.localLibraryKey() }.toSet()

    fun toggleFavorite(item: StreamItem): Boolean {
        if (!item.canBeFavorited()) return false
        val items = favoriteItems().toMutableList()
        val key = item.localLibraryKey()
        val existingIndex = items.indexOfFirst { it.localLibraryKey() == key }
        val favorited = existingIndex == -1
        if (favorited) {
            items.add(0, item)
        } else {
            items.removeAt(existingIndex)
        }
        writeItems(KEY_FAVORITES, items)
        return favorited
    }

    fun resumeEntries(): List<ResumeEntry> =
        readResumeEntries().sortedByDescending { it.updatedAtEpochSeconds }

    fun resumePositionMs(item: StreamItem): Long =
        resumeEntries()
            .firstOrNull { it.item.localLibraryKey() == item.localLibraryKey() }
            ?.positionMs
            ?: 0L

    fun saveResumeProgress(item: StreamItem, positionMs: Long, durationMs: Long) {
        if (!item.canResume()) return
        val safePosition = positionMs.coerceAtLeast(0L)
        val safeDuration = durationMs.coerceAtLeast(0L)
        val key = item.localLibraryKey()
        val storedEntries = readResumeEntries()
        val existing = storedEntries.firstOrNull { it.item.localLibraryKey() == key }
        when (
            decideResumeProgressUpdate(
                existingPositionMs = existing?.positionMs,
                existingDurationMs = existing?.durationMs,
                positionMs = safePosition,
                durationMs = safeDuration,
            )
        ) {
            ResumeProgressUpdate.KEEP_EXISTING -> return
            ResumeProgressUpdate.REMOVE -> {
                writeResumeEntries(
                    storedEntries
                        .filterNot { it.item.localLibraryKey() == key }
                        .take(MAX_RESUME_ENTRIES),
                )
            }
            ResumeProgressUpdate.UPSERT -> {
                val entries = storedEntries
                    .filterNot { it.item.localLibraryKey() == key }
                    .toMutableList()
                entries.add(
                    0,
                    ResumeEntry(
                        item = item,
                        positionMs = safePosition,
                        durationMs = safeDuration,
                        updatedAtEpochSeconds = currentEpochSeconds(),
                    ),
                )
                writeResumeEntries(entries.take(MAX_RESUME_ENTRIES))
            }
        }
    }

    private fun readItems(key: String): List<StreamItem> {
        val array = readArray(key)
        return buildList {
            for (index in 0 until array.length()) {
                array.optJSONObject(index)?.toStreamItem()?.let { add(it) }
            }
        }
    }

    private fun writeItems(key: String, items: List<StreamItem>) {
        val array = JSONArray()
        items.forEach { array.put(it.toJson()) }
        preferences.edit().putString(key, array.toString()).apply()
    }

    private fun readResumeEntries(): List<ResumeEntry> {
        val array = readArray(KEY_RESUME)
        return buildList {
            for (index in 0 until array.length()) {
                val json = array.optJSONObject(index) ?: continue
                val item = json.optJSONObject("item")?.toStreamItem() ?: continue
                add(
                    ResumeEntry(
                        item = item,
                        positionMs = json.optLong("positionMs", 0L),
                        durationMs = json.optLong("durationMs", 0L),
                        updatedAtEpochSeconds = json.optLong("updatedAtEpochSeconds", 0L),
                    ),
                )
            }
        }
    }

    private fun writeResumeEntries(entries: List<ResumeEntry>) {
        val array = JSONArray()
        entries.forEach { entry ->
            array.put(
                JSONObject()
                    .put("item", entry.item.toJson())
                    .put("positionMs", entry.positionMs)
                    .put("durationMs", entry.durationMs)
                    .put("updatedAtEpochSeconds", entry.updatedAtEpochSeconds),
            )
        }
        preferences.edit().putString(KEY_RESUME, array.toString()).apply()
    }

    private fun readArray(key: String): JSONArray =
        runCatching { JSONArray(preferences.getString(key, "[]").orEmpty()) }
            .getOrDefault(JSONArray())

    private fun StreamItem.toJson(): JSONObject =
        JSONObject()
            .put("id", id)
            .put("name", name)
            .put("kind", kind.name)
            .put("extension", extension)
            .put("subtitle", subtitle)
            .put("imageUrl", imageUrl)
            .put("directUrl", directUrl)

    private fun JSONObject.toStreamItem(): StreamItem? {
        val id = optString("id")
        val name = optString("name")
        val kind = runCatching { ContentKind.valueOf(optString("kind")) }.getOrNull()
        if (id.isBlank() || name.isBlank() || kind == null) return null
        return StreamItem(
            id = id,
            name = name,
            kind = kind,
            extension = optString("extension"),
            subtitle = optString("subtitle"),
            imageUrl = optString("imageUrl"),
            directUrl = optString("directUrl"),
        )
    }

    private companion object {
        const val KEY_FAVORITES = "favorites"
        const val KEY_RESUME = "resume"
        const val MAX_RESUME_ENTRIES = 120
    }
}

internal enum class ResumeProgressUpdate {
    KEEP_EXISTING,
    REMOVE,
    UPSERT,
}

internal fun decideResumeProgressUpdate(
    existingPositionMs: Long?,
    existingDurationMs: Long?,
    positionMs: Long,
    durationMs: Long,
): ResumeProgressUpdate {
    val safePosition = positionMs.coerceAtLeast(0L)
    val safeDuration = durationMs.coerceAtLeast(0L)
    val finished = safeDuration > 0L &&
        safePosition >= MIN_RESUME_POSITION_MS &&
        safePosition >= (safeDuration - FINISHED_WINDOW_MS).coerceAtLeast(0L)

    return when {
        finished && existingPositionMs != null -> ResumeProgressUpdate.REMOVE
        finished -> ResumeProgressUpdate.KEEP_EXISTING
        safePosition < MIN_RESUME_POSITION_MS -> ResumeProgressUpdate.KEEP_EXISTING
        existingPositionMs == safePosition &&
            existingDurationMs?.coerceAtLeast(0L) == safeDuration ->
            ResumeProgressUpdate.KEEP_EXISTING
        else -> ResumeProgressUpdate.UPSERT
    }
}

private const val MIN_RESUME_POSITION_MS = 30_000L
private const val FINISHED_WINDOW_MS = 60_000L

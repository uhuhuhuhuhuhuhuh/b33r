package com.streamdeck.iptv.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AppColors = darkColorScheme(
    primary = Color(0xFFF2A900),
    onPrimary = Color(0xFF101010),
    secondary = Color(0xFFFFD36A),
    background = Color(0xFF0B0B0B),
    onBackground = Color(0xFFF5F5F5),
    surface = Color(0xFF171717),
    onSurface = Color(0xFFF5F5F5),
    surfaceVariant = Color(0xFF282828),
    onSurfaceVariant = Color(0xFFAAAAAA),
    outline = Color(0xFF3D3D3D),
    error = Color(0xFFFFB4AB),
)

@Composable
fun StreamDeckTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AppColors,
        content = content,
    )
}

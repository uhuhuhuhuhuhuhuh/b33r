package com.streamdeck.iptv.data

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AuthenticationFailureClassifierTest {
    @Test
    fun initialBadLoginIsNotReportedAsExpired() {
        assertFalse(
            shouldTreatAuthenticationFailureAsExpired(
                status = "",
                message = "Username or password is incorrect.",
                expiresAtEpochSeconds = null,
                nowEpochSeconds = 1_000L,
            ),
        )
    }

    @Test
    fun rejectedSavedSessionWithoutExpiryEvidenceIsNotReportedAsExpired() {
        assertFalse(
            shouldTreatAuthenticationFailureAsExpired(
                status = "Disabled",
                message = "Account disabled.",
                expiresAtEpochSeconds = null,
                nowEpochSeconds = 1_000L,
            ),
        )
    }

    @Test
    fun explicitExpiredStatusIsRecognizedOnInitialLogin() {
        assertTrue(
            shouldTreatAuthenticationFailureAsExpired(
                status = "Expired",
                message = "",
                expiresAtEpochSeconds = null,
                nowEpochSeconds = 1_000L,
            ),
        )
    }

    @Test
    fun expiredTimestampIsRecognizedOnInitialLogin() {
        assertTrue(
            shouldTreatAuthenticationFailureAsExpired(
                status = "Active",
                message = "",
                expiresAtEpochSeconds = 999L,
                nowEpochSeconds = 1_000L,
            ),
        )
    }
}

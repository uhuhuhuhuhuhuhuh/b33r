package com.streamdeck.iptv.ui

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResponsiveLayoutTest {
    @Test
    fun televisionScaleGrowsAcross720p1080pAnd4k() {
        val hd = calculateResponsiveScaleProfile(true, 540, 720)
        val fullHd = calculateResponsiveScaleProfile(true, 540, 1_080)
        val ultraHd = calculateResponsiveScaleProfile(true, 540, 2_160)

        assertTrue(hd.uiScale < fullHd.uiScale)
        assertTrue(fullHd.uiScale < ultraHd.uiScale)
        assertTrue(hd.textScale < fullHd.textScale)
        assertTrue(fullHd.textScale < ultraHd.textScale)
    }

    @Test
    fun phoneTabletAndLargeTabletUseDifferentScales() {
        val phone = calculateResponsiveScaleProfile(false, 384, 1_440)
        val tablet = calculateResponsiveScaleProfile(false, 700, 1_600)
        val largeTablet = calculateResponsiveScaleProfile(false, 900, 1_800)

        assertEquals(1.00f, phone.uiScale)
        assertEquals(1.08f, tablet.uiScale)
        assertEquals(1.14f, largeTablet.uiScale)
        assertTrue(phone.textScale < tablet.textScale)
        assertTrue(tablet.textScale < largeTablet.textScale)
    }

    @Test
    fun compactPhoneShrinksWithoutMakingTextTooSmall() {
        val compact = calculateResponsiveScaleProfile(false, 320, 720)

        assertEquals(0.92f, compact.uiScale)
        assertEquals(0.96f, compact.textScale)
    }

    @Test
    fun fourKModeDoesNotOverscaleA1080pAppWindow() {
        val compatibilityWindow = calculateResponsiveScaleProfile(
            isTelevision = true,
            shortestWidthDp = 540,
            physicalShortSidePx = 2_160,
            windowShortSidePx = 1_080,
        )
        val nativeFullHd = calculateResponsiveScaleProfile(
            isTelevision = true,
            shortestWidthDp = 540,
            physicalShortSidePx = 1_080,
            windowShortSidePx = 1_080,
        )

        assertEquals(nativeFullHd.uiScale, compatibilityWindow.uiScale)
        assertEquals(nativeFullHd.textScale, compatibilityWindow.textScale)
    }

    @Test
    fun navigationRailRequiresWidthHeightAndTabletOrTvFormFactor() {
        assertFalse(shouldUseNavigationRail(false, widthDp = 850f, heightDp = 390f))
        assertFalse(shouldUseNavigationRail(false, widthDp = 720f, heightDp = 520f))
        assertTrue(shouldUseNavigationRail(false, widthDp = 900f, heightDp = 700f))
        assertTrue(shouldUseNavigationRail(true, widthDp = 960f, heightDp = 540f))
    }

    @Test
    fun nativeControllerDensityUsesTheSameBoundedUiScale() {
        assertEquals(300, scaledDensityDpi(baseDensityDpi = 240, scale = 1.25f))
        assertEquals(204, scaledDensityDpi(baseDensityDpi = 240, scale = 0.50f))
        assertEquals(384, scaledDensityDpi(baseDensityDpi = 240, scale = 2.00f))
    }
}

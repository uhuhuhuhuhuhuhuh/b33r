package com.streamdeck.iptv.data

import org.junit.Assert.assertEquals
import org.junit.Test

class ResumeProgressUpdateTest {
    @Test
    fun zeroPositionDoesNotEraseExistingResumeEntry() {
        assertEquals(
            ResumeProgressUpdate.KEEP_EXISTING,
            decideResumeProgressUpdate(
                existingPositionMs = 1_800_000L,
                existingDurationMs = 3_600_000L,
                positionMs = 0L,
                durationMs = 3_600_000L,
            ),
        )
    }

    @Test
    fun startupSampleDoesNotEraseExistingResumeEntry() {
        assertEquals(
            ResumeProgressUpdate.KEEP_EXISTING,
            decideResumeProgressUpdate(
                existingPositionMs = 1_800_000L,
                existingDurationMs = 3_600_000L,
                positionMs = 12_000L,
                durationMs = 3_600_000L,
            ),
        )
    }

    @Test
    fun unchangedProgressDoesNotCauseAnotherWrite() {
        assertEquals(
            ResumeProgressUpdate.KEEP_EXISTING,
            decideResumeProgressUpdate(
                existingPositionMs = 1_800_000L,
                existingDurationMs = 3_600_000L,
                positionMs = 1_800_000L,
                durationMs = 3_600_000L,
            ),
        )
    }

    @Test
    fun meaningfulProgressIsStored() {
        assertEquals(
            ResumeProgressUpdate.UPSERT,
            decideResumeProgressUpdate(
                existingPositionMs = 1_800_000L,
                existingDurationMs = 3_600_000L,
                positionMs = 1_830_000L,
                durationMs = 3_600_000L,
            ),
        )
    }

    @Test
    fun progressNearEndRemovesExistingResumeEntry() {
        assertEquals(
            ResumeProgressUpdate.REMOVE,
            decideResumeProgressUpdate(
                existingPositionMs = 1_800_000L,
                existingDurationMs = 3_600_000L,
                positionMs = 3_550_000L,
                durationMs = 3_600_000L,
            ),
        )
    }

    @Test
    fun zeroPositionOnShortVideoIsNotTreatedAsFinished() {
        assertEquals(
            ResumeProgressUpdate.KEEP_EXISTING,
            decideResumeProgressUpdate(
                existingPositionMs = 35_000L,
                existingDurationMs = 45_000L,
                positionMs = 0L,
                durationMs = 45_000L,
            ),
        )
    }
}

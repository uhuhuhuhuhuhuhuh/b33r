package com.streamdeck.iptv.ui

import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SingleFlightGateTest {
    @Test
    fun repeatedStartsAllowOnlyOneTransition() {
        val gate = SingleFlightGate()

        assertTrue(gate.tryAcquire())
        repeat(100) {
            assertFalse(gate.tryAcquire())
        }
        gate.release()
        assertTrue(gate.tryAcquire())
    }

    @Test
    fun simultaneousCallbacksAllowOnlyOneTransition() {
        val gate = SingleFlightGate()
        val ready = CountDownLatch(32)
        val start = CountDownLatch(1)
        val winners = AtomicInteger(0)
        val executor = Executors.newFixedThreadPool(32)

        repeat(32) {
            executor.execute {
                ready.countDown()
                start.await()
                if (gate.tryAcquire()) winners.incrementAndGet()
            }
        }
        ready.await()
        start.countDown()
        executor.shutdown()
        while (!executor.isTerminated) {
            Thread.yield()
        }

        assertEquals(1, winners.get())
    }
}

# b33r IPTV

An adaptive Android IPTV player for phones, tablets, and Android TV. The app uses a
preconfigured Xtream Codes provider and intentionally never displays the provider
address in its interface.

## What it includes

- First-run screen containing username, password, and login only
- Xtream Codes authentication through `player_api.php`
- Credentials encrypted with AES-256-GCM and protected by Android Keystore
- Automatic sign-in on later launches
- Blank/`null` account expiration is treated as never expiring
- Expired accounts are denied login, catalog access, and playback inside the app
- Saved sessions keep the last known expiration so an expired account is explained clearly after Dispatcharr starts returning unauthorized responses
- Background account refresh checks whether the saved account has expired yet
- The visible account badge refreshes the username/expiration while the app is open and whenever the app resumes
- Live TV, Movies, and Series categories
- Local Favorites section for Live TV, Movies, and Series
- Continue Watching section for movies and series episodes
- Saved playback timestamps resume automatically when a Continue Watching item is opened
- Episode browsing for series
- Provider-supplied channel logos and movie/series/episode cover artwork
- b33r-themed dark taproom background with amber, cream, and hop-green accents
- Beer-mug/play launcher icon, Fire TV icon, and TV banner
- Polished login card, library header, account badge, search, category, and navigation styling
- Instant local search for live channels, movies, series, and episodes
- Search text remains intact when opening content and returning from playback
- HLS, DASH, SmoothStreaming, RTSP, RTMP, MPEG-TS, MP4, WebM, and Matroska playback support
- Decoder fallback, Compose surface synchronization, alternate TextureView rendering, and provider direct-source retry
- Embedded LibVLC engine with separate hardware and software decoding modes for streams Media3 cannot render
- Automatic player selection: VLC hardware, VLC software, alternate source, then Media3 fallbacks
- Playback launches and automatic fallbacks are single-flight so repeated remote presses or duplicate player errors cannot start overlapping native decoders
- Catalog, category, login, episode, account, and update requests cancel cleanly and ignore stale results
- Custom playback controls with selectable embedded audio and subtitle tracks
- Auto-hiding playback controls that return on touch or remote input
- LIVE status on channel playback controls
- 10-second rewind and 30-second forward controls for movies and episodes
- Visible buffering status with a larger network buffer for older Fire TV hardware
- Aspect-ratio-preserving fit-to-screen playback that never stretches or crops the picture
- Auto quality by default, plus 720p, 1080p, 1440p, 2160p, and maximum-quality choices
- Fire TV system keyboard opens only after pressing OK on login or search fields
- Fire TV update prompts auto-focus the update action so Update now and Later can be selected by remote
- Pressing Down from the library search field moves focus into the first visible result
- Fire TV directional keys leave the library search field instead of moving the text cursor
- Player controls expose Fire TV focus targets for live, movies, and episodes
- The complete UI—including Material text, dialogs, menus, controls, focus targets, spacing, and artwork grids—scales as one system
- Phone, tablet, Fire TV, and Android TV layouts use the active window, device type, and TV output resolution
- TV controls and poster grids have distinct 720p, 1080p, and 4K sizes while compact phones and tablets use their own profiles
- Library header shows the signed-in username and account expiration date
- Automatic update checks from the GitHub version manifest
- Background update checks with an update notification when Android allows notifications
- SHA-256 verified update downloads with Android installer handoff
- Handoff to another installed video player when an external playback engine is needed
- Media3/ExoPlayer playback for transport streams, HLS, DASH, and common VOD formats
- Responsive touch layout for phones such as the Galaxy S24 Ultra
- D-pad focus states, navigation rail, dedicated app icon and 320:180 TV banner, and Leanback launcher support
- Logout action that removes the saved encrypted session

## Requirements

- Android Studio with Android SDK 36.1
- JDK 17 or newer
- Internet access for the first Gradle dependency download
- Android 5.0 (API 21) or newer device
- ARM64 or ARMv7 processor (covers the Galaxy S24 Ultra and standard physical Android TV devices)

## Build

1. Open this folder in Android Studio and allow Gradle sync to finish.
2. Select **Build > Generate Signed Bundle / APK** or run the Gradle command below.
3. The release APK is written to:
   `app/build/outputs/apk/release/app-release.apk`

From a terminal on Windows:

```powershell
$env:ANDROID_HOME="$env:LOCALAPPDATA\Android\Sdk"
.\gradlew.bat assembleDebug
```

Release builds intentionally require an external signing key instead of silently
using Android's disposable debug key. Set these environment variables to the
retained key that signs published updates:

```powershell
$env:ANDROID_HOME="$env:LOCALAPPDATA\Android\Sdk"
$env:B33R_RELEASE_STORE_FILE="C:\secure\path\b33r-release.keystore"
$env:B33R_RELEASE_STORE_PASSWORD="<keystore password>"
$env:B33R_RELEASE_KEY_ALIAS="<key alias>"
$env:B33R_RELEASE_KEY_PASSWORD="<key password>"
.\gradlew.bat assembleRelease
```

Every update must use the same retained key as the installed APK. Do not commit
the keystore or its passwords to this source project.

## Install on a Galaxy S24 Ultra

Copy `StreamDeck-IPTV-1.9.10.apk` to the phone, open it in **My Files**, and allow
installation from that source when Android asks. Alternatively, with USB debugging
enabled:

```powershell
adb install -r StreamDeck-IPTV-1.9.10.apk
```

## Install on Android TV

Transfer the same APK to the TV and open it with a file manager, or enable network
debugging and run:

```powershell
adb connect TV_IP_ADDRESS
adb install -r StreamDeck-IPTV-1.9.10.apk
```

Playback-engine selection is automatic. If a source fails to produce video, the app
advances through its built-in decoding and source fallbacks without requiring a
player-selection prompt. Use the **Audio** and **Subtitles** buttons in the custom
player controls when a stream provides multiple embedded tracks.

The app checks
`https://raw.githubusercontent.com/uhuhuhuhuhuhuhuh/b33r/main/versions/latest.json`
on launch. When a newer `versionCode` is published, it offers to download the APK,
verifies its SHA-256 checksum and package identity, and opens Android's installer.
Future updates must be signed with the same signing key as the installed APK.
The same background refresh also checks the saved account status periodically. If
the provider reports that the account is expired, or the saved expiration time has
passed, the app removes the saved session and blocks playback until a valid login
is used.

## Security note

Credentials are encrypted at rest and excluded from Android backup/device transfer.
The configured provider uses plain HTTP, so credentials and video traffic are not
encrypted while crossing the network. This cannot be corrected by the app without an
HTTPS endpoint from the provider. Use only on a trusted network and with an account
you are authorized to access.

Only stream services and content for which you have permission should be used.

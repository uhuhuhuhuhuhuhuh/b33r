package com.streamdeck.iptv.data

import android.net.Uri
import com.streamdeck.iptv.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class XtreamApi {
    suspend fun authenticate(credentials: Credentials): AccountInfo {
        val response = requestObject(credentials)
        val userInfo = response.optJSONObject("user_info")
            ?: throw XtreamException("The provider returned an invalid login response.")
        val authenticated = userInfo.optInt("auth", 0) == 1
        val status = userInfo.optString("status")
        if (!authenticated || (status.isNotBlank() && !status.equals("Active", ignoreCase = true))) {
            throw XtreamException(userInfo.optString("message", "Username or password is incorrect."))
        }
        val account = AccountInfo(
            username = userInfo.optString("username").ifBlank { credentials.username },
            expiresAtEpochSeconds = parseExpiration(userInfo),
        )
        if (account.expired) throw AccountExpiredException()
        return account
    }

    suspend fun categories(
        credentials: Credentials,
        section: LibrarySection,
    ): List<Category> {
        val action = when (section) {
            LibrarySection.LIVE -> "get_live_categories"
            LibrarySection.MOVIES -> "get_vod_categories"
            LibrarySection.SERIES -> "get_series_categories"
            LibrarySection.FAVORITES,
            LibrarySection.RESUME -> throw XtreamException("This section is stored on this device.")
        }
        return requestArray(credentials, action = action).mapObjects { json ->
            Category(
                id = json.optString("category_id"),
                name = json.optString("category_name", "Untitled"),
            )
        }.filter { it.id.isNotBlank() }
    }

    suspend fun streams(
        credentials: Credentials,
        section: LibrarySection,
        categoryId: String?,
    ): List<StreamItem> {
        val action = when (section) {
            LibrarySection.LIVE -> "get_live_streams"
            LibrarySection.MOVIES -> "get_vod_streams"
            LibrarySection.SERIES -> "get_series"
            LibrarySection.FAVORITES,
            LibrarySection.RESUME -> throw XtreamException("This section is stored on this device.")
        }
        return requestArray(credentials, action, categoryId).mapObjects { json ->
            when (section) {
                LibrarySection.LIVE -> StreamItem(
                    id = json.optString("stream_id"),
                    name = json.optString("name", "Untitled channel"),
                    kind = ContentKind.LIVE,
                    extension = safeExtension(json.optString("container_extension", "ts"), "ts"),
                    subtitle = json.optString("epg_channel_id"),
                    imageUrl = json.optString("stream_icon"),
                    directUrl = json.optString("direct_source"),
                )
                LibrarySection.MOVIES -> StreamItem(
                    id = json.optString("stream_id"),
                    name = json.optString("name", "Untitled movie"),
                    kind = ContentKind.MOVIE,
                    extension = safeExtension(json.optString("container_extension", "mp4"), "mp4"),
                    subtitle = listOf(json.optString("year"), json.optString("rating"))
                        .filter { it.isNotBlank() && it != "0" }
                        .joinToString("  •  "),
                    imageUrl = json.optString("stream_icon"),
                    directUrl = json.optString("direct_source"),
                )
                LibrarySection.SERIES -> StreamItem(
                    id = json.optString("series_id"),
                    name = json.optString("name", "Untitled series"),
                    kind = ContentKind.SERIES,
                    subtitle = json.optString("releaseDate").ifBlank { json.optString("year") },
                    imageUrl = json.optString("cover"),
                )
                LibrarySection.FAVORITES,
                LibrarySection.RESUME -> throw XtreamException("This section is stored on this device.")
            }
        }.filter { it.id.isNotBlank() }
    }

    suspend fun episodes(credentials: Credentials, seriesId: String): List<StreamItem> {
        val response = requestObject(credentials, action = "get_series_info", seriesId = seriesId)
        val episodes = response.optJSONObject("episodes") ?: return emptyList()
        val seriesCover = response.optJSONObject("info")?.optString("cover").orEmpty()
        val results = mutableListOf<StreamItem>()
        episodes.keys().asSequence()
            .sortedWith(compareBy({ it.toIntOrNull() ?: Int.MAX_VALUE }, { it }))
            .forEach { season ->
                val seasonEpisodes = episodes.optJSONArray(season) ?: return@forEach
                for (index in 0 until seasonEpisodes.length()) {
                    val episode = seasonEpisodes.optJSONObject(index) ?: continue
                    val info = episode.optJSONObject("info")
                    val number = episode.optString("episode_num", "${index + 1}")
                    results += StreamItem(
                        id = episode.optString("id"),
                        name = episode.optString("title", "Episode $number"),
                        kind = ContentKind.EPISODE,
                        extension = safeExtension(
                            episode.optString(
                                "container_extension",
                                info?.optString("container_extension", "mp4") ?: "mp4",
                            ),
                            "mp4",
                        ),
                        subtitle = "Season $season  •  Episode $number",
                        imageUrl = info?.optString("movie_image").orEmpty().ifBlank { seriesCover },
                        directUrl = episode.optString("direct_source"),
                    )
                }
            }
        return results.filter { it.id.isNotBlank() }
    }

    fun playbackUrls(credentials: Credentials, item: StreamItem): List<String> {
        val directUrl = item.directUrl.trim()
        val validDirectUrl = if (
            directUrl.startsWith("https://", ignoreCase = true) ||
            directUrl.startsWith("http://", ignoreCase = true) ||
            directUrl.startsWith("rtsp://", ignoreCase = true) ||
            directUrl.startsWith("rtmp://", ignoreCase = true)
        ) {
            directUrl
        } else {
            null
        }

        val path = when (item.kind) {
            ContentKind.LIVE -> "live"
            ContentKind.MOVIE -> "movie"
            ContentKind.EPISODE -> "series"
            ContentKind.SERIES -> error("A series must be resolved to an episode before playback.")
        }
        val extension = safeExtension(item.extension, if (item.kind == ContentKind.LIVE) "ts" else "mp4")
        val canonicalUrl = "${BuildConfig.XTREAM_BASE_URL}/$path/" +
            "${Uri.encode(credentials.username)}/${Uri.encode(credentials.password)}/" +
            "${Uri.encode(item.id)}.$extension"
        return listOfNotNull(canonicalUrl, validDirectUrl).distinct()
    }

    fun playbackUrl(credentials: Credentials, item: StreamItem): String =
        playbackUrls(credentials, item).first()

    private suspend fun requestArray(
        credentials: Credentials,
        action: String,
        categoryId: String? = null,
    ): JSONArray = request(credentials, action, categoryId = categoryId).let {
        runCatching { JSONArray(it) }
            .getOrElse { throw XtreamException("The provider returned an invalid catalog response.") }
    }

    private suspend fun requestObject(
        credentials: Credentials,
        action: String? = null,
        seriesId: String? = null,
    ): JSONObject = request(credentials, action, seriesId = seriesId).let {
        runCatching { JSONObject(it) }
            .getOrElse { throw XtreamException("The provider returned an invalid response.") }
    }

    private suspend fun request(
        credentials: Credentials,
        action: String? = null,
        categoryId: String? = null,
        seriesId: String? = null,
    ): String = withContext(Dispatchers.IO) {
        val query = buildList {
            add("username=${encode(credentials.username)}")
            add("password=${encode(credentials.password)}")
            action?.let { add("action=${encode(it)}") }
            categoryId?.let { add("category_id=${encode(it)}") }
            seriesId?.let { add("series_id=${encode(it)}") }
        }.joinToString("&")
        val connection = (URL("${BuildConfig.XTREAM_BASE_URL}/player_api.php?$query")
            .openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15_000
            readTimeout = 30_000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "StreamDeckIPTV/1.0 Android")
        }
        try {
            val code = connection.responseCode
            val body = (if (code in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader()
                ?.use { it.readText() }
                .orEmpty()
            if (code !in 200..299) {
                throw providerError(code, body)
            }
            body
        } catch (error: XtreamException) {
            throw error
        } catch (_: Exception) {
            throw XtreamException("Unable to connect. Check the device network and try again.")
        } finally {
            connection.disconnect()
        }
    }

    private fun encode(value: String): String = URLEncoder.encode(value, Charsets.UTF_8.name())

    private fun safeExtension(value: String, fallback: String): String =
        value.lowercase().replace(Regex("[^a-z0-9]"), "").ifBlank { fallback }

    private fun parseExpiration(userInfo: JSONObject): Long? {
        if (!userInfo.has("exp_date") || userInfo.isNull("exp_date")) return null
        return when (val value = userInfo.opt("exp_date")) {
            is Number -> value.toLong()
            is String -> value.trim().takeUnless {
                it.isBlank() || it.equals("null", ignoreCase = true)
            }?.toLongOrNull()
            else -> null
        }?.takeIf { it > 0L }
    }

    private fun providerError(code: Int, body: String): XtreamException {
        val errorMessage = runCatching {
            JSONObject(body).optString("error")
        }.getOrDefault("")
        if (errorMessage.equals("Account expired", ignoreCase = true)) {
            return AccountExpiredException()
        }
        if (code == HttpURLConnection.HTTP_FORBIDDEN) {
            return XtreamException("Access was forbidden. The account may be expired.")
        }
        if (code == HttpURLConnection.HTTP_UNAUTHORIZED) {
            return XtreamException("Username or password is incorrect, or the account has expired.")
        }
        return XtreamException("Provider request failed (HTTP $code).")
    }

    private inline fun <T> JSONArray.mapObjects(transform: (JSONObject) -> T): List<T> =
        buildList {
            for (index in 0 until length()) {
                optJSONObject(index)?.let { add(transform(it)) }
            }
        }
}

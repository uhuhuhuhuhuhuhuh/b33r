package com.streamdeck.iptv

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.streamdeck.iptv.data.AccountExpiredException
import com.streamdeck.iptv.data.AppUpdate
import com.streamdeck.iptv.data.AppUpdateManager
import com.streamdeck.iptv.data.BackgroundStatusStore
import com.streamdeck.iptv.data.Category
import com.streamdeck.iptv.data.ContentKind
import com.streamdeck.iptv.data.CredentialStore
import com.streamdeck.iptv.data.Credentials
import com.streamdeck.iptv.data.LibrarySection
import com.streamdeck.iptv.data.LocalLibraryStore
import com.streamdeck.iptv.data.ResumeEntry
import com.streamdeck.iptv.data.StoredSession
import com.streamdeck.iptv.data.StreamItem
import com.streamdeck.iptv.data.XtreamApi
import com.streamdeck.iptv.data.canBeFavorited
import com.streamdeck.iptv.data.canResume
import com.streamdeck.iptv.data.currentEpochSeconds
import com.streamdeck.iptv.data.localLibraryKey
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class IptvUiState(
    val checkingSession: Boolean = true,
    val authenticated: Boolean = false,
    val loading: Boolean = false,
    val error: String? = null,
    val accountUsername: String = "",
    val accountExpiresAtEpochSeconds: Long? = null,
    val accountExpired: Boolean = false,
    val section: LibrarySection = LibrarySection.LIVE,
    val categories: List<Category> = emptyList(),
    val selectedCategoryId: String? = null,
    val items: List<StreamItem> = emptyList(),
    val favoriteItems: List<StreamItem> = emptyList(),
    val favoriteKeys: Set<String> = emptySet(),
    val resumeEntries: List<ResumeEntry> = emptyList(),
    val continueWatchingItems: List<StreamItem> = emptyList(),
    val seriesTitle: String? = null,
    val seriesId: String? = null,
    val episodes: List<StreamItem> = emptyList(),
    val searchQueries: Map<String, String> = emptyMap(),
    val playbackUrl: String? = null,
    val playbackSources: List<String> = emptyList(),
    val playbackTitle: String = "",
    val playbackKind: ContentKind? = null,
    val playbackItem: StreamItem? = null,
    val playbackStartPositionMs: Long = 0L,
    val availableUpdate: AppUpdate? = null,
    val updateDownloading: Boolean = false,
    val updateAwaitingPermission: Boolean = false,
    val updateError: String? = null,
    val updateDismissed: Boolean = false,
) {
    val searchKey: String
        get() = seriesId?.let { "episodes:$it" } ?: "section:${section.name}"

    val searchQuery: String
        get() = searchQueries[searchKey].orEmpty()
}

class IptvViewModel(application: Application) : AndroidViewModel(application) {
    private val api = XtreamApi()
    private val credentialStore = CredentialStore(application)
    private val localLibraryStore = LocalLibraryStore(application)
    private val updateManager = AppUpdateManager(application)
    private val backgroundStatusStore = BackgroundStatusStore(application)
    private var credentials: Credentials? = null
    private var catalogJob: Job? = null
    private var expirationJob: Job? = null
    private var accountRefreshJob: Job? = null

    var state by mutableStateOf(IptvUiState())
        private set

    init {
        refreshLocalLibraryState()
        backgroundStatusStore.loadAvailableUpdate()?.let { update ->
            state = state.copy(availableUpdate = update)
        }
        checkForUpdates()
        val savedSession = credentialStore.loadSession()
        if (savedSession == null) {
            val expiredNotice = backgroundStatusStore.loadExpiredAccountNotice()
            state = state.copy(
                checkingSession = false,
                error = expiredNotice?.let { "Account expired." },
            )
        } else if (savedSession.expired) {
            handleAccountExpired(savedSession.accountUsername, savedSession.expiresAtEpochSeconds)
        } else {
            credentials = savedSession.credentials
            state = state.copy(
                checkingSession = false,
                authenticated = true,
                accountUsername = savedSession.accountUsername,
                accountExpiresAtEpochSeconds = savedSession.expiresAtEpochSeconds,
            )
            scheduleExpiration(savedSession.expiresAtEpochSeconds)
            startAccountRefreshLoop()
            refreshAccountInfo(savedSession)
            loadSection(LibrarySection.LIVE)
        }
    }

    private fun refreshAccountInfo(session: StoredSession) {
        viewModelScope.launch {
            refreshAccountInfoOnce(session)
        }
    }

    private suspend fun refreshAccountInfoOnce(session: StoredSession) {
        runCatching { api.authenticate(session.credentials) }
            .onSuccess { account ->
                if (credentials == session.credentials) {
                    credentialStore.save(session.credentials, account)
                    backgroundStatusStore.clearExpiredAccountNotice()
                    state = state.copy(
                        accountUsername = account.username,
                        accountExpiresAtEpochSeconds = account.expiresAtEpochSeconds,
                    )
                    scheduleExpiration(account.expiresAtEpochSeconds)
                }
            }
            .onFailure { error ->
                if (error is AccountExpiredException || session.expired) {
                    handleAccountExpired(session.accountUsername, session.expiresAtEpochSeconds)
                }
            }
    }

    private fun checkForUpdates() {
        viewModelScope.launch {
            runCatching { updateManager.checkForUpdate() }
                .onSuccess { update ->
                    backgroundStatusStore.saveAvailableUpdate(update)
                    if (update != null) {
                        state = state.copy(
                            availableUpdate = update,
                            updateDismissed = false,
                            updateError = null,
                        )
                    }
                }
        }
    }

    fun installAvailableUpdate() {
        val update = state.availableUpdate ?: return
        if (state.updateDownloading) return
        viewModelScope.launch {
            state = state.copy(
                updateDownloading = true,
                updateAwaitingPermission = false,
                updateError = null,
            )
            runCatching { updateManager.downloadAndVerify(update) }
                .onSuccess { apk ->
                    val installerOpened = updateManager.openInstallerOrSettings(apk)
                    state = state.copy(
                        updateDownloading = false,
                        updateAwaitingPermission = !installerOpened,
                        updateDismissed = installerOpened,
                        updateError = if (installerOpened) {
                            null
                        } else {
                            "Allow b33r IPTV to install updates, then return to continue."
                        },
                    )
                }
                .onFailure { error ->
                    state = state.copy(
                        updateDownloading = false,
                        updateError = error.message ?: "The update could not be downloaded.",
                    )
                }
        }
    }

    fun resumePendingUpdateInstall() {
        if (!state.updateAwaitingPermission) return
        if (updateManager.resumePendingInstall()) {
            state = state.copy(
                updateAwaitingPermission = false,
                updateDismissed = true,
                updateError = null,
            )
        }
    }

    fun refreshVisibleAccountInfo() {
        val currentCredentials = credentials ?: return
        val session = credentialStore.loadSession()
        if (session == null) {
            backgroundStatusStore.loadExpiredAccountNotice()?.let { notice ->
                handleAccountExpired(notice.username, notice.expiresAtEpochSeconds)
            }
            return
        }
        if (session.credentials != currentCredentials) return
        if (session.expired) {
            refreshAccountInfo(session)
            return
        }
        state = state.copy(
            accountUsername = session.accountUsername,
            accountExpiresAtEpochSeconds = session.expiresAtEpochSeconds,
            accountExpired = false,
        )
        scheduleExpiration(session.expiresAtEpochSeconds)
        refreshAccountInfo(session)
    }

    fun dismissUpdate() {
        if (!state.updateDownloading) {
            state = state.copy(updateDismissed = true)
        }
    }

    fun login(username: String, password: String) {
        if (username.isBlank() || password.isBlank()) {
            state = state.copy(error = "Enter both username and password.")
            return
        }
        viewModelScope.launch {
            state = state.copy(loading = true, error = null)
            val candidate = Credentials(username.trim(), password)
            runCatching { api.authenticate(candidate) }
                .onSuccess { account ->
                    credentialStore.save(candidate, account)
                    backgroundStatusStore.clearExpiredAccountNotice()
                    credentials = candidate
                    state = state.copy(
                        authenticated = true,
                        loading = false,
                        accountUsername = account.username,
                        accountExpiresAtEpochSeconds = account.expiresAtEpochSeconds,
                        accountExpired = false,
                    )
                    scheduleExpiration(account.expiresAtEpochSeconds)
                    startAccountRefreshLoop()
                    loadSection(LibrarySection.LIVE)
                }
                .onFailure { error ->
                    state = state.copy(
                        loading = false,
                        error = error.message ?: "Login failed.",
                    )
                }
        }
    }

    fun logout() {
        catalogJob?.cancel()
        expirationJob?.cancel()
        accountRefreshJob?.cancel()
        credentialStore.clear()
        backgroundStatusStore.clearExpiredAccountNotice()
        credentials = null
        state = IptvUiState(checkingSession = false)
        refreshLocalLibraryState()
    }

    fun loadSection(section: LibrarySection) {
        if (section == LibrarySection.FAVORITES || section == LibrarySection.RESUME) {
            catalogJob?.cancel()
            refreshLocalLibraryState()
            state = state.copy(
                section = section,
                loading = false,
                error = null,
                categories = emptyList(),
                selectedCategoryId = null,
                items = localItems(section),
                seriesTitle = null,
                seriesId = null,
                episodes = emptyList(),
            )
            return
        }
        val session = usableCredentials() ?: return
        catalogJob?.cancel()
        catalogJob = viewModelScope.launch {
            state = state.copy(
                section = section,
                loading = true,
                error = null,
                categories = emptyList(),
                selectedCategoryId = null,
                items = emptyList(),
                seriesTitle = null,
                seriesId = null,
                episodes = emptyList(),
            )
            runCatching {
                val categories = api.categories(session, section)
                val streams = api.streams(session, section, null)
                categories to streams
            }.onSuccess { (categories, streams) ->
                state = state.copy(
                    loading = false,
                    categories = categories,
                    items = streams,
                )
            }.onFailure { error ->
                if (error is AccountExpiredException) {
                    handleAccountExpired(state.accountUsername, state.accountExpiresAtEpochSeconds)
                    return@onFailure
                }
                state = state.copy(
                    loading = false,
                    error = error.message ?: "Unable to load the catalog.",
                )
            }
        }
    }

    fun selectCategory(categoryId: String?) {
        if (categoryId == state.selectedCategoryId) return
        if (state.section == LibrarySection.FAVORITES || state.section == LibrarySection.RESUME) return
        val session = usableCredentials() ?: return
        catalogJob?.cancel()
        catalogJob = viewModelScope.launch {
            state = state.copy(
                selectedCategoryId = categoryId,
                loading = true,
                error = null,
                items = emptyList(),
            )
            runCatching { api.streams(session, state.section, categoryId) }
                .onSuccess { streams ->
                    state = state.copy(loading = false, items = streams)
                }
                .onFailure { error ->
                    if (error is AccountExpiredException) {
                        handleAccountExpired(state.accountUsername, state.accountExpiresAtEpochSeconds)
                        return@onFailure
                    }
                    state = state.copy(
                        loading = false,
                        error = error.message ?: "Unable to load this category.",
                    )
                }
        }
    }

    fun open(item: StreamItem) {
        val session = usableCredentials() ?: return
        val itemToOpen = originalResumeItem(item)
        if (itemToOpen.kind == ContentKind.SERIES) {
            viewModelScope.launch {
                state = state.copy(loading = true, error = null)
                runCatching { api.episodes(session, itemToOpen.id) }
                    .onSuccess { episodes ->
                        state = state.copy(
                            loading = false,
                            seriesTitle = itemToOpen.name,
                            seriesId = itemToOpen.id,
                            episodes = episodes,
                            error = if (episodes.isEmpty()) "No episodes were returned for this series." else null,
                        )
                    }
                    .onFailure { error ->
                        if (error is AccountExpiredException) {
                            handleAccountExpired(state.accountUsername, state.accountExpiresAtEpochSeconds)
                            return@onFailure
                        }
                        state = state.copy(
                            loading = false,
                            error = error.message ?: "Unable to load episodes.",
                        )
                    }
            }
        } else {
            val playbackSources = api.playbackUrls(session, itemToOpen)
            state = state.copy(
                playbackUrl = playbackSources.first(),
                playbackSources = playbackSources,
                playbackTitle = itemToOpen.name,
                playbackKind = itemToOpen.kind,
                playbackItem = itemToOpen,
                playbackStartPositionMs = if (itemToOpen.canResume()) {
                    localLibraryStore.resumePositionMs(itemToOpen)
                } else {
                    0L
                },
                error = null,
            )
        }
    }

    fun closeSeries() {
        state = state.copy(
            seriesTitle = null,
            seriesId = null,
            episodes = emptyList(),
            error = null,
        )
    }

    fun updateSearchQuery(query: String) {
        state = state.copy(
            searchQueries = state.searchQueries + (state.searchKey to query),
        )
    }

    fun toggleFavorite(item: StreamItem) {
        if (!item.canBeFavorited()) return
        localLibraryStore.toggleFavorite(item)
        refreshLocalLibraryState()
    }

    fun savePlaybackProgress(positionMs: Long, durationMs: Long) {
        val item = state.playbackItem ?: return
        if (!item.canResume()) return
        localLibraryStore.saveResumeProgress(item, positionMs, durationMs)
    }

    fun closePlayer() {
        state = state.copy(
            playbackUrl = null,
            playbackSources = emptyList(),
            playbackTitle = "",
            playbackKind = null,
            playbackItem = null,
            playbackStartPositionMs = 0L,
        )
        refreshLocalLibraryState()
    }

    fun clearError() {
        state = state.copy(error = null)
    }

    private fun refreshLocalLibraryState() {
        val favorites = localLibraryStore.favoriteItems()
        val resumeEntries = localLibraryStore.resumeEntries()
        val continueWatchingItems = resumeEntries.map { it.toContinueWatchingItem() }
        state = state.copy(
            favoriteItems = favorites,
            favoriteKeys = favorites.map { it.localLibraryKey() }.toSet(),
            resumeEntries = resumeEntries,
            continueWatchingItems = continueWatchingItems,
            items = when {
                state.seriesTitle != null -> state.items
                state.section == LibrarySection.FAVORITES -> favorites
                state.section == LibrarySection.RESUME -> continueWatchingItems
                else -> state.items
            },
        )
    }

    private fun localItems(section: LibrarySection): List<StreamItem> =
        when (section) {
            LibrarySection.FAVORITES -> state.favoriteItems
            LibrarySection.RESUME -> state.continueWatchingItems
            else -> emptyList()
        }

    private fun originalResumeItem(item: StreamItem): StreamItem =
        state.resumeEntries
            .firstOrNull { it.item.localLibraryKey() == item.localLibraryKey() }
            ?.item
            ?: item

    private fun ResumeEntry.toContinueWatchingItem(): StreamItem {
        val parts = buildList {
            if (item.subtitle.isNotBlank()) add(item.subtitle)
            add("Left off at ${formatPlaybackTimestamp(positionMs)}")
            if (durationMs > 0L) add("of ${formatPlaybackTimestamp(durationMs)}")
        }
        return item.copy(subtitle = parts.joinToString("  •  "))
    }

    private fun formatPlaybackTimestamp(milliseconds: Long): String {
        if (milliseconds <= 0L) return "0:00"
        val totalSeconds = milliseconds / 1_000L
        val hours = totalSeconds / 3_600L
        val minutes = (totalSeconds % 3_600L) / 60L
        val seconds = totalSeconds % 60L
        return if (hours > 0L) {
            "%d:%02d:%02d".format(hours, minutes, seconds)
        } else {
            "%d:%02d".format(minutes, seconds)
        }
    }

    private fun usableCredentials(): Credentials? {
        val session = credentials ?: return null
        if (isExpired(state.accountExpiresAtEpochSeconds)) {
            handleAccountExpired(state.accountUsername.ifBlank { session.username }, state.accountExpiresAtEpochSeconds)
            return null
        }
        return session
    }

    private fun scheduleExpiration(expiresAtEpochSeconds: Long?) {
        expirationJob?.cancel()
        if (expiresAtEpochSeconds == null) return
        val delayMillis = ((expiresAtEpochSeconds - currentEpochSeconds()) * 1_000L).coerceAtLeast(0L)
        expirationJob = viewModelScope.launch {
            delay(delayMillis + 1_000L)
            credentialStore.loadSession()?.let { session ->
                if (credentials == session.credentials) {
                    refreshAccountInfoOnce(session)
                }
            }
            if (isExpired(state.accountExpiresAtEpochSeconds)) {
                handleAccountExpired(state.accountUsername, state.accountExpiresAtEpochSeconds)
            }
        }
    }

    private fun startAccountRefreshLoop() {
        accountRefreshJob?.cancel()
        accountRefreshJob = viewModelScope.launch {
            while (true) {
                delay(ACCOUNT_REFRESH_INTERVAL_MS)
                val session = credentialStore.loadSession() ?: continue
                if (credentials == session.credentials) {
                    refreshAccountInfoOnce(session)
                }
            }
        }
    }

    private fun handleAccountExpired(username: String, expiresAtEpochSeconds: Long?) {
        catalogJob?.cancel()
        expirationJob?.cancel()
        accountRefreshJob?.cancel()
        credentialStore.clear()
        backgroundStatusStore.saveAccountExpired(username, expiresAtEpochSeconds)
        credentials = null
        state = IptvUiState(
            checkingSession = false,
            error = "Account expired.",
            accountUsername = username,
            accountExpiresAtEpochSeconds = expiresAtEpochSeconds,
            accountExpired = true,
        )
        refreshLocalLibraryState()
    }

    private fun isExpired(expiresAtEpochSeconds: Long?): Boolean =
        expiresAtEpochSeconds?.let { it <= currentEpochSeconds() } == true

    private companion object {
        const val ACCOUNT_REFRESH_INTERVAL_MS = 5 * 60 * 1_000L
    }
}

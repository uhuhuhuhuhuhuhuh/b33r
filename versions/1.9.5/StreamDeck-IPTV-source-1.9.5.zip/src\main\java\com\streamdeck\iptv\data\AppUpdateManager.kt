package com.streamdeck.iptv.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import com.streamdeck.iptv.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URI
import java.security.MessageDigest

data class AppUpdate(
    val versionCode: Int,
    val versionName: String,
    val apkUrl: String,
    val sha256: String,
    val sizeBytes: Long,
    val releaseDate: String,
    val notes: List<String>,
) {
    fun toJson(): JSONObject = JSONObject()
        .put("versionCode", versionCode)
        .put("versionName", versionName)
        .put("apkUrl", apkUrl)
        .put("sha256", sha256)
        .put("sizeBytes", sizeBytes)
        .put("releaseDate", releaseDate)
        .put("notes", notes)

    companion object {
        fun fromJson(document: JSONObject): AppUpdate = AppUpdate(
            versionCode = document.getInt("versionCode"),
            versionName = document.getString("versionName"),
            apkUrl = document.getString("apkUrl"),
            sha256 = document.getString("sha256").lowercase(),
            sizeBytes = document.optLong("sizeBytes", -1L),
            releaseDate = document.optString("releaseDate"),
            notes = document.optJSONArray("notes")?.let { array ->
                buildList {
                    for (index in 0 until array.length()) {
                        add(array.getString(index))
                    }
                }
            }.orEmpty(),
        )
    }
}

class AppUpdateManager(private val context: Context) {
    private var pendingApk: File? = null

    suspend fun checkForUpdate(): AppUpdate? = withContext(Dispatchers.IO) {
        val cacheBuster = if ("?" in BuildConfig.UPDATE_MANIFEST_URL) "&" else "?"
        val manifestUrl =
            "${BuildConfig.UPDATE_MANIFEST_URL}${cacheBuster}installed=${BuildConfig.VERSION_CODE}"
        val json = getText(manifestUrl)
        val update = AppUpdate.fromJson(JSONObject(json))
        validateUpdate(update)
        update.takeIf { it.versionCode > BuildConfig.VERSION_CODE }
    }

    suspend fun downloadAndVerify(update: AppUpdate): File = withContext(Dispatchers.IO) {
        validateUpdate(update)
        val updateDirectory = File(context.cacheDir, "updates").apply { mkdirs() }
        val finalFile = File(updateDirectory, "StreamDeck-IPTV-${update.versionName}.apk")
        if (finalFile.isFile && sha256(finalFile) == update.sha256) {
            validateApk(finalFile, update)
            pendingApk = finalFile
            return@withContext finalFile
        }

        val temporaryFile = File(updateDirectory, "${finalFile.name}.download")
        temporaryFile.delete()
        val connection = openConnection(update.apkUrl)
        try {
            val expectedLength = connection.contentLength.toLong()
            FileOutputStream(temporaryFile).use { output ->
                connection.inputStream.use { input -> input.copyTo(output) }
            }
            if (update.sizeBytes > 0 && temporaryFile.length() != update.sizeBytes) {
                error("The downloaded update has an unexpected file size.")
            }
            if (expectedLength > 0 && temporaryFile.length() != expectedLength) {
                error("The update download was incomplete.")
            }
            if (sha256(temporaryFile) != update.sha256) {
                error("The update failed its security checksum.")
            }
            validateApk(temporaryFile, update)
            finalFile.delete()
            if (!temporaryFile.renameTo(finalFile)) {
                error("The verified update could not be prepared for installation.")
            }
            pendingApk = finalFile
            finalFile
        } catch (error: Throwable) {
            temporaryFile.delete()
            throw error
        } finally {
            connection.disconnect()
        }
    }

    fun openInstallerOrSettings(apk: File): Boolean {
        pendingApk = apk
        if (
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            !context.packageManager.canRequestPackageInstalls()
        ) {
            val permissionIntent = Intent(
                Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.parse("package:${context.packageName}"),
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(permissionIntent)
            return false
        }
        openInstaller(apk)
        return true
    }

    fun resumePendingInstall(): Boolean {
        val apk = pendingApk?.takeIf(File::isFile) ?: return false
        if (
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            !context.packageManager.canRequestPackageInstalls()
        ) {
            return false
        }
        openInstaller(apk)
        return true
    }

    private fun openInstaller(apk: File) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.updates",
            apk,
        )
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(intent)
        pendingApk = null
    }

    private fun validateUpdate(update: AppUpdate) {
        require(update.versionCode > 0) { "The update manifest has an invalid version code." }
        require(update.versionName.isNotBlank()) { "The update manifest has no version name." }
        require(update.sha256.matches(Regex("[a-f0-9]{64}"))) {
            "The update manifest has an invalid checksum."
        }
        val uri = URI(update.apkUrl)
        require(uri.scheme.equals("https", ignoreCase = true)) {
            "Updates must use a secure HTTPS address."
        }
        require(
            uri.host.equals("github.com", ignoreCase = true) ||
                uri.host.equals("download.b33r.top", ignoreCase = true),
        ) {
            "The update points to an untrusted download host."
        }
    }

    @Suppress("DEPRECATION")
    private fun validateApk(file: File, update: AppUpdate) {
        val packageInfo = context.packageManager.getPackageArchiveInfo(file.absolutePath, 0)
            ?: error("The downloaded update is not a valid Android package.")
        require(packageInfo.packageName == context.packageName) {
            "The downloaded update belongs to a different app."
        }
        val versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            packageInfo.longVersionCode
        } else {
            packageInfo.versionCode.toLong()
        }
        require(versionCode == update.versionCode.toLong()) {
            "The downloaded APK version does not match the update manifest."
        }
    }

    private fun getText(url: String): String {
        val connection = openConnection(url)
        return try {
            connection.inputStream.bufferedReader().use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }

    private fun openConnection(url: String): HttpURLConnection =
        (URI(url).toURL().openConnection() as HttpURLConnection).apply {
            connectTimeout = 10_000
            readTimeout = 30_000
            instanceFollowRedirects = true
            useCaches = false
            setRequestProperty("Accept", "application/json, application/vnd.android.package-archive")
            setRequestProperty("Cache-Control", "no-cache")
            setRequestProperty("User-Agent", "StreamDeck-IPTV/${BuildConfig.VERSION_NAME}")
            connect()
            if (responseCode !in 200..299) {
                val code = responseCode
                disconnect()
                error("Update server returned HTTP $code.")
            }
        }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}

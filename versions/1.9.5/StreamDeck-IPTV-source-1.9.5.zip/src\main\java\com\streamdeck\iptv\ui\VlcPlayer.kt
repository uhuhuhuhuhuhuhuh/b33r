package com.streamdeck.iptv.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.view.SurfaceView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Forward30
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.streamdeck.iptv.data.ContentKind
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer as VlcMediaPlayer
import kotlinx.coroutines.delay
import kotlin.math.max

private data class VlcTrackChoice(
    val id: Int,
    val name: String,
)

@Composable
internal fun VlcPlayerScreen(
    sources: List<String>,
    title: String,
    contentKind: ContentKind,
    startPositionMs: Long,
    onProgress: (Long, Long) -> Unit,
    onBack: () -> Unit,
    onUseMedia3: () -> Unit,
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var sourceIndex by remember(sources) { mutableIntStateOf(0) }
    var isPlaying by remember { mutableStateOf(false) }
    var currentTime by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var isScrubbing by remember { mutableStateOf(false) }
    var scrubFraction by remember { mutableFloatStateOf(0f) }
    var playbackError by remember { mutableStateOf<String?>(null) }
    var softwareDecode by remember { mutableStateOf(false) }
    var videoOutputCount by remember { mutableIntStateOf(0) }
    var audioTracks by remember { mutableStateOf(emptyList<VlcTrackChoice>()) }
    var subtitleTracks by remember {
        mutableStateOf(listOf(VlcTrackChoice(-1, "Off")))
    }
    var selectedAudioTrack by remember { mutableIntStateOf(-1) }
    var selectedSubtitleTrack by remember { mutableIntStateOf(-1) }
    var controlsVisible by remember { mutableStateOf(true) }
    var controlActivity by remember { mutableIntStateOf(0) }
    var isBuffering by remember { mutableStateOf(true) }
    var selectedQuality by remember { mutableIntStateOf(QUALITY_AUTO) }
    var resumeAfterQualityChange by remember { mutableLongStateOf(0L) }
    val controlFocusRequester = remember { FocusRequester() }
    val isLive = contentKind == ContentKind.LIVE
    val activeUrl = sources[sourceIndex.coerceIn(sources.indices)]
    var initialSeekApplied by remember(activeUrl, softwareDecode, selectedQuality, startPositionMs) {
        mutableStateOf(false)
    }
    val qualityChoices = remember {
        listOf(
            VlcTrackChoice(QUALITY_AUTO, "Auto"),
            VlcTrackChoice(720, "720p"),
            VlcTrackChoice(1_080, "1080p"),
            VlcTrackChoice(1_440, "1440p"),
            VlcTrackChoice(2_160, "2160p"),
            VlcTrackChoice(QUALITY_MAX, "Max"),
        )
    }

    val libVlc = remember {
        LibVLC(
            context,
            arrayListOf(
                "--network-caching=8000",
                "--live-caching=8000",
                "--http-reconnect",
                "--no-drop-late-frames",
                "--no-skip-frames",
            ),
        )
    }
    val mediaPlayer = remember(libVlc) { VlcMediaPlayer(libVlc) }

    fun refreshTrackChoices() {
        audioTracks = runCatching {
            mediaPlayer.audioTracks
                .orEmpty()
                .filter { it.id >= 0 }
                .map { VlcTrackChoice(it.id, it.name.ifBlank { "Audio ${it.id}" }) }
        }.getOrDefault(emptyList())
        subtitleTracks = listOf(VlcTrackChoice(-1, "Off")) + runCatching {
            mediaPlayer.spuTracks
                .orEmpty()
                .filter { it.id >= 0 }
                .map { VlcTrackChoice(it.id, it.name.ifBlank { "Subtitle ${it.id}" }) }
        }.getOrDefault(emptyList())
        selectedAudioTrack = runCatching { mediaPlayer.audioTrack }.getOrDefault(-1)
        selectedSubtitleTrack = runCatching { mediaPlayer.spuTrack }.getOrDefault(-1)
    }

    fun advanceAutomaticFallback(reason: String) {
        playbackError = reason
        when {
            !softwareDecode -> softwareDecode = true
            sourceIndex < sources.lastIndex -> {
                sourceIndex += 1
                softwareDecode = false
            }
            else -> onUseMedia3()
        }
    }

    fun showControls() {
        controlsVisible = true
        controlActivity += 1
    }

    DisposableEffect(libVlc, mediaPlayer) {
        onDispose {
            runCatching { mediaPlayer.stop() }
            runCatching { mediaPlayer.vlcVout.detachViews() }
            mediaPlayer.release()
            libVlc.release()
        }
    }

    DisposableEffect(mediaPlayer, activeUrl, softwareDecode, selectedQuality, lifecycleOwner) {
        val listener = VlcMediaPlayer.EventListener { event ->
            when (event.type) {
	                VlcMediaPlayer.Event.Playing -> {
	                    isPlaying = true
	                    isBuffering = false
	                    playbackError = null
	                    if (!isLive && resumeAfterQualityChange > 0L) {
	                        mediaPlayer.time = resumeAfterQualityChange
	                        resumeAfterQualityChange = 0L
	                        initialSeekApplied = true
	                    } else if (!isLive && !initialSeekApplied && startPositionMs > 0L) {
	                        mediaPlayer.time = startPositionMs
	                        currentTime = startPositionMs
	                        initialSeekApplied = true
	                    }
	                    refreshTrackChoices()
	                }
                VlcMediaPlayer.Event.Buffering -> isBuffering = event.buffering < 100f
                VlcMediaPlayer.Event.Paused,
                VlcMediaPlayer.Event.Stopped,
                VlcMediaPlayer.Event.EndReached -> {
                    isPlaying = false
                    isBuffering = false
                }
                VlcMediaPlayer.Event.TimeChanged -> if (!isScrubbing) {
                    currentTime = max(0L, event.timeChanged)
                }
                VlcMediaPlayer.Event.LengthChanged -> duration = max(0L, event.lengthChanged)
                VlcMediaPlayer.Event.Vout -> videoOutputCount = event.voutCount
                VlcMediaPlayer.Event.ESAdded,
                VlcMediaPlayer.Event.ESDeleted,
                VlcMediaPlayer.Event.ESSelected -> refreshTrackChoices()
                VlcMediaPlayer.Event.EncounteredError -> {
                    isBuffering = false
                    advanceAutomaticFallback("Playback failed; selecting the next built-in fallback.")
                }
            }
        }
        mediaPlayer.setEventListener(listener)
        val lifecycleObserver = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> if (!mediaPlayer.isPlaying) mediaPlayer.play()
                Lifecycle.Event.ON_STOP -> if (mediaPlayer.isPlaying) mediaPlayer.pause()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(lifecycleObserver)

        currentTime = 0L
        duration = 0L
        isBuffering = true
        videoOutputCount = 0
        audioTracks = emptyList()
        subtitleTracks = listOf(VlcTrackChoice(-1, "Off"))
        selectedAudioTrack = -1
        selectedSubtitleTrack = -1
        val media = Media(libVlc, Uri.parse(activeUrl)).apply {
            setHWDecoderEnabled(!softwareDecode, false)
            addOption(":network-caching=8000")
            addOption(":live-caching=8000")
            addOption(":http-reconnect")
            addOption(
                if (selectedQuality == QUALITY_MAX) {
                    ":adaptive-logic=highest"
                } else {
                    ":adaptive-logic=rate"
                },
            )
            if (selectedQuality > 0 && selectedQuality != QUALITY_MAX) {
                addOption(":adaptive-maxheight=$selectedQuality")
            }
        }
        mediaPlayer.media = media
        media.release()
        mediaPlayer.aspectRatio = null
        mediaPlayer.scale = 0f
        mediaPlayer.play()

	        onDispose {
	            lifecycleOwner.lifecycle.removeObserver(lifecycleObserver)
	            mediaPlayer.setEventListener(null)
	            if (!isLive) {
	                onProgress(mediaPlayer.time.coerceAtLeast(0L), duration.coerceAtLeast(0L))
	            }
	            runCatching { mediaPlayer.stop() }
	        }
	    }

	    LaunchedEffect(mediaPlayer, activeUrl, contentKind) {
	        while (true) {
	            delay(5_000)
	            if (!isLive && mediaPlayer.time > 0L) {
	                onProgress(mediaPlayer.time, duration.coerceAtLeast(0L))
	            }
	        }
	    }

	    LaunchedEffect(activeUrl, softwareDecode, selectedQuality) {
	        delay(12_000)
        if (videoOutputCount == 0) {
            advanceAutomaticFallback("No video output detected; selecting the next built-in fallback.")
        }
    }

    LaunchedEffect(Unit) {
        controlFocusRequester.requestFocus()
    }

    LaunchedEffect(controlsVisible) {
        if (!controlsVisible) {
            controlFocusRequester.requestFocus()
        }
    }

    LaunchedEffect(controlActivity, controlsVisible, isPlaying) {
        if (controlsVisible && isPlaying) {
            delay(5_000)
            controlsVisible = false
        }
    }

    fun openInAnotherPlayer() {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse(activeUrl), "video/*")
            putExtra(Intent.EXTRA_TITLE, title)
        }
        try {
            context.startActivity(Intent.createChooser(intent, "Open with video player"))
        } catch (_: ActivityNotFoundException) {
            playbackError = "No other compatible video player is installed."
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .onPreviewKeyEvent { event ->
                if (event.type == KeyEventType.KeyDown) {
                    val consumeToReveal = !controlsVisible
                    showControls()
                    consumeToReveal
                } else {
                    false
                }
            }
            .focusRequester(controlFocusRequester)
            .focusable(),
    ) {
        AndroidView(
            factory = { viewContext ->
                SurfaceView(viewContext).also { surface ->
                    surface.keepScreenOn = true
                    surface.addOnLayoutChangeListener { _, left, top, right, bottom, _, _, _, _ ->
                        val width = right - left
                        val height = bottom - top
                        if (width > 0 && height > 0) {
                            mediaPlayer.vlcVout.setWindowSize(width, height)
                        }
                    }
                    mediaPlayer.vlcVout.setVideoView(surface)
                    mediaPlayer.vlcVout.attachViews()
                }
            },
            modifier = Modifier.fillMaxSize(),
        )

        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures(onTap = { showControls() })
                },
        )

        if (isBuffering) {
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .background(Color(0xCC111111), RoundedCornerShape(12.dp))
                    .padding(horizontal = 22.dp, vertical = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                Text(
                    text = "Buffering…",
                    color = Color.White,
                    style = MaterialTheme.typography.labelLarge,
                )
            }
        }

        if (controlsVisible) Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(WindowInsets.safeDrawing.asPaddingValues())
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = Color.White,
                )
            }
            Column(Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = buildString {
                        if (isLive) append("LIVE • ")
                        append(if (softwareDecode) "VLC SOFTWARE" else "VLC HARDWARE")
                    },
                    color = MaterialTheme.colorScheme.primary,
                    style = MaterialTheme.typography.labelSmall,
                )
            }
            if (sources.size > 1) {
                Text(
                    text = "SOURCE ${sourceIndex + 1}/${sources.size}",
                    color = Color.White,
                    style = MaterialTheme.typography.labelSmall,
                )
            }
            TextButton(
                onClick = {
                    showControls()
                    openInAnotherPlayer()
                },
            ) {
                Text("Other player", color = Color.White)
            }
        }

        if (controlsVisible) Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(WindowInsets.safeDrawing.asPaddingValues())
                .padding(12.dp)
                .background(Color(0xCC111111), RoundedCornerShape(12.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp),
        ) {
            playbackError?.let {
                Text(
                    text = it,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (!isLive) {
                    IconButton(
                        onClick = {
                            showControls()
                            mediaPlayer.time = (mediaPlayer.time - 10_000L).coerceAtLeast(0L)
                        },
                    ) {
                        Icon(
                            imageVector = Icons.Default.Replay10,
                            contentDescription = "Rewind 10 seconds",
                            tint = Color.White,
                            modifier = Modifier.size(30.dp),
                        )
                    }
                }
                IconButton(
                    onClick = {
                        showControls()
                        if (mediaPlayer.isPlaying) mediaPlayer.pause() else mediaPlayer.play()
                    },
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Play",
                        tint = Color.White,
                        modifier = Modifier.size(32.dp),
                    )
                }
                if (!isLive) {
                    IconButton(
                        onClick = {
                            showControls()
                            val target = mediaPlayer.time + 30_000L
                            mediaPlayer.time = if (duration > 0L) {
                                target.coerceAtMost(duration)
                            } else {
                                target
                            }
                        },
                    ) {
                        Icon(
                            imageVector = Icons.Default.Forward30,
                            contentDescription = "Skip forward 30 seconds",
                            tint = Color.White,
                            modifier = Modifier.size(30.dp),
                        )
                    }
                }
                Text(
                    text = if (isLive) {
                        "LIVE"
                    } else {
                        "${formatDuration(currentTime)} / ${formatDuration(duration)}"
                    },
                    color = Color.White,
                    style = MaterialTheme.typography.labelMedium,
                )
                Spacer(Modifier.weight(1f))
                TrackMenuButton(
                    label = "Quality",
                    choices = qualityChoices,
                    selectedId = selectedQuality,
                    enabled = true,
                    onInteraction = ::showControls,
                    onSelect = { choice ->
                        if (choice.id != selectedQuality) {
                            if (!isLive) resumeAfterQualityChange = currentTime
                            selectedQuality = choice.id
                        }
                    },
                )
                TrackMenuButton(
                    label = "Audio",
                    choices = audioTracks,
                    selectedId = selectedAudioTrack,
                    enabled = audioTracks.size > 1,
                    onInteraction = ::showControls,
                    onSelect = { choice ->
                        if (mediaPlayer.setAudioTrack(choice.id)) {
                            selectedAudioTrack = choice.id
                        }
                    },
                )
                TrackMenuButton(
                    label = "Subtitles",
                    choices = subtitleTracks,
                    selectedId = selectedSubtitleTrack,
                    enabled = subtitleTracks.size > 1,
                    onInteraction = ::showControls,
                    onSelect = { choice ->
                        if (mediaPlayer.setSpuTrack(choice.id)) {
                            selectedSubtitleTrack = choice.id
                        }
                    },
                )
            }
            if (!isLive) Slider(
                value = if (isScrubbing) {
                    scrubFraction
                } else if (duration > 0L) {
                    (currentTime.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
                } else {
                    0f
                },
                onValueChange = {
                    showControls()
                    isScrubbing = true
                    scrubFraction = it
                },
                onValueChangeFinished = {
                    if (duration > 0L) {
                        mediaPlayer.time = (duration * scrubFraction).toLong()
                    }
                    isScrubbing = false
                },
                enabled = duration > 0L,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

@Composable
private fun TrackMenuButton(
    label: String,
    choices: List<VlcTrackChoice>,
    selectedId: Int,
    enabled: Boolean,
    onInteraction: () -> Unit,
    onSelect: (VlcTrackChoice) -> Unit,
) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        TextButton(
            onClick = {
                onInteraction()
                expanded = true
            },
            enabled = enabled,
        ) {
            Text(label)
        }
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
        ) {
            choices.forEach { choice ->
                DropdownMenuItem(
                    text = {
                        Text(
                            text = if (choice.id == selectedId) "✓ ${choice.name}" else choice.name,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    },
                    onClick = {
                        onInteraction()
                        onSelect(choice)
                        expanded = false
                    },
                )
            }
        }
    }
}

private fun formatDuration(milliseconds: Long): String {
    if (milliseconds <= 0L) return "0:00"
    val totalSeconds = milliseconds / 1000
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return if (hours > 0) {
        "%d:%02d:%02d".format(hours, minutes, seconds)
    } else {
        "%d:%02d".format(minutes, seconds)
    }
}

private const val QUALITY_AUTO = -1
private const val QUALITY_MAX = Int.MAX_VALUE

@file:androidx.media3.common.util.UnstableApi

package com.streamdeck.iptv.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.res.Configuration
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.KeyEvent as AndroidKeyEvent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.streamdeck.iptv.IptvUiState
import com.streamdeck.iptv.IptvViewModel
import com.streamdeck.iptv.R
import com.streamdeck.iptv.data.AppUpdate
import com.streamdeck.iptv.data.ContentKind
import com.streamdeck.iptv.data.LibrarySection
import com.streamdeck.iptv.data.StreamItem
import com.streamdeck.iptv.data.canBeFavorited
import com.streamdeck.iptv.data.localLibraryKey
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun StreamDeckApp(viewModel: IptvViewModel) {
    StreamDeckTheme {
        val state = viewModel.state
        Box(Modifier.fillMaxSize()) {
            Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                when {
                    state.checkingSession -> LoadingScreen()
                    !state.authenticated -> LoginScreen(
                        loading = state.loading,
                        error = state.error,
                        onLogin = viewModel::login,
                        onEdit = viewModel::clearError,
                    )
                    state.playbackUrl != null -> PlayerScreen(
                        sources = state.playbackSources.ifEmpty { listOf(state.playbackUrl) },
                        title = state.playbackTitle,
                        contentKind = state.playbackKind ?: ContentKind.MOVIE,
                        startPositionMs = state.playbackStartPositionMs,
                        onProgress = viewModel::savePlaybackProgress,
                        onBack = viewModel::closePlayer,
                    )
                    else -> LibraryScreen(
                        state = state,
                        onSection = viewModel::loadSection,
                        onCategory = viewModel::selectCategory,
                        onSearchQuery = viewModel::updateSearchQuery,
                        onItem = viewModel::open,
                        onFavorite = viewModel::toggleFavorite,
                        onBackFromSeries = viewModel::closeSeries,
                        onLogout = viewModel::logout,
                    )
                }
            }
            state.availableUpdate
                ?.takeUnless { state.updateDismissed }
                ?.let { update ->
                    UpdateDialog(
                        update = update,
                        downloading = state.updateDownloading,
                        awaitingPermission = state.updateAwaitingPermission,
                        error = state.updateError,
                        onInstall = viewModel::installAvailableUpdate,
                        onDismiss = viewModel::dismissUpdate,
                    )
                }
        }
    }
}

@Composable
private fun UpdateDialog(
    update: AppUpdate,
    downloading: Boolean,
    awaitingPermission: Boolean,
    error: String?,
    onInstall: () -> Unit,
    onDismiss: () -> Unit,
) {
    val updateFocusRequester = remember { FocusRequester() }
    val laterFocusRequester = remember { FocusRequester() }
    LaunchedEffect(downloading, awaitingPermission) {
        if (!downloading) {
            repeat(5) {
                delay(120)
                val focused = runCatching { updateFocusRequester.requestFocus() }
                    .getOrDefault(false)
                if (focused) return@LaunchedEffect
            }
        }
    }
    AlertDialog(
        onDismissRequest = { if (!downloading) onDismiss() },
        title = { Text("Update ${update.versionName} available") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (update.releaseDate.isNotBlank()) {
                    Text(
                        text = "Released ${update.releaseDate}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.labelMedium,
                    )
                }
                if (update.notes.isNotEmpty()) {
                    Text(update.notes.joinToString(separator = "\n") { "• $it" })
                } else {
                    Text("A newer version of b33r IPTV is ready.")
                }
                if (downloading) {
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                    Text("Downloading and verifying the update…")
                }
                if (awaitingPermission) {
                    Text("Android needs permission to install updates from this app.")
                }
                error?.let {
                    Text(
                        text = it,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onInstall,
                enabled = !downloading,
                modifier = Modifier
                    .focusRequester(updateFocusRequester)
                    .focusProperties { left = laterFocusRequester },
            ) {
                Text(
                    when {
                        downloading -> "Downloading"
                        awaitingPermission -> "Open permission"
                        else -> "Update now"
                    },
                )
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                enabled = !downloading,
                modifier = Modifier
                    .focusRequester(laterFocusRequester)
                    .focusProperties { right = updateFocusRequester },
            ) {
                Text("Later")
            }
        },
    )
}

@Composable
private fun LoadingScreen() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator()
    }
}

private fun opensTvKeyboard(event: androidx.compose.ui.input.key.KeyEvent): Boolean {
    val keyCode = event.nativeKeyEvent.keyCode
    return event.type == KeyEventType.KeyDown &&
        (
            keyCode == AndroidKeyEvent.KEYCODE_DPAD_CENTER ||
                keyCode == AndroidKeyEvent.KEYCODE_ENTER ||
                keyCode == AndroidKeyEvent.KEYCODE_NUMPAD_ENTER
            )
}

private fun tvFocusDirection(event: androidx.compose.ui.input.key.KeyEvent): FocusDirection? {
    if (event.type != KeyEventType.KeyDown) return null
    return when (event.nativeKeyEvent.keyCode) {
        AndroidKeyEvent.KEYCODE_DPAD_UP -> FocusDirection.Up
        AndroidKeyEvent.KEYCODE_DPAD_DOWN -> FocusDirection.Down
        AndroidKeyEvent.KEYCODE_DPAD_LEFT -> FocusDirection.Left
        AndroidKeyEvent.KEYCODE_DPAD_RIGHT -> FocusDirection.Right
        else -> null
    }
}

@Composable
private fun LoginScreen(
    loading: Boolean,
    error: String?,
    onLogin: (String, String) -> Unit,
    onEdit: () -> Unit,
) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var usernameEditing by remember { mutableStateOf(false) }
    var passwordEditing by remember { mutableStateOf(false) }
    val configuration = LocalConfiguration.current
    val isTelevision =
        configuration.uiMode and Configuration.UI_MODE_TYPE_MASK ==
            Configuration.UI_MODE_TYPE_TELEVISION
    val usernameFocusRequester = remember { FocusRequester() }
    val passwordFocusRequester = remember { FocusRequester() }
    val softwareKeyboardController = LocalSoftwareKeyboardController.current
    val submit = {
        usernameEditing = false
        passwordEditing = false
        softwareKeyboardController?.hide()
        onLogin(username, password)
    }

    LaunchedEffect(usernameEditing) {
        if (isTelevision && usernameEditing) {
            usernameFocusRequester.requestFocus()
            delay(50)
            softwareKeyboardController?.show()
        }
    }
    LaunchedEffect(passwordEditing) {
        if (isTelevision && passwordEditing) {
            passwordFocusRequester.requestFocus()
            delay(50)
            softwareKeyboardController?.show()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF2B1709),
                        Color(0xFF160B05),
                        Color(0xFF080301),
                    ),
                ),
            )
            .padding(WindowInsets.safeDrawing.asPaddingValues())
            .padding(24.dp),
        contentAlignment = Alignment.Center,
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .widthIn(max = 460.dp),
            shape = RoundedCornerShape(26.dp),
            color = Color(0xF21A0F08),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.34f)),
            tonalElevation = 8.dp,
            shadowElevation = 18.dp,
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 28.dp, vertical = 30.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                Surface(
                    modifier = Modifier.size(54.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFF2A170A),
                    border = BorderStroke(
                        1.dp,
                        MaterialTheme.colorScheme.primary.copy(alpha = 0.38f),
                    ),
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = "b33r",
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp,
                            letterSpacing = 0.2.sp,
                        )
                    }
                }
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "B33R IPTV",
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        letterSpacing = 2.4.sp,
                    )
                    Text(
                        text = "Pour into your library",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Text(
                        text = "Sign in with your username and password.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
                OutlinedTextField(
                    value = username,
                    onValueChange = {
                        username = it
                        onEdit()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(usernameFocusRequester)
                        .onFocusChanged {
                            if (!it.isFocused) usernameEditing = false
                        }
                        .onPreviewKeyEvent { event ->
                            if (isTelevision && opensTvKeyboard(event)) {
                                usernameEditing = true
                                softwareKeyboardController?.show()
                                true
                            } else {
                                false
                            }
                        },
                    enabled = !loading,
                    readOnly = isTelevision && !usernameEditing,
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    label = { Text("Username") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = Color(0xFF5B3918),
                        focusedContainerColor = Color(0xFF100804),
                        unfocusedContainerColor = Color(0xFF100804),
                    ),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    keyboardActions = KeyboardActions(
                        onNext = {
                            usernameEditing = false
                            passwordEditing = true
                        },
                    ),
                )
                OutlinedTextField(
                    value = password,
                    onValueChange = {
                        password = it
                        onEdit()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(passwordFocusRequester)
                        .onFocusChanged {
                            if (!it.isFocused) passwordEditing = false
                        }
                        .onPreviewKeyEvent { event ->
                            if (isTelevision && opensTvKeyboard(event)) {
                                passwordEditing = true
                                softwareKeyboardController?.show()
                                true
                            } else {
                                false
                            }
                        },
                    enabled = !loading,
                    readOnly = isTelevision && !passwordEditing,
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    label = { Text("Password") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = Color(0xFF5B3918),
                        focusedContainerColor = Color(0xFF100804),
                        unfocusedContainerColor = Color(0xFF100804),
                    ),
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { submit() }),
                )
                Button(
                    onClick = submit,
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    enabled = !loading,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                    ),
                ) {
                    if (loading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.onPrimary,
                        )
                    } else {
                        Text(
                            text = "Login",
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.4.sp,
                        )
                    }
                }
                error?.let {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.error.copy(alpha = 0.10f),
                        border = BorderStroke(
                            1.dp,
                            MaterialTheme.colorScheme.error.copy(alpha = 0.24f),
                        ),
                    ) {
                        Text(
                            text = it,
                            modifier = Modifier.padding(12.dp),
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                }
            }
        }
    }
}

private enum class TvKeyboardField {
    USERNAME,
    PASSWORD,
}

@Composable
private fun TvLoginField(
    label: String,
    value: String,
    masked: Boolean,
    enabled: Boolean,
    onOpenKeyboard: () -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(72.dp)
            .onFocusChanged { focused = it.isFocused }
            .clickable(enabled = enabled, onClick = onOpenKeyboard),
        shape = RoundedCornerShape(8.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(
            width = if (focused) 3.dp else 1.dp,
            color = if (focused) {
                MaterialTheme.colorScheme.primary
            } else {
                MaterialTheme.colorScheme.outline
            },
        ),
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.Center,
        ) {
            Text(
                text = label,
                color = if (focused) {
                    MaterialTheme.colorScheme.primary
                } else {
                    MaterialTheme.colorScheme.onSurfaceVariant
                },
                style = MaterialTheme.typography.labelMedium,
            )
            Text(
                text = when {
                    value.isEmpty() -> "Press OK to type"
                    masked -> "•".repeat(value.length)
                    else -> value
                },
                color = if (value.isEmpty()) {
                    MaterialTheme.colorScheme.onSurfaceVariant
                } else {
                    MaterialTheme.colorScheme.onSurface
                },
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun TvSearchField(
    value: String,
    placeholder: String,
    onOpenKeyboard: () -> Unit,
    onClear: () -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    Surface(
        modifier = Modifier
            .padding(horizontal = 20.dp)
            .widthIn(max = 560.dp)
            .fillMaxWidth()
            .height(64.dp)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onOpenKeyboard),
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(
            width = if (focused) 3.dp else 1.dp,
            color = if (focused) {
                MaterialTheme.colorScheme.primary
            } else {
                MaterialTheme.colorScheme.outline
            },
        ),
    ) {
        Row(
            modifier = Modifier.padding(start = 16.dp, end = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Icon(
                Icons.Default.Search,
                contentDescription = null,
                tint = if (focused) {
                    MaterialTheme.colorScheme.primary
                } else {
                    MaterialTheme.colorScheme.onSurfaceVariant
                },
            )
            Text(
                text = value.ifEmpty { "$placeholder — press OK to type" },
                modifier = Modifier.weight(1f),
                color = if (value.isEmpty()) {
                    MaterialTheme.colorScheme.onSurfaceVariant
                } else {
                    MaterialTheme.colorScheme.onSurface
                },
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (value.isNotEmpty()) {
                IconButton(onClick = onClear) {
                    Icon(Icons.Default.Close, contentDescription = "Clear search")
                }
            }
        }
    }
}

@Composable
private fun TvKeyboardDialog(
    title: String,
    value: String,
    masked: Boolean,
    onValueChange: (String) -> Unit,
    onDone: () -> Unit,
    onDismiss: () -> Unit,
) {
    var uppercase by remember { mutableStateOf(false) }
    var symbols by remember { mutableStateOf(false) }
    val alphaRows = listOf(
        "1234567890".map(Char::toString),
        "qwertyuiop".map(Char::toString),
        "asdfghjkl".map(Char::toString),
        "zxcvbnm".map(Char::toString),
    )
    val symbolRows = listOf(
        "1234567890".map(Char::toString),
        listOf("!", "@", "#", "$", "%", "^", "&", "*", "(", ")"),
        listOf("_", "-", "+", "=", "[", "]", "{", "}", "<", ">"),
        listOf(".", ",", ":", ";", "/", "?", "\\", "|", "'", "\""),
    )
    val rows = if (symbols) {
        symbolRows
    } else if (uppercase) {
        alphaRows.map { row -> row.map(String::uppercase) }
    } else {
        alphaRows
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.fillMaxWidth().widthIn(max = 760.dp),
            color = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(18.dp),
            tonalElevation = 8.dp,
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text(title, style = MaterialTheme.typography.titleLarge)
                Text(
                    text = when {
                        value.isEmpty() -> " "
                        masked -> "•".repeat(value.length)
                        else -> value
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            MaterialTheme.colorScheme.surfaceVariant,
                            RoundedCornerShape(8.dp),
                        )
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.titleMedium,
                )
                rows.forEach { row ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        row.forEach { key ->
                            TvKeyboardKey(
                                label = key,
                                modifier = Modifier.weight(1f),
                                onClick = { onValueChange(value + key) },
                            )
                        }
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    TvKeyboardKey(
                        label = if (uppercase) "abc" else "ABC",
                        modifier = Modifier.weight(1f),
                        onClick = {
                            symbols = false
                            uppercase = !uppercase
                        },
                    )
                    TvKeyboardKey(
                        label = if (symbols) "ABC" else "#+=",
                        modifier = Modifier.weight(1f),
                        onClick = { symbols = !symbols },
                    )
                    TvKeyboardKey(
                        label = "SPACE",
                        modifier = Modifier.weight(2f),
                        onClick = { onValueChange("$value ") },
                    )
                    TvKeyboardKey(
                        label = "⌫",
                        modifier = Modifier.weight(1f),
                        onClick = {
                            if (value.isNotEmpty()) onValueChange(value.dropLast(1))
                        },
                    )
                    TvKeyboardKey(
                        label = "CLEAR",
                        modifier = Modifier.weight(1f),
                        onClick = { onValueChange("") },
                    )
                    TvKeyboardKey(
                        label = "DONE",
                        modifier = Modifier.weight(1.3f),
                        emphasized = true,
                        onClick = onDone,
                    )
                }
            }
        }
    }
}

@Composable
private fun RowScope.TvKeyboardKey(
    label: String,
    modifier: Modifier = Modifier,
    emphasized: Boolean = false,
    onClick: () -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    val background = when {
        focused -> MaterialTheme.colorScheme.primary
        emphasized -> MaterialTheme.colorScheme.primaryContainer
        else -> MaterialTheme.colorScheme.surfaceVariant
    }
    Surface(
        modifier = modifier
            .height(46.dp)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick),
        color = background,
        shape = RoundedCornerShape(7.dp),
        border = if (focused) {
            BorderStroke(2.dp, MaterialTheme.colorScheme.onPrimary)
        } else {
            null
        },
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = label,
                color = if (focused) {
                    MaterialTheme.colorScheme.onPrimary
                } else {
                    MaterialTheme.colorScheme.onSurfaceVariant
                },
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                style = MaterialTheme.typography.labelLarge,
            )
        }
    }
}

@Composable
private fun LibraryScreen(
    state: IptvUiState,
    onSection: (LibrarySection) -> Unit,
    onCategory: (String?) -> Unit,
    onSearchQuery: (String) -> Unit,
    onItem: (StreamItem) -> Unit,
    onFavorite: (StreamItem) -> Unit,
    onBackFromSeries: () -> Unit,
    onLogout: () -> Unit,
) {
    BackHandler(enabled = state.seriesTitle != null, onBack = onBackFromSeries)
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth >= 720.dp
        if (wide) {
            Row(Modifier.fillMaxSize().padding(WindowInsets.safeDrawing.asPaddingValues())) {
                SectionRail(state.section, onSection, onLogout)
                LibraryContent(
                    state = state,
                    wide = true,
                    onCategory = onCategory,
                    onSearchQuery = onSearchQuery,
                    onItem = onItem,
                    onFavorite = onFavorite,
                    onBackFromSeries = onBackFromSeries,
                )
            }
        } else {
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(WindowInsets.statusBars.asPaddingValues()),
            ) {
                LibraryContent(
                    state = state,
                    wide = false,
                    onCategory = onCategory,
                    onSearchQuery = onSearchQuery,
                    onItem = onItem,
                    onFavorite = onFavorite,
                    onBackFromSeries = onBackFromSeries,
                    onLogout = onLogout,
                    modifier = Modifier.weight(1f),
                )
                SectionBar(state.section, onSection)
            }
        }
    }
}

@Composable
private fun LibraryContent(
    state: IptvUiState,
    wide: Boolean,
    onCategory: (String?) -> Unit,
    onSearchQuery: (String) -> Unit,
    onItem: (StreamItem) -> Unit,
    onFavorite: (StreamItem) -> Unit,
    onBackFromSeries: () -> Unit,
    modifier: Modifier = Modifier,
    onLogout: (() -> Unit)? = null,
) {
    val configuration = LocalConfiguration.current
    val isTelevision =
        configuration.uiMode and Configuration.UI_MODE_TYPE_MASK ==
            Configuration.UI_MODE_TYPE_TELEVISION
    var searchEditing by remember(state.section, state.seriesTitle) {
        mutableStateOf(false)
    }
    val searchFocusRequester = remember { FocusRequester() }
    val firstResultFocusRequester = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    val softwareKeyboardController = LocalSoftwareKeyboardController.current
    val searchPlaceholder = when {
        state.seriesTitle != null -> "Search episodes"
        state.section == LibrarySection.LIVE -> "Search live channels"
        state.section == LibrarySection.MOVIES -> "Search movies"
        state.section == LibrarySection.SERIES -> "Search series"
        state.section == LibrarySection.FAVORITES -> "Search favorites"
        else -> "Search continue watching"
    }
    val sectionItems = if (state.seriesTitle == null) state.items else state.episodes
    val visibleItems = remember(sectionItems, state.searchQuery) {
        val query = state.searchQuery.trim()
        if (query.isEmpty()) {
            sectionItems
        } else {
            sectionItems.filter { item ->
                item.name.contains(query, ignoreCase = true) ||
                    item.subtitle.contains(query, ignoreCase = true)
            }
        }
    }
    LaunchedEffect(searchEditing) {
        if (isTelevision && searchEditing) {
            searchFocusRequester.requestFocus()
            delay(50)
            softwareKeyboardController?.show()
        }
    }
    fun leaveSearch(direction: FocusDirection): Boolean {
        searchEditing = false
        softwareKeyboardController?.hide()
        if (direction == FocusDirection.Down && visibleItems.isNotEmpty()) {
            val focusedFirstResult = runCatching {
                firstResultFocusRequester.requestFocus()
            }.getOrDefault(false)
            if (focusedFirstResult) return true
        }
        return focusManager.moveFocus(direction)
    }

    Column(
        modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF241307),
                        Color(0xFF120804),
                        MaterialTheme.colorScheme.background,
                    ),
                ),
            ),
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            shape = RoundedCornerShape(20.dp),
            color = Color(0xE61A0F08),
            border = BorderStroke(1.dp, Color(0xFF4B2D12)),
            shadowElevation = 8.dp,
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (state.seriesTitle != null) {
                    IconButton(onClick = onBackFromSeries) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
                Column(
                    modifier = Modifier.weight(1f),
                ) {
                    Text(
                        text = "B33R IPTV",
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.6.sp,
                    )
                    Text(
                        text = state.seriesTitle ?: state.section.title,
                        style = if (wide) {
                            MaterialTheme.typography.headlineLarge
                        } else {
                            MaterialTheme.typography.headlineSmall
                        },
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = (-0.5).sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                if (state.accountUsername.isNotBlank()) {
                    Surface(
                        modifier = Modifier.padding(start = 8.dp).widthIn(max = 170.dp),
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.09f),
                        border = BorderStroke(
                            1.dp,
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.22f),
                        ),
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                            horizontalAlignment = Alignment.End,
                        ) {
                            Text(
                                text = state.accountUsername,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.labelLarge,
                            )
                            Text(
                                text = formatAccountExpiration(
                                    state.accountExpiresAtEpochSeconds,
                                ),
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                style = MaterialTheme.typography.labelSmall,
                            )
                        }
                    }
                }
                onLogout?.let {
                    IconButton(onClick = it) {
                        Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = "Log out")
                    }
                }
            }
        }

        if (state.seriesTitle == null && state.categories.isNotEmpty()) {
            LazyRow(
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                item {
                    FilterChip(
                        selected = state.selectedCategoryId == null,
                        onClick = { onCategory(null) },
                        label = { Text("All") },
                        colors = libraryFilterChipColors(),
                    )
                }
                items(state.categories, key = { it.id }) { category ->
                    FilterChip(
                        selected = state.selectedCategoryId == category.id,
                        onClick = { onCategory(category.id) },
                        label = { Text(category.name, maxLines = 1) },
                        colors = libraryFilterChipColors(),
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        OutlinedTextField(
            value = state.searchQuery,
            onValueChange = onSearchQuery,
            modifier = Modifier
                .padding(horizontal = 20.dp)
                .widthIn(max = 560.dp)
                .fillMaxWidth()
                .focusRequester(searchFocusRequester)
                .onFocusChanged {
                    if (!it.isFocused) searchEditing = false
                }
                .onPreviewKeyEvent { event ->
                    val direction = if (isTelevision) tvFocusDirection(event) else null
                    when {
                        direction != null -> {
                            leaveSearch(direction)
                            true
                        }
                        isTelevision && opensTvKeyboard(event) -> {
                            searchEditing = true
                            softwareKeyboardController?.show()
                            true
                        }
                        else -> false
                    }
                },
            readOnly = isTelevision && !searchEditing,
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = Color(0xFF5B3918),
                focusedContainerColor = Color(0xE61A0F08),
                unfocusedContainerColor = Color(0xE61A0F08),
            ),
            placeholder = { Text(searchPlaceholder) },
            leadingIcon = {
                Icon(Icons.Default.Search, contentDescription = null)
            },
            trailingIcon = if (state.searchQuery.isNotEmpty()) {
                {
                    IconButton(onClick = { onSearchQuery("") }) {
                        Icon(Icons.Default.Close, contentDescription = "Clear search")
                    }
                }
            } else {
                null
            },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(
                onDone = {
                    searchEditing = false
                    softwareKeyboardController?.hide()
                },
            ),
        )
        Spacer(Modifier.height(12.dp))

        state.error?.let { message ->
            Text(
                text = message,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                color = MaterialTheme.colorScheme.error,
            )
        }

        Box(Modifier.fillMaxSize()) {
            if (visibleItems.isNotEmpty()) {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(if (wide) 178.dp else 142.dp),
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(
                        start = 20.dp,
                        end = 20.dp,
                        top = 4.dp,
                        bottom = 24.dp,
                    ),
                    horizontalArrangement = Arrangement.spacedBy(18.dp),
                    verticalArrangement = Arrangement.spacedBy(22.dp),
                ) {
                    itemsIndexed(visibleItems, key = { _, item -> "${item.kind}-${item.id}" }) { index, item ->
                        ContentCard(
                            item = item,
                            modifier = if (index == 0) {
                                Modifier.focusRequester(firstResultFocusRequester)
                            } else {
                                Modifier
                            },
                            isFavorite = state.favoriteKeys.contains(item.localLibraryKey()),
                            onFavorite = if (item.canBeFavorited()) {
                                { onFavorite(item) }
                            } else {
                                null
                            },
                            onClick = { onItem(item) },
                        )
                    }
                }
            } else if (!state.loading && state.error == null) {
                Text(
                    text = if (state.searchQuery.isBlank()) {
                        "Nothing found in this section."
                    } else {
                        "No matches for “${state.searchQuery.trim()}”."
                    },
                    modifier = Modifier.align(Alignment.Center),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (state.loading) {
                CircularProgressIndicator(Modifier.align(Alignment.Center))
            }
        }
    }
}

@Composable
private fun libraryFilterChipColors() = FilterChipDefaults.filterChipColors(
    containerColor = Color(0xFF151515),
    labelColor = MaterialTheme.colorScheme.onSurfaceVariant,
    iconColor = MaterialTheme.colorScheme.onSurfaceVariant,
    selectedContainerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f),
    selectedLabelColor = MaterialTheme.colorScheme.primary,
    selectedLeadingIconColor = MaterialTheme.colorScheme.primary,
)

private fun formatAccountExpiration(expiresAtEpochSeconds: Long?): String {
    if (expiresAtEpochSeconds == null) return "Never expires"
    val safeSeconds = expiresAtEpochSeconds.coerceAtMost(Long.MAX_VALUE / 1_000L)
    val formatted = SimpleDateFormat("MMM d, yyyy", Locale.getDefault())
        .format(Date(safeSeconds * 1_000L))
    if (expiresAtEpochSeconds <= System.currentTimeMillis() / 1_000L) {
        return "Expired $formatted"
    }
    return "Expires $formatted"
}

@Composable
private fun ContentCard(
    item: StreamItem,
    modifier: Modifier = Modifier,
    isFavorite: Boolean,
    onFavorite: (() -> Unit)?,
    onClick: () -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.035f else 1f, label = "cardScale")
    val container by animateColorAsState(
        if (focused) Color(0xFF3A2412) else Color(0xFF1A0F08),
        label = "cardColor",
    )
    val posterRatio = if (item.kind == ContentKind.LIVE) 16f / 9f else 2f / 3f
    val context = LocalContext.current
    Card(
        onClick = onClick,
        modifier = modifier
            .fillMaxWidth()
            .scale(scale)
            .onFocusChanged { focused = it.isFocused },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = container),
        border = if (focused) {
            BorderStroke(2.dp, MaterialTheme.colorScheme.primary)
        } else {
            BorderStroke(1.dp, Color(0xFF3A2412))
        },
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(posterRatio)
                    .background(Color(0xFF241307)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = item.kind.icon(),
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.55f),
                    modifier = Modifier.size(if (item.kind == ContentKind.LIVE) 38.dp else 46.dp),
                )
                if (item.imageUrl.isNotBlank()) {
                    AsyncImage(
                        model = ImageRequest.Builder(context)
                            .data(item.imageUrl)
                            .crossfade(true)
                            .build(),
                        contentDescription = "${item.name} artwork",
                        contentScale = if (item.kind == ContentKind.LIVE) ContentScale.Fit else ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
                if (item.kind == ContentKind.LIVE) {
                    Text(
                        text = "LIVE",
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp)
                            .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 3.dp),
                        color = MaterialTheme.colorScheme.onPrimary,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp,
                    )
                }
                onFavorite?.let { favorite ->
                    Surface(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(7.dp)
                            .size(38.dp),
                        shape = RoundedCornerShape(19.dp),
                        color = Color(0xCC120804),
                        border = BorderStroke(
                            1.dp,
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.38f),
                        ),
                    ) {
                        IconButton(onClick = favorite) {
                            Icon(
                                imageVector = if (isFavorite) {
                                    Icons.Default.Favorite
                                } else {
                                    Icons.Default.FavoriteBorder
                                },
                                contentDescription = if (isFavorite) {
                                    "Remove favorite"
                                } else {
                                    "Add favorite"
                                },
                                tint = MaterialTheme.colorScheme.primary,
                            )
                        }
                    }
                }
            }
            Column(Modifier.padding(horizontal = 12.dp, vertical = 11.dp)) {
                Text(
                    text = item.name,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    lineHeight = 18.sp,
                )
                if (item.subtitle.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = item.subtitle.uppercase(),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 10.sp,
                        letterSpacing = 0.8.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
    }
}

private fun ContentKind.icon(): ImageVector = when (this) {
    ContentKind.LIVE -> Icons.Default.LiveTv
    ContentKind.MOVIE -> Icons.Default.Movie
    ContentKind.SERIES, ContentKind.EPISODE -> Icons.Default.VideoLibrary
}

@Composable
private fun SectionRail(
    selected: LibrarySection,
    onSection: (LibrarySection) -> Unit,
    onLogout: () -> Unit,
) {
    NavigationRail(
        modifier = Modifier
            .fillMaxHeight()
            .padding(10.dp)
            .width(104.dp)
            .clip(RoundedCornerShape(22.dp)),
        containerColor = Color(0xEB1A0F08),
        header = {
            Surface(
                modifier = Modifier.padding(vertical = 18.dp).size(48.dp),
                shape = RoundedCornerShape(15.dp),
                color = Color(0xFF2A170A),
                border = BorderStroke(
                    1.dp,
                    MaterialTheme.colorScheme.primary.copy(alpha = 0.28f),
                ),
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = "b33r",
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Black,
                        fontSize = 12.sp,
                    )
                }
            }
        },
    ) {
        LibrarySection.entries.forEach { section ->
            NavigationRailItem(
                selected = selected == section,
                onClick = { onSection(section) },
                icon = { Icon(section.icon(), contentDescription = null) },
                label = { Text(section.shortTitle()) },
                colors = NavigationRailItemDefaults.colors(
                    selectedIconColor = MaterialTheme.colorScheme.primary,
                    selectedTextColor = MaterialTheme.colorScheme.primary,
                    indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f),
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                ),
            )
        }
        Spacer(Modifier.weight(1f))
        NavigationRailItem(
            selected = false,
            onClick = onLogout,
            icon = { Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null) },
            label = { Text("Logout") },
            colors = NavigationRailItemDefaults.colors(
                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
            ),
        )
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun SectionBar(
    selected: LibrarySection,
    onSection: (LibrarySection) -> Unit,
) {
    NavigationBar(
        modifier = Modifier
            .padding(WindowInsets.navigationBars.asPaddingValues())
            .padding(horizontal = 10.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(20.dp)),
        containerColor = Color(0xF21A0F08),
    ) {
        LibrarySection.entries.forEach { section ->
            NavigationBarItem(
                selected = selected == section,
                onClick = { onSection(section) },
                icon = { Icon(section.icon(), contentDescription = null) },
                label = { Text(section.shortTitle()) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = MaterialTheme.colorScheme.primary,
                    selectedTextColor = MaterialTheme.colorScheme.primary,
                    indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f),
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                ),
            )
        }
    }
}

private fun LibrarySection.icon(): ImageVector = when (this) {
    LibrarySection.LIVE -> Icons.Default.LiveTv
    LibrarySection.MOVIES -> Icons.Default.Movie
    LibrarySection.SERIES -> Icons.Default.VideoLibrary
    LibrarySection.FAVORITES -> Icons.Default.Favorite
    LibrarySection.RESUME -> Icons.Default.History
}

private fun LibrarySection.shortTitle(): String = when (this) {
    LibrarySection.LIVE -> "Live"
    LibrarySection.MOVIES -> "Movies"
    LibrarySection.SERIES -> "Series"
    LibrarySection.FAVORITES -> "Favs"
    LibrarySection.RESUME -> "Continue"
}

private data class PlaybackAttempt(
    val sourceIndex: Int,
    val useTextureView: Boolean,
)

private data class VideoQualityOption(
    val label: String,
    val maxHeight: Int?,
    val forceHighest: Boolean,
)

private val videoQualityOptions = listOf(
    VideoQualityOption("Auto", null, false),
    VideoQualityOption("720p", 720, true),
    VideoQualityOption("1080p", 1_080, true),
    VideoQualityOption("1440p", 1_440, true),
    VideoQualityOption("2160p", 2_160, true),
    VideoQualityOption("Max", null, true),
)

private enum class PlaybackEngine {
    VLC,
    MEDIA3,
}

@Composable
private fun PlayerScreen(
    sources: List<String>,
    title: String,
    contentKind: ContentKind,
    startPositionMs: Long,
    onProgress: (Long, Long) -> Unit,
    onBack: () -> Unit,
) {
    var engine by remember(sources) { mutableStateOf(PlaybackEngine.VLC) }
    var vlcExhausted by remember(sources) { mutableStateOf(false) }
    if (engine == PlaybackEngine.VLC) {
        VlcPlayerScreen(
            sources = sources,
            title = title,
            contentKind = contentKind,
            startPositionMs = startPositionMs,
            onProgress = onProgress,
            onBack = onBack,
            onUseMedia3 = {
                vlcExhausted = true
                engine = PlaybackEngine.MEDIA3
            },
        )
    } else {
        Media3PlayerScreen(
            sources = sources,
            title = title,
            contentKind = contentKind,
            startPositionMs = startPositionMs,
            onProgress = onProgress,
            onBack = onBack,
            canUseVlc = !vlcExhausted,
            onUseVlc = { engine = PlaybackEngine.VLC },
        )
    }
}

@Composable
private fun Media3PlayerScreen(
    sources: List<String>,
    title: String,
    contentKind: ContentKind,
    startPositionMs: Long,
    onProgress: (Long, Long) -> Unit,
    onBack: () -> Unit,
    canUseVlc: Boolean,
    onUseVlc: () -> Unit,
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val attempts = remember(sources) {
        sources.flatMapIndexed { sourceIndex, _ ->
            listOf(
                PlaybackAttempt(sourceIndex, useTextureView = false),
                PlaybackAttempt(sourceIndex, useTextureView = true),
            )
        }
    }
    var attemptIndex by remember(sources) { mutableIntStateOf(0) }
    var playerError by remember(sources) { mutableStateOf<String?>(null) }
    var externalError by remember(sources) { mutableStateOf<String?>(null) }
    var controlsVisible by remember(sources) { mutableStateOf(true) }
    var isBuffering by remember(sources) { mutableStateOf(true) }
    var selectedQualityIndex by remember(sources) { mutableIntStateOf(0) }
    val mediaBackFocusRequester = remember { FocusRequester() }
    val mediaQualityFocusRequester = remember { FocusRequester() }
    val mediaOtherPlayerFocusRequester = remember { FocusRequester() }
    val attempt = attempts[attemptIndex.coerceIn(attempts.indices)]
    val activeUrl = sources[attempt.sourceIndex]
    val player = remember(activeUrl, attempt.useTextureView) {
        val renderersFactory = DefaultRenderersFactory(context)
            .setEnableDecoderFallback(true)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                15_000,
                60_000,
                2_500,
                5_000,
            )
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()
        ExoPlayer.Builder(context, renderersFactory)
            .setLoadControl(loadControl)
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(30_000)
            .build()
            .apply {
            if (contentKind != ContentKind.LIVE && startPositionMs > 0L) {
                setMediaItem(createMediaItem(activeUrl), startPositionMs)
            } else {
                setMediaItem(createMediaItem(activeUrl))
            }
            prepare()
            playWhenReady = true
            setHandleAudioBecomingNoisy(true)
        }
    }

    DisposableEffect(player, lifecycleOwner) {
        val playerListener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                isBuffering = playbackState == Player.STATE_BUFFERING
            }

            override fun onRenderedFirstFrame() {
                playerError = null
                isBuffering = false
            }

            override fun onPlayerError(error: PlaybackException) {
                isBuffering = false
                if (attemptIndex < attempts.lastIndex) {
                    playerError = "Playback failed; trying the next fallback."
                    attemptIndex += 1
                } else if (canUseVlc) {
                    playerError = "Media3 could not decode this stream; switching to VLC."
                    onUseVlc()
                } else {
                    playerError = "All built-in playback engines failed for this stream."
                }
            }
        }
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> player.play()
                Lifecycle.Event.ON_STOP -> player.pause()
                else -> Unit
            }
        }
        player.addListener(playerListener)
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            if (contentKind != ContentKind.LIVE) {
                onProgress(player.currentPosition.coerceAtLeast(0L), player.duration.coerceAtLeast(0L))
            }
            player.removeListener(playerListener)
            lifecycleOwner.lifecycle.removeObserver(observer)
            player.release()
        }
    }

    LaunchedEffect(player, contentKind) {
        while (true) {
            delay(5_000)
            if (contentKind != ContentKind.LIVE && player.currentPosition > 0L) {
                onProgress(player.currentPosition, player.duration.coerceAtLeast(0L))
            }
        }
    }

    LaunchedEffect(controlsVisible) {
        if (controlsVisible) {
            delay(100)
            runCatching { mediaBackFocusRequester.requestFocus() }
        }
    }

    LaunchedEffect(player, selectedQualityIndex) {
        val quality = videoQualityOptions[selectedQualityIndex]
        val parameters = player.trackSelectionParameters.buildUpon()
            .setForceHighestSupportedBitrate(quality.forceHighest)
            .apply {
                if (quality.maxHeight == null) {
                    clearVideoSizeConstraints()
                } else {
                    setMaxVideoSize(Int.MAX_VALUE, quality.maxHeight)
                }
            }
            .build()
        player.trackSelectionParameters = parameters
    }

    LaunchedEffect(player, attemptIndex) {
        delay(10_000)
        if (
            player.isPlaying &&
            player.currentPosition > 1_000 &&
            player.videoSize.width == 0 &&
            attemptIndex < attempts.lastIndex
        ) {
            playerError = "No video frames detected; trying the next fallback."
            attemptIndex += 1
        } else if (
            player.isPlaying &&
            player.currentPosition > 1_000 &&
            player.videoSize.width == 0
        ) {
            if (canUseVlc) {
                onUseVlc()
            } else {
                playerError = "All built-in playback engines failed to produce video."
            }
        }
    }

    fun openInAnotherPlayer() {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse(activeUrl), "video/*")
            putExtra(Intent.EXTRA_TITLE, title)
        }
        try {
            context.startActivity(Intent.createChooser(intent, "Open with video player"))
            externalError = null
        } catch (_: ActivityNotFoundException) {
            externalError = "No other compatible video player is installed."
        }
    }

    Box(Modifier.fillMaxSize()) {
        key(attemptIndex) {
            AndroidView(
                factory = { viewContext ->
                    val layout = if (attempt.useTextureView) {
                        R.layout.player_texture
                    } else {
                        R.layout.player_surface
                    }
                    (LayoutInflater.from(viewContext).inflate(layout, null, false) as PlayerView).apply {
                        if (!attempt.useTextureView) {
                            setEnableComposeSurfaceSyncWorkaround(true)
                        }
                        resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                        setShowSubtitleButton(true)
                        setShowRewindButton(contentKind != ContentKind.LIVE)
                        setShowFastForwardButton(contentKind != ContentKind.LIVE)
                        controllerShowTimeoutMs = 5_000
                        controllerAutoShow = true
                        controllerHideOnTouch = true
                        setControllerVisibilityListener(
                            PlayerView.ControllerVisibilityListener { visibility ->
                                controlsVisible = visibility == View.VISIBLE
                            },
                        )
                        this.player = player
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT,
                        )
                    }
                },
                update = { view ->
                    view.player = player
                },
                modifier = Modifier.fillMaxSize(),
            )
        }
        if (controlsVisible) Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(WindowInsets.safeDrawing.asPaddingValues())
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .focusRequester(mediaBackFocusRequester)
                    .focusProperties { right = mediaQualityFocusRequester },
            ) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = Color.White,
                )
            }
            Text(
                text = title,
                modifier = Modifier.weight(1f),
                color = Color.White,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (contentKind == ContentKind.LIVE) {
                Text(
                    text = "LIVE",
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 12.dp),
                )
            }
            Media3QualityMenu(
                selectedIndex = selectedQualityIndex,
                onSelect = { selectedQualityIndex = it },
                modifier = Modifier
                    .focusRequester(mediaQualityFocusRequester)
                    .focusProperties {
                        left = mediaBackFocusRequester
                        right = mediaOtherPlayerFocusRequester
                    },
            )
            TextButton(
                onClick = ::openInAnotherPlayer,
                modifier = Modifier
                    .focusRequester(mediaOtherPlayerFocusRequester)
                    .focusProperties { left = mediaQualityFocusRequester },
            ) {
                Text(
                    text = "Other player",
                    color = Color.White,
                    maxLines = 1,
                )
            }
        }
        if (isBuffering) {
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .background(Color(0xCC111111), RoundedCornerShape(12.dp))
                    .padding(horizontal = 22.dp, vertical = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                Text(
                    text = "Buffering…",
                    color = Color.White,
                    style = MaterialTheme.typography.labelLarge,
                )
            }
        }
        val statusMessage = externalError ?: playerError
        statusMessage?.let { message ->
            Text(
                text = message,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(WindowInsets.safeDrawing.asPaddingValues())
                    .padding(16.dp)
                    .background(Color(0xDD111111), RoundedCornerShape(8.dp))
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                color = Color.White,
                style = MaterialTheme.typography.bodyMedium,
            )
        }
    }
}

@Composable
private fun Media3QualityMenu(
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        TextButton(
            onClick = { expanded = true },
            modifier = modifier,
        ) {
            Text(
                text = "Quality: ${videoQualityOptions[selectedIndex].label}",
                color = Color.White,
                maxLines = 1,
            )
        }
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
        ) {
            videoQualityOptions.forEachIndexed { index, quality ->
                DropdownMenuItem(
                    text = {
                        Text(
                            if (index == selectedIndex) {
                                "✓ ${quality.label}"
                            } else {
                                quality.label
                            },
                        )
                    },
                    onClick = {
                        onSelect(index)
                        expanded = false
                    },
                )
            }
        }
    }
}

private fun createMediaItem(url: String): MediaItem {
    val normalized = url.lowercase()
    val mimeType = when {
        ".m3u8" in normalized || "format=m3u8" in normalized || "type=m3u8" in normalized ->
            MimeTypes.APPLICATION_M3U8
        ".mpd" in normalized || "format=mpd" in normalized || "type=mpd" in normalized ->
            MimeTypes.APPLICATION_MPD
        ".ism/manifest" in normalized || normalized.endsWith(".ism") ->
            MimeTypes.APPLICATION_SS
        else -> null
    }
    return MediaItem.Builder()
        .setUri(url)
        .apply { mimeType?.let { setMimeType(it) } }
        .build()
}

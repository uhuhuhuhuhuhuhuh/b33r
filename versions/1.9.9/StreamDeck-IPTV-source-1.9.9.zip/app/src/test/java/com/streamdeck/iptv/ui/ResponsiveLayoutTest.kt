package com.streamdeck.iptv.ui

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ResponsiveLayoutTest {
    @Test
    fun televisionScaleGrowsAcross720p1080pAnd4k() {
        val hd = calculateResponsiveScaleProfile(true, 540, 720)
        val fullHd = calculateResponsiveScaleProfile(true, 540, 1_080)
        val ultraHd = calculateResponsiveScaleProfile(true, 540, 2_160)

        assertTrue(hd.uiScale < fullHd.uiScale)
        assertTrue(fullHd.uiScale < ultraHd.uiScale)
        assertTrue(hd.textScale < fullHd.textScale)
        assertTrue(fullHd.textScale < ultraHd.textScale)
    }

    @Test
    fun phoneTabletAndLargeTabletUseDifferentScales() {
        val phone = calculateResponsiveScaleProfile(false, 384, 1_440)
        val tablet = calculateResponsiveScaleProfile(false, 700, 1_600)
        val largeTablet = calculateResponsiveScaleProfile(false, 900, 1_800)

        assertEquals(1.00f, phone.uiScale)
        assertEquals(1.08f, tablet.uiScale)
        assertEquals(1.14f, largeTablet.uiScale)
        assertTrue(phone.textScale < tablet.textScale)
        assertTrue(tablet.textScale < largeTablet.textScale)
    }

    @Test
    fun compactPhoneShrinksWithoutMakingTextTooSmall() {
        val compact = calculateResponsiveScaleProfile(false, 320, 720)

        assertEquals(0.92f, compact.uiScale)
        assertEquals(0.96f, compact.textScale)
    }
}

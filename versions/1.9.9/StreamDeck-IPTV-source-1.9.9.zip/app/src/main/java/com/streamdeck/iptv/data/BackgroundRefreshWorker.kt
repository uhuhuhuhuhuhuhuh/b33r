package com.streamdeck.iptv.data

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

class BackgroundRefreshWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val updateManager = AppUpdateManager(applicationContext)
        val credentialStore = CredentialStore(applicationContext)
        val statusStore = BackgroundStatusStore(applicationContext)
        val notifications = BackgroundNotificationHelper(applicationContext)

        runCatching { updateManager.checkForUpdate() }
            .onSuccess { update ->
                statusStore.saveAvailableUpdate(update)
                if (update != null && !statusStore.hasNotifiedUpdate(update.versionCode)) {
                    notifications.notifyUpdate(update)
                    statusStore.markUpdateNotified(update.versionCode)
                }
            }

        val session = credentialStore.loadSession() ?: return Result.success()
        if (session.expired) {
            expireSession(session.accountUsername, session.expiresAtEpochSeconds, credentialStore, statusStore, notifications)
            return Result.success()
        }

        runCatching { XtreamApi().authenticate(session.credentials) }
            .onSuccess { account ->
                credentialStore.save(session.credentials, account)
                statusStore.clearExpiredAccountNotice()
            }
            .onFailure { error ->
                if (error is AccountExpiredException || session.expired) {
                    expireSession(
                        username = session.accountUsername,
                        expiresAtEpochSeconds = session.expiresAtEpochSeconds,
                        credentialStore = credentialStore,
                        statusStore = statusStore,
                        notifications = notifications,
                    )
                }
            }

        return Result.success()
    }

    private fun expireSession(
        username: String,
        expiresAtEpochSeconds: Long?,
        credentialStore: CredentialStore,
        statusStore: BackgroundStatusStore,
        notifications: BackgroundNotificationHelper,
    ) {
        credentialStore.clear()
        statusStore.saveAccountExpired(username, expiresAtEpochSeconds)
        if (!statusStore.hasNotifiedExpired(expiresAtEpochSeconds)) {
            notifications.notifyExpired(username)
            statusStore.markExpiredNotified(expiresAtEpochSeconds)
        }
    }
}

object BackgroundRefreshScheduler {
    private const val PERIODIC_WORK = "background_refresh"
    private const val IMMEDIATE_WORK = "background_refresh_once"

    fun schedule(context: Context) {
        val appContext = context.applicationContext
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val periodic = PeriodicWorkRequestBuilder<BackgroundRefreshWorker>(
            6,
            TimeUnit.HOURS,
        )
            .setConstraints(constraints)
            .build()

        val workManager = WorkManager.getInstance(appContext)
        workManager.enqueueUniquePeriodicWork(
            PERIODIC_WORK,
            ExistingPeriodicWorkPolicy.UPDATE,
            periodic,
        )
        // The foreground view model already performs this refresh at launch.
        // Removing the old one-time job prevents duplicate update/auth traffic
        // while the first catalog is loading on memory-constrained TV boxes.
        workManager.cancelUniqueWork(IMMEDIATE_WORK)
    }
}

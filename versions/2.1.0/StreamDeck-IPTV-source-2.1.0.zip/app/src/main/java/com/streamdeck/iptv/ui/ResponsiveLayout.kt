package com.streamdeck.iptv.ui

import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalWindowInfo
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.min
import kotlin.math.roundToInt

internal enum class B33rWindowClass {
    COMPACT,
    MEDIUM,
    EXPANDED,
    TELEVISION,
}

internal data class ResponsiveScaleProfile(
    val isTelevision: Boolean,
    val uiScale: Float,
    val textScale: Float,
    val shortestWidthDp: Int,
    val windowWidthDp: Int,
    val windowHeightDp: Int,
    val windowClass: B33rWindowClass,
)

internal data class ResponsiveLayout(
    val isTelevision: Boolean,
    val windowClass: B33rWindowClass,
    val windowWidthDp: Int,
    val windowHeightDp: Int,
    val uiScale: Float,
    val textScale: Float,
    val pagePadding: Dp,
    val gridCardWidth: Dp,
    val gridSpacing: Dp,
    val railWidth: Dp,
    val loginMaxWidth: Dp,
    val playerPadding: Dp,
    val playerButtonSize: Dp,
    val playerIconSize: Dp,
) {
    val isCompact: Boolean get() = windowClass == B33rWindowClass.COMPACT
    val isMedium: Boolean get() = windowClass == B33rWindowClass.MEDIUM
    val isExpanded: Boolean get() = windowClass == B33rWindowClass.EXPANDED
}

private val LocalResponsiveScaleProfile = compositionLocalOf {
    ResponsiveScaleProfile(
        isTelevision = false,
        uiScale = 1f,
        textScale = 1f,
        shortestWidthDp = 360,
        windowWidthDp = 360,
        windowHeightDp = 640,
        windowClass = B33rWindowClass.COMPACT,
    )
}

/**
 * Provides adaptive window information without replacing Compose density.
 *
 * B33R 2.0 scaled the full composition tree, which could partially cancel the
 * user's system font-size preference and shrink touch targets. 2.1 keeps the
 * platform density/font scale intact and adapts component dimensions instead.
 */
@Composable
internal fun ProvideResponsiveScaling(content: @Composable () -> Unit) {
    val context = LocalContext.current
    val configuration = LocalConfiguration.current
    val density = LocalDensity.current
    val windowSize = LocalWindowInfo.current.containerSize
    val widthPx = windowSize.width.takeIf { it > 0 }
        ?: context.resources.displayMetrics.widthPixels
    val heightPx = windowSize.height.takeIf { it > 0 }
        ?: context.resources.displayMetrics.heightPixels
    val widthDp = (widthPx / density.density).roundToInt().coerceAtLeast(1)
    val heightDp = (heightPx / density.density).roundToInt().coerceAtLeast(1)
    val television = remember(context, configuration.uiMode) {
        isTelevisionDevice(context, configuration)
    }
    val profile = remember(television, widthDp, heightDp) {
        calculateResponsiveScaleProfile(
            isTelevision = television,
            shortestWidthDp = min(widthDp, heightDp),
            physicalShortSidePx = min(widthPx, heightPx),
            windowShortSidePx = min(widthPx, heightPx),
            windowWidthDp = widthDp,
            windowHeightDp = heightDp,
        )
    }

    CompositionLocalProvider(
        LocalResponsiveScaleProfile provides profile,
        content = content,
    )
}

internal fun calculateResponsiveScaleProfile(
    isTelevision: Boolean,
    shortestWidthDp: Int,
    physicalShortSidePx: Int,
    windowShortSidePx: Int = physicalShortSidePx,
    windowWidthDp: Int = shortestWidthDp,
    windowHeightDp: Int = shortestWidthDp,
): ResponsiveScaleProfile {
    // Retained parameters keep compatibility with previous unit tests and call
    // sites. Window classes, not physical display identity, now drive layout.
    @Suppress("UNUSED_VARIABLE")
    val ignoredPhysicalPixels = min(physicalShortSidePx, windowShortSidePx)
    val windowClass = when {
        isTelevision -> B33rWindowClass.TELEVISION
        windowWidthDp >= 840 && windowHeightDp >= 480 -> B33rWindowClass.EXPANDED
        windowWidthDp >= 600 && windowHeightDp >= 480 -> B33rWindowClass.MEDIUM
        else -> B33rWindowClass.COMPACT
    }
    return ResponsiveScaleProfile(
        isTelevision = isTelevision,
        uiScale = 1f,
        textScale = 1f,
        shortestWidthDp = shortestWidthDp,
        windowWidthDp = windowWidthDp,
        windowHeightDp = windowHeightDp,
        windowClass = windowClass,
    )
}

@Composable
internal fun rememberResponsiveLayout(): ResponsiveLayout {
    val profile = LocalResponsiveScaleProfile.current
    return remember(profile) {
        ResponsiveLayout(
            isTelevision = profile.isTelevision,
            windowClass = profile.windowClass,
            windowWidthDp = profile.windowWidthDp,
            windowHeightDp = profile.windowHeightDp,
            uiScale = 1f,
            textScale = 1f,
            pagePadding = when (profile.windowClass) {
                B33rWindowClass.TELEVISION -> 16.dp
                B33rWindowClass.EXPANDED -> 16.dp
                B33rWindowClass.MEDIUM -> 14.dp
                B33rWindowClass.COMPACT -> 12.dp
            },
            gridCardWidth = when (profile.windowClass) {
                B33rWindowClass.TELEVISION -> 148.dp
                B33rWindowClass.EXPANDED -> 156.dp
                B33rWindowClass.MEDIUM -> 146.dp
                B33rWindowClass.COMPACT -> 126.dp
            },
            gridSpacing = when (profile.windowClass) {
                B33rWindowClass.TELEVISION -> 12.dp
                B33rWindowClass.EXPANDED -> 12.dp
                else -> 10.dp
            },
            railWidth = if (profile.isTelevision) 92.dp else 84.dp,
            loginMaxWidth = when (profile.windowClass) {
                B33rWindowClass.TELEVISION -> 540.dp
                B33rWindowClass.EXPANDED -> 500.dp
                B33rWindowClass.MEDIUM -> 460.dp
                B33rWindowClass.COMPACT -> 420.dp
            },
            playerPadding = if (profile.isTelevision) 10.dp else 8.dp,
            // Never drop touch controls below Android's recommended 48dp.
            playerButtonSize = if (profile.isTelevision) 52.dp else 48.dp,
            playerIconSize = if (profile.isTelevision) 30.dp else 28.dp,
        )
    }
}

internal fun shouldUseNavigationRail(
    isTelevision: Boolean,
    widthDp: Float,
    heightDp: Float,
): Boolean = isTelevision || (widthDp >= 600f && heightDp >= 480f)

internal fun scaledDensityDpi(baseDensityDpi: Int, scale: Float): Int =
    (baseDensityDpi.coerceAtLeast(1) * scale.coerceIn(0.85f, 1.60f))
        .roundToInt()
        .coerceAtLeast(1)

internal fun createScaledAndroidViewContext(
    context: Context,
    uiScale: Float,
    textScale: Float,
): Context {
    // Android Views now use the same unmodified density/font scale as Compose.
    @Suppress("UNUSED_VARIABLE")
    val compatibility = uiScale + textScale
    return context
}

internal fun ResponsiveLayout.dp(value: Float): Dp = value.dp
internal fun ResponsiveLayout.sp(value: Float): TextUnit = value.sp

private fun isTelevisionDevice(
    context: Context,
    configuration: Configuration,
): Boolean {
    val uiModeIsTelevision =
        configuration.uiMode and Configuration.UI_MODE_TYPE_MASK ==
            Configuration.UI_MODE_TYPE_TELEVISION
    val packageManager = context.packageManager
    return uiModeIsTelevision ||
        packageManager.hasSystemFeature(PackageManager.FEATURE_LEANBACK) ||
        packageManager.hasSystemFeature(PackageManager.FEATURE_TELEVISION)
}

package com.streamdeck.iptv.data

import java.util.UUID

/** Top-level destinations shared by the television rail and mobile bottom navigation. */
enum class ProDestination(val title: String) {
    GUIDE("Guide"),
    MOVIES("Movies"),
    SERIES("Series"),
    FAVORITES("Favorites"),
    CONTINUE("Continue"),
    RECORDINGS("Recordings"),
    MULTIVIEW("Multiview"),
    SEARCH("Search"),
    PLAYLISTS("Playlists"),
    PROFILES("Profiles"),
    SETTINGS("Settings"),
}

data class EpgProgram(
    val id: String,
    val channelStreamId: String,
    val title: String,
    val description: String = "",
    val startEpochSeconds: Long,
    val endEpochSeconds: Long,
    val hasArchive: Boolean = false,
) {
    val durationSeconds: Long
        get() = (endEpochSeconds - startEpochSeconds).coerceAtLeast(1L)

    fun progress(nowEpochSeconds: Long = currentEpochSeconds()): Float =
        ((nowEpochSeconds - startEpochSeconds).toFloat() / durationSeconds.toFloat())
            .coerceIn(0f, 1f)

    val isLiveNow: Boolean
        get() {
            val now = currentEpochSeconds()
            return now in startEpochSeconds until endEpochSeconds
        }
}

data class GuideChannel(
    val item: StreamItem,
    val categoryId: String? = null,
    val programs: List<EpgProgram> = emptyList(),
)

data class GuideWindow(
    val startEpochSeconds: Long,
    val endEpochSeconds: Long,
    val channels: List<GuideChannel>,
)

data class PlaylistAccount(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val baseUrl: String,
    val username: String,
    val password: String,
    val enabled: Boolean = true,
    val lastSuccessfulRefreshEpochSeconds: Long? = null,
)

data class UserProfile(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val pinHash: String? = null,
    val kidsMode: Boolean = false,
    val lockedChannelIds: Set<String> = emptySet(),
    val lockedCategoryIds: Set<String> = emptySet(),
    val hiddenChannelIds: Set<String> = emptySet(),
    val hiddenCategoryIds: Set<String> = emptySet(),
)

enum class GuideDensity { COMPACT, BALANCED, COMFORTABLE }
enum class PlayerEnginePreference { AUTOMATIC, MEDIA3, VLC, EXTERNAL }
enum class SubtitleMode { OFF, AUTO_FORCED, ON }
enum class RecordingStatus { SCHEDULED, RECORDING, COMPLETE, FAILED, CANCELLED }

data class PlaybackPreferences(
    val engine: PlayerEnginePreference = PlayerEnginePreference.AUTOMATIC,
    val bufferSeconds: Int = 18,
    val timeshiftMinutes: Int = 30,
    val matchFrameRate: Boolean = true,
    val preferHardwareDecoding: Boolean = true,
    val passthroughAudio: Boolean = false,
    val audioDelayMs: Int = 0,
    val subtitleDelayMs: Int = 0,
    val subtitleScalePercent: Int = 100,
    val subtitleMode: SubtitleMode = SubtitleMode.AUTO_FORCED,
    val preferDeviceLanguage: Boolean = true,
    val preferredAudioLanguageTags: List<String> = emptyList(),
    val preferredSubtitleLanguageTags: List<String> = emptyList(),
    val maxVideoHeight: Int? = null,
    val autoPlayNextEpisode: Boolean = true,
    val externalPlayerPackage: String? = null,
)

data class AppearancePreferences(
    val guideDensity: GuideDensity = GuideDensity.COMPACT,
    val showChannelNumbers: Boolean = true,
    val showChannelLogos: Boolean = true,
    val use24HourClock: Boolean = false,
    val animationsEnabled: Boolean = true,
    val previewEnabled: Boolean = true,
    val accentArgb: Long = 0xFFF2A900,
)

data class ParentalPreferences(
    val adultNameFiltering: Boolean = true,
    val requirePinForSettings: Boolean = false,
    val requirePinForLockedContent: Boolean = true,
)

data class B33rPreferences(
    val playback: PlaybackPreferences = PlaybackPreferences(),
    val appearance: AppearancePreferences = AppearancePreferences(),
    val parental: ParentalPreferences = ParentalPreferences(),
    val recordingPaddingStartMinutes: Int = 2,
    val recordingPaddingEndMinutes: Int = 5,
)

data class ScheduledRecording(
    val id: String = UUID.randomUUID().toString(),
    val channel: StreamItem,
    val program: EpgProgram? = null,
    val title: String = program?.title ?: channel.name,
    val startEpochSeconds: Long,
    val endEpochSeconds: Long,
    val status: RecordingStatus = RecordingStatus.SCHEDULED,
    val playlistId: String? = null,
    val outputPath: String? = null,
    val errorMessage: String? = null,
    val createdAtEpochSeconds: Long = currentEpochSeconds(),
)

data class ProgramReminder(
    val id: String = UUID.randomUUID().toString(),
    val channel: StreamItem,
    val program: EpgProgram,
    val notifyAtEpochSeconds: Long,
)

data class MultiviewSlot(
    val slot: Int,
    val channel: StreamItem,
    val sources: List<String>,
)

data class MultiviewLayoutState(
    val slots: List<MultiviewSlot> = emptyList(),
    val activeAudioSlot: Int = 0,
) {
    val capacity: Int = 4
}

data class ChannelCustomization(
    val streamId: String,
    val customName: String? = null,
    val customGroup: String? = null,
    val hidden: Boolean = false,
    val order: Int? = null,
    val logoUrl: String? = null,
    val epgChannelId: String? = null,
    val epgOffsetMinutes: Int = 0,
)

/** Persistent playback policy for one provider stream. Null fields inherit global preferences. */
data class ChannelPlaybackOverride(
    val streamId: String,
    val engine: PlayerEnginePreference? = null,
    val preferredSourceIndex: Int? = null,
    val bufferSeconds: Int? = null,
    val preferHardwareDecoding: Boolean? = null,
    val passthroughAudio: Boolean? = null,
    val subtitleMode: SubtitleMode? = null,
    val audioDelayMs: Int? = null,
    val subtitleDelayMs: Int? = null,
    val maxVideoHeight: Int? = null,
)

fun PlaybackPreferences.withChannelOverride(
    override: ChannelPlaybackOverride?,
): PlaybackPreferences {
    if (override == null) return this
    return copy(
        engine = override.engine ?: engine,
        bufferSeconds = override.bufferSeconds?.coerceIn(3, 120) ?: bufferSeconds,
        preferHardwareDecoding = override.preferHardwareDecoding ?: preferHardwareDecoding,
        passthroughAudio = override.passthroughAudio ?: passthroughAudio,
        subtitleMode = override.subtitleMode ?: subtitleMode,
        audioDelayMs = override.audioDelayMs ?: audioDelayMs,
        subtitleDelayMs = override.subtitleDelayMs ?: subtitleDelayMs,
        maxVideoHeight = override.maxVideoHeight ?: maxVideoHeight,
    )
}

data class ProUiState(
    val destination: ProDestination = ProDestination.GUIDE,
    val guideLoading: Boolean = false,
    val guideError: String? = null,
    val guideCategoryId: String? = null,
    val guideWindow: GuideWindow? = null,
    val selectedGuideChannelId: String? = null,
    val selectedProgramId: String? = null,
    val globalSearchQuery: String = "",
    val globalSearchResults: List<StreamItem> = emptyList(),
    val recordings: List<ScheduledRecording> = emptyList(),
    val reminders: List<ProgramReminder> = emptyList(),
    val multiview: MultiviewLayoutState = MultiviewLayoutState(),
    val profiles: List<UserProfile> = listOf(UserProfile(id = "default", name = "Default")),
    val activeProfileId: String = "default",
    val playlists: List<PlaylistAccount> = emptyList(),
    val activePlaylistId: String? = null,
    val preferences: B33rPreferences = B33rPreferences(),
    val customizations: Map<String, ChannelCustomization> = emptyMap(),
    val channelPlaybackOverrides: Map<String, ChannelPlaybackOverride> = emptyMap(),
    val message: String? = null,
)

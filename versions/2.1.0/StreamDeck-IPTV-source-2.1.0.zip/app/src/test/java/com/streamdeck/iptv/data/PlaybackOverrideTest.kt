package com.streamdeck.iptv.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test

class PlaybackOverrideTest {
    @Test
    fun channelOverrideWinsWithoutErasingInheritedValues() {
        val global = PlaybackPreferences(
            engine = PlayerEnginePreference.MEDIA3,
            bufferSeconds = 12,
            preferHardwareDecoding = true,
            subtitleMode = SubtitleMode.OFF,
            maxVideoHeight = null,
        )
        val resolved = global.withChannelOverride(
            ChannelPlaybackOverride(
                streamId = "42",
                engine = PlayerEnginePreference.VLC,
                bufferSeconds = 30,
                preferHardwareDecoding = false,
                subtitleMode = SubtitleMode.AUTO_FORCED,
                maxVideoHeight = 1080,
            ),
        )

        assertEquals(PlayerEnginePreference.VLC, resolved.engine)
        assertEquals(30, resolved.bufferSeconds)
        assertFalse(resolved.preferHardwareDecoding)
        assertEquals(SubtitleMode.AUTO_FORCED, resolved.subtitleMode)
        assertEquals(1080, resolved.maxVideoHeight)
        assertEquals(global.passthroughAudio, resolved.passthroughAudio)
    }
}

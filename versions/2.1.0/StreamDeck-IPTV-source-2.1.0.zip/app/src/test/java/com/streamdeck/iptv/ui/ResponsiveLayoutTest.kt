package com.streamdeck.iptv.ui

import org.junit.Assert.assertEquals
import org.junit.Test

class ResponsiveLayoutTest {
    @Test
    fun televisionAlwaysUsesTelevisionClass() {
        val profile = calculateResponsiveScaleProfile(
            isTelevision = true,
            shortestWidthDp = 720,
            physicalShortSidePx = 1080,
            windowWidthDp = 960,
            windowHeightDp = 540,
        )
        assertEquals(B33rWindowClass.TELEVISION, profile.windowClass)
    }

    @Test
    fun windowClassesFollowAvailableWindow() {
        assertEquals(
            B33rWindowClass.COMPACT,
            calculateResponsiveScaleProfile(false, 360, 1080, windowWidthDp = 360, windowHeightDp = 800).windowClass,
        )
        assertEquals(
            B33rWindowClass.MEDIUM,
            calculateResponsiveScaleProfile(false, 700, 1400, windowWidthDp = 700, windowHeightDp = 900).windowClass,
        )
        assertEquals(
            B33rWindowClass.EXPANDED,
            calculateResponsiveScaleProfile(false, 700, 1400, windowWidthDp = 1000, windowHeightDp = 700).windowClass,
        )
    }
}

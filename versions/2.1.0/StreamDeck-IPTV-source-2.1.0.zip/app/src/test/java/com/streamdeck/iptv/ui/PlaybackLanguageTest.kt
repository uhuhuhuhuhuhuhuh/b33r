package com.streamdeck.iptv.ui

import org.junit.Assert.assertEquals
import org.junit.Test

class PlaybackLanguageTest {
    @Test
    fun forcedTrackPrefersMatchingDeviceLanguage() {
        val preference = PlaybackLanguagePreference(
            media3LanguageTags = listOf("es-US", "es"),
            vlcLanguageTokens = listOf("es-US", "es", "spa"),
            trackNameHints = listOf("spanish", "es", "spa"),
        )
        val choices = listOf(
            1 to "English Forced",
            2 to "Spanish Forced",
            3 to "Spanish",
        )

        assertEquals(2, preferredForcedVlcTrackId(choices, preference))
    }
}

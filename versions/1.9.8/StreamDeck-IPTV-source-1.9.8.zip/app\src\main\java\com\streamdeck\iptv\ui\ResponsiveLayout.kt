package com.streamdeck.iptv.ui

import android.content.res.Configuration
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.max
import kotlin.math.min

internal data class ResponsiveLayout(
    val isTelevision: Boolean,
    val scale: Float,
    val fontScale: Float,
    val pagePadding: Dp,
    val gridCardWidth: Dp,
    val gridSpacing: Dp,
    val railWidth: Dp,
    val loginMaxWidth: Dp,
    val playerPadding: Dp,
    val playerButtonSize: Dp,
    val playerIconSize: Dp,
)

@Composable
internal fun rememberResponsiveLayout(): ResponsiveLayout {
    val configuration = LocalConfiguration.current
    val metrics = LocalContext.current.resources.displayMetrics
    val longPx = max(metrics.widthPixels, metrics.heightPixels)
    val shortPx = min(metrics.widthPixels, metrics.heightPixels)
    val longDp = max(configuration.screenWidthDp, configuration.screenHeightDp)
    val shortDp = min(configuration.screenWidthDp, configuration.screenHeightDp)
    val isTelevision =
        configuration.uiMode and Configuration.UI_MODE_TYPE_MASK ==
            Configuration.UI_MODE_TYPE_TELEVISION

    val scale = if (isTelevision) {
        when {
            longPx >= 3_500 -> 1.24f
            longPx >= 2_500 -> 1.14f
            longPx >= 1_800 -> 1.00f
            longPx >= 1_200 -> 0.90f
            else -> 0.84f
        }
    } else {
        when {
            shortDp >= 840 -> 1.16f
            shortDp >= 600 -> 1.08f
            longPx >= 2_700 && shortDp >= 390 -> 1.04f
            shortDp <= 360 || shortPx <= 720 -> 0.90f
            longDp <= 760 -> 0.94f
            else -> 1.00f
        }
    }

    val fontScale = if (isTelevision) {
        scale.coerceIn(0.92f, 1.18f)
    } else {
        scale.coerceIn(0.92f, 1.10f)
    }
    val gridBase = when {
        isTelevision -> 178f
        shortDp >= 600 -> 172f
        else -> 142f
    }

    return ResponsiveLayout(
        isTelevision = isTelevision,
        scale = scale,
        fontScale = fontScale,
        pagePadding = scaledDp(if (isTelevision) 20f else 16f, scale),
        gridCardWidth = scaledDp(
            value = (gridBase * scale).coerceIn(
                minimumValue = if (isTelevision) 150f else 128f,
                maximumValue = if (isTelevision) 248f else 210f,
            ),
            scale = 1f,
        ),
        gridSpacing = scaledDp(if (isTelevision) 18f else 14f, scale),
        railWidth = scaledDp(104f, scale).coerceIn(92.dp, 138.dp),
        loginMaxWidth = scaledDp(if (isTelevision) 520f else 460f, scale)
            .coerceIn(420.dp, if (isTelevision) 660.dp else 560.dp),
        playerPadding = scaledDp(if (isTelevision) 12f else 10f, scale),
        playerButtonSize = scaledDp(if (isTelevision) 48f else 44f, scale)
            .coerceIn(42.dp, 62.dp),
        playerIconSize = scaledDp(if (isTelevision) 32f else 30f, scale)
            .coerceIn(26.dp, 42.dp),
    )
}

internal fun ResponsiveLayout.dp(value: Float): Dp = scaledDp(value, scale)

internal fun ResponsiveLayout.sp(value: Float): TextUnit = (value * fontScale).sp

private fun scaledDp(value: Float, scale: Float): Dp = (value * scale).dp

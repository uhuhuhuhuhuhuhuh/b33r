package com.streamdeck.iptv.data

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Environment
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.ForegroundInfo
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.streamdeck.iptv.MainActivity
import com.streamdeck.iptv.R
import java.io.File
import java.io.FileOutputStream
import java.net.URI
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

object RecordingScheduler {
    fun schedule(context: Context, recording: ScheduledRecording) {
        val now = currentEpochSeconds()
        val delaySeconds = (recording.startEpochSeconds - now).coerceAtLeast(0L)
        val request = OneTimeWorkRequestBuilder<IptvRecordingWorker>()
            .setInitialDelay(delaySeconds, TimeUnit.SECONDS)
            .setInputData(Data.Builder().putString(KEY_RECORDING_ID, recording.id).build())
            .addTag(TAG_RECORDING)
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            uniqueName(recording.id),
            ExistingWorkPolicy.REPLACE,
            request,
        )
    }

    fun cancel(context: Context, recordingId: String) {
        WorkManager.getInstance(context).cancelUniqueWork(uniqueName(recordingId))
    }

    private fun uniqueName(id: String) = "b33r-recording-$id"
    const val KEY_RECORDING_ID = "recording_id"
    const val TAG_RECORDING = "b33r-recording"
}

class IptvRecordingWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .build()

    override suspend fun doWork(): Result {
        val id = inputData.getString(RecordingScheduler.KEY_RECORDING_ID) ?: return Result.failure()
        val store = FeatureStore(applicationContext)
        val playlistStore = SecurePlaylistStore(applicationContext)
        val recording = store.loadRecordings().firstOrNull { it.id == id } ?: return Result.failure()
        if (recording.status == RecordingStatus.CANCELLED) return Result.success()

        val credentials = recording.playlistId
            ?.let { playlistId -> playlistStore.load().firstOrNull { it.id == playlistId } }
            ?.let { Credentials(it.username, it.password, it.baseUrl) }
            ?: CredentialStore(applicationContext).load()
            ?: return fail(store, recording, "The playlist credentials are unavailable.")

        val now = currentEpochSeconds()
        if (recording.endEpochSeconds <= now) {
            return fail(store, recording, "The recording window has already ended.")
        }

        val outputDirectory = File(
            applicationContext.getExternalFilesDir(Environment.DIRECTORY_MOVIES),
            "B33R Recordings",
        ).apply { mkdirs() }
        val extension = if (recording.channel.extension.equals("m3u8", true)) "ts" else
            recording.channel.extension.ifBlank { "ts" }.replace(Regex("[^A-Za-z0-9]"), "")
                .ifBlank { "ts" }
        val output = File(outputDirectory, "${safeFileName(recording.title)}-${recording.id.take(8)}.$extension")
        update(store, recording.copy(status = RecordingStatus.RECORDING, outputPath = output.absolutePath))
        setForeground(createForegroundInfo(recording.title, 0))

        return try {
            val url = XtreamApi().playbackUrls(credentials, recording.channel).first()
            if (url.contains(".m3u8", true) || url.contains("format=m3u8", true)) {
                recordHls(url, output, recording.endEpochSeconds, recording.title)
            } else {
                recordProgressive(url, output, recording.endEpochSeconds, recording.title)
            }
            update(
                store,
                recording.copy(
                    status = RecordingStatus.COMPLETE,
                    outputPath = output.absolutePath,
                    errorMessage = null,
                ),
            )
            showCompletionNotification(recording.title, output)
            Result.success()
        } catch (error: CancellationException) {
            update(store, recording.copy(status = RecordingStatus.CANCELLED, outputPath = output.absolutePath))
            throw error
        } catch (error: Exception) {
            output.takeIf { it.length() == 0L }?.delete()
            fail(store, recording.copy(outputPath = output.takeIf(File::exists)?.absolutePath), error.message ?: "Recording failed.")
        }
    }

    private suspend fun recordProgressive(
        url: String,
        output: File,
        endEpochSeconds: Long,
        title: String,
    ) = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "B33R-IPTV/2.0")
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Provider returned HTTP ${response.code}.")
            val body = response.body ?: error("Provider returned an empty stream.")
            body.byteStream().use { input ->
                FileOutputStream(output, true).use { sink ->
                    val buffer = ByteArray(128 * 1024)
                    var lastNotification = 0L
                    while (currentEpochSeconds() < endEpochSeconds) {
                        ensureActive()
                        val read = input.read(buffer)
                        if (read < 0) break
                        sink.write(buffer, 0, read)
                        val now = currentEpochSeconds()
                        if (now - lastNotification >= 20) {
                            lastNotification = now
                            val progress = recordingProgress(endEpochSeconds)
                            setForeground(createForegroundInfo(title, progress))
                        }
                    }
                    sink.flush()
                }
            }
        }
    }

    private suspend fun recordHls(
        playlistUrl: String,
        output: File,
        endEpochSeconds: Long,
        title: String,
    ) = withContext(Dispatchers.IO) {
        val downloaded = linkedSetOf<String>()
        var mediaPlaylistUrl = playlistUrl
        var idlePolls = 0
        FileOutputStream(output, true).use { sink ->
            while (currentEpochSeconds() < endEpochSeconds) {
                ensureActive()
                val playlistText = downloadText(mediaPlaylistUrl)
                val lines = playlistText.lineSequence().map(String::trim).filter(String::isNotBlank).toList()
                val variant = lines.firstOrNull { !it.startsWith("#") }
                if (lines.any { it.startsWith("#EXT-X-STREAM-INF") } && variant != null) {
                    mediaPlaylistUrl = resolve(mediaPlaylistUrl, variant)
                    continue
                }
                val segments = lines.filter { !it.startsWith("#") }
                    .map { resolve(mediaPlaylistUrl, it) }
                var wrote = false
                for (segment in segments) {
                    if (!downloaded.add(segment)) continue
                    ensureActive()
                    downloadBytes(segment).use { input -> input.copyTo(sink, 128 * 1024) }
                    sink.flush()
                    wrote = true
                    setForeground(createForegroundInfo(title, recordingProgress(endEpochSeconds)))
                }
                idlePolls = if (wrote) 0 else idlePolls + 1
                if (lines.any { it == "#EXT-X-ENDLIST" }) break
                delay(if (idlePolls > 4) 4_000L else 2_000L)
            }
        }
    }

    private fun downloadText(url: String): String {
        val request = Request.Builder().url(url).header("User-Agent", "B33R-IPTV/2.0").build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Playlist returned HTTP ${response.code}.")
            return response.body?.string() ?: error("Playlist was empty.")
        }
    }

    private fun downloadBytes(url: String) =
        client.newCall(Request.Builder().url(url).header("User-Agent", "B33R-IPTV/2.0").build())
            .execute().let { response ->
                if (!response.isSuccessful) {
                    response.close()
                    error("Segment returned HTTP ${response.code}.")
                }
                response.body?.byteStream() ?: run {
                    response.close()
                    error("Segment was empty.")
                }
            }

    private fun resolve(base: String, child: String): String = URI(base).resolve(child).toString()

    private fun update(store: FeatureStore, updated: ScheduledRecording) {
        val recordings = store.loadRecordings().map { if (it.id == updated.id) updated else it }
        store.saveRecordings(recordings)
    }

    private fun fail(
        store: FeatureStore,
        recording: ScheduledRecording,
        message: String,
    ): Result {
        update(store, recording.copy(status = RecordingStatus.FAILED, errorMessage = message))
        return Result.failure(Data.Builder().putString("error", message).build())
    }

    private fun recordingProgress(endEpochSeconds: Long): Int {
        val remaining = (endEpochSeconds - currentEpochSeconds()).coerceAtLeast(0L)
        val estimatedTotal = 60L * 60L
        return (100 - (remaining * 100L / estimatedTotal).coerceIn(0L, 100L)).toInt()
    }

    private fun createForegroundInfo(title: String, progress: Int): ForegroundInfo {
        ensureNotificationChannel()
        val intent = Intent(applicationContext, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            applicationContext,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or immutableFlag(),
        )
        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_RECORDINGS)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Recording $title")
            .setContentText("B33R IPTV is saving the live stream.")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(100, progress, progress <= 0)
            .setContentIntent(pendingIntent)
            .build()
        return ForegroundInfo((title.hashCode() and 0x7fffffff).coerceAtLeast(10_000), notification)
    }

    private fun showCompletionNotification(title: String, output: File) {
        ensureNotificationChannel()
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(
            (output.absolutePath.hashCode() and 0x7fffffff).coerceAtLeast(20_000),
            NotificationCompat.Builder(applicationContext, CHANNEL_RECORDINGS)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("Recording complete")
                .setContentText(title)
                .setAutoCancel(true)
                .build(),
        )
    }

    private fun ensureNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_RECORDINGS,
                "IPTV recordings",
                NotificationManager.IMPORTANCE_LOW,
            ),
        )
    }

    private fun safeFileName(value: String): String = value
        .replace(Regex("[\\\\/:*?\"<>|]"), "-")
        .replace(Regex("\\s+"), " ")
        .trim()
        .take(100)
        .ifBlank { "B33R Recording" }

    private fun immutableFlag(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0

    private companion object {
        const val CHANNEL_RECORDINGS = "b33r_recordings"
    }
}

object ReminderScheduler {
    fun schedule(context: Context, reminder: ProgramReminder) {
        val delaySeconds = (reminder.notifyAtEpochSeconds - currentEpochSeconds()).coerceAtLeast(0L)
        val request = OneTimeWorkRequestBuilder<ProgramReminderWorker>()
            .setInitialDelay(delaySeconds, TimeUnit.SECONDS)
            .setInputData(Data.Builder().putString(KEY_REMINDER_ID, reminder.id).build())
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            "b33r-reminder-${reminder.id}",
            ExistingWorkPolicy.REPLACE,
            request,
        )
    }

    fun cancel(context: Context, reminderId: String) {
        WorkManager.getInstance(context).cancelUniqueWork("b33r-reminder-$reminderId")
    }

    const val KEY_REMINDER_ID = "reminder_id"
}

class ProgramReminderWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val id = inputData.getString(ReminderScheduler.KEY_REMINDER_ID) ?: return Result.failure()
        val reminder = FeatureStore(applicationContext).loadReminders().firstOrNull { it.id == id }
            ?: return Result.success()
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_REMINDERS, "Programme reminders", NotificationManager.IMPORTANCE_HIGH),
            )
        }
        val pendingIntent = PendingIntent.getActivity(
            applicationContext,
            reminder.id.hashCode(),
            Intent(applicationContext, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0,
        )
        manager.notify(
            reminder.id.hashCode(),
            NotificationCompat.Builder(applicationContext, CHANNEL_REMINDERS)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(reminder.program.title)
                .setContentText("Starting soon on ${reminder.channel.name}")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .build(),
        )
        return Result.success()
    }

    private companion object {
        const val CHANNEL_REMINDERS = "b33r_programme_reminders"
    }
}

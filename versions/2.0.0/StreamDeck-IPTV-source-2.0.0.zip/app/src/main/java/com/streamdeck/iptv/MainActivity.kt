package com.streamdeck.iptv

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.app.PictureInPictureParams
import android.os.Bundle
import android.util.Rational
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.streamdeck.iptv.data.BackgroundRefreshScheduler
import com.streamdeck.iptv.ui.StreamDeckApp

class MainActivity : ComponentActivity() {
    private val viewModel: IptvViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        BackgroundRefreshScheduler.schedule(this)
        requestNotificationPermissionIfNeeded()
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING)
        enableEdgeToEdge()
        setContent {
            StreamDeckApp(viewModel)
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.resumePendingUpdateInstall()
        viewModel.refreshVisibleAccountInfo()
        viewModel.refreshFeatureState()
    }


    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && viewModel.state.playbackUrl != null) {
            runCatching {
                enterPictureInPictureMode(
                    PictureInPictureParams.Builder()
                        .setAspectRatio(Rational(16, 9))
                        .build(),
                )
            }
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return
        if (
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS,
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.POST_NOTIFICATIONS),
            NOTIFICATION_PERMISSION_REQUEST,
        )
    }

    private companion object {
        const val NOTIFICATION_PERMISSION_REQUEST = 42
    }
}

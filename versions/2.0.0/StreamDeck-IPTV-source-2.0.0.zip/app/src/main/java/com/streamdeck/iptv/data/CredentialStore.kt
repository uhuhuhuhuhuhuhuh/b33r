package com.streamdeck.iptv.data

import android.annotation.TargetApi
import android.content.Context
import android.os.Build
import android.security.KeyPairGeneratorSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONObject
import java.math.BigInteger
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.SecureRandom
import java.util.Calendar
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import javax.security.auth.x500.X500Principal

class CredentialStore(context: Context) {
    private val appContext = context.applicationContext
    private val preferences = appContext.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)

    fun save(credentials: Credentials): StoredSession =
        saveSession(
            StoredSession(
                sessionId = UUID.randomUUID().toString(),
                credentials = credentials,
                accountUsername = credentials.username,
                expiresAtEpochSeconds = null,
            ),
        )

    fun save(credentials: Credentials, account: AccountInfo): StoredSession =
        saveSession(
            StoredSession(
                sessionId = UUID.randomUUID().toString(),
                credentials = credentials,
                accountUsername = account.username,
                expiresAtEpochSeconds = account.expiresAtEpochSeconds,
            ),
        )

    fun saveSession(session: StoredSession): StoredSession = synchronized(STORAGE_LOCK) {
        saveSessionLocked(session)
        session
    }

    fun updateIfCurrent(session: StoredSession, account: AccountInfo): StoredSession? =
        synchronized(STORAGE_LOCK) {
            val current = loadSessionLocked() ?: return@synchronized null
            if (current.sessionId != session.sessionId) return@synchronized null
            val updated = current.copy(
                accountUsername = account.username,
                expiresAtEpochSeconds = account.expiresAtEpochSeconds,
            )
            saveSessionLocked(updated)
            updated
        }

    fun clearIfCurrent(sessionId: String): Boolean = synchronized(STORAGE_LOCK) {
        val current = loadSessionLocked() ?: return@synchronized false
        if (current.sessionId != sessionId) return@synchronized false
        clearLocked()
        true
    }

    private fun saveSessionLocked(session: StoredSession) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            saveModern(session)
        } else {
            saveLegacy(session)
        }
    }

    fun load(): Credentials? = loadSession()?.credentials

    fun loadSession(): StoredSession? = synchronized(STORAGE_LOCK) {
        loadSessionLocked()
    }

    private fun loadSessionLocked(): StoredSession? = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            loadModernSession() ?: loadLegacySession()?.also { legacySession ->
                saveModern(legacySession)
                clearLegacyPayloadLocked()
            }
        } else {
            loadLegacySession()
        }
    } catch (_: Exception) {
        // Keystore entries can be invalidated by an OS restore, lock-screen change,
        // or vendor firmware bug. Fail closed instead of crashing at startup.
        recoverFromStorageFailureLocked()
        null
    }

    private fun clearLegacyPayloadLocked() {
        preferences.edit()
            .remove(KEY_LEGACY_IV)
            .remove(KEY_LEGACY_CIPHERTEXT)
            .remove(KEY_WRAPPED_LEGACY_KEY)
            .commit()
        runCatching {
            KeyStore.getInstance(KEYSTORE_PROVIDER).apply {
                load(null)
                if (containsAlias(LEGACY_RSA_ALIAS)) deleteEntry(LEGACY_RSA_ALIAS)
            }
        }
    }

    fun clear() = synchronized(STORAGE_LOCK) {
        clearLocked()
    }

    private fun clearLocked() {
        preferences.edit().clear().commit()
    }

    @TargetApi(Build.VERSION_CODES.M)
    private fun saveModern(session: StoredSession) {
        val cipher = Cipher.getInstance(AES_TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateModernKey())
        saveEncryptedPayload(session, cipher, KEY_IV, KEY_CIPHERTEXT)
    }

    @TargetApi(Build.VERSION_CODES.M)
    private fun loadModernSession(): StoredSession? {
        val iv = preferences.getString(KEY_IV, null) ?: return null
        val ciphertext = preferences.getString(KEY_CIPHERTEXT, null) ?: return null
        return decryptPayload(iv, ciphertext, getOrCreateModernKey(), legacySessionId(iv, ciphertext))
    }

    private fun saveLegacy(session: StoredSession) {
        val cipher = Cipher.getInstance(AES_TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateLegacyKey())
        saveEncryptedPayload(
            session,
            cipher,
            KEY_LEGACY_IV,
            KEY_LEGACY_CIPHERTEXT,
        )
    }

    private fun loadLegacySession(): StoredSession? {
        val iv = preferences.getString(KEY_LEGACY_IV, null) ?: return null
        val ciphertext = preferences.getString(KEY_LEGACY_CIPHERTEXT, null) ?: return null
        return decryptPayload(iv, ciphertext, getOrCreateLegacyKey(), legacySessionId(iv, ciphertext))
    }

    private fun saveEncryptedPayload(
        session: StoredSession,
        cipher: Cipher,
        ivKey: String,
        ciphertextKey: String,
    ) {
        val plaintext = JSONObject()
            .put("sessionId", session.sessionId)
            .put("username", session.credentials.username)
            .put("password", session.credentials.password)
            .put("baseUrl", session.credentials.baseUrl)
            .put("accountUsername", session.accountUsername)
            .put("expiresAtEpochSeconds", session.expiresAtEpochSeconds)
            .toString()
            .toByteArray(Charsets.UTF_8)
        val encrypted = cipher.doFinal(plaintext)

        val saved = preferences.edit()
            .putString(ivKey, Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
            .putString(ciphertextKey, Base64.encodeToString(encrypted, Base64.NO_WRAP))
            .commit()
        check(saved) { "The secure session could not be saved." }
    }

    private fun decryptPayload(
        iv: String,
        ciphertext: String,
        key: SecretKey,
        fallbackSessionId: String,
    ): StoredSession? {
        val cipher = Cipher.getInstance(AES_TRANSFORMATION)
        cipher.init(
            Cipher.DECRYPT_MODE,
            key,
            GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)),
        )
        val json = JSONObject(
            cipher.doFinal(Base64.decode(ciphertext, Base64.NO_WRAP))
                .toString(Charsets.UTF_8),
        )
        val credentials = Credentials(
            username = json.getString("username"),
            password = json.getString("password"),
            baseUrl = json.optString("baseUrl").normalizeServerUrl(),
        )
        return StoredSession(
            sessionId = json.optString("sessionId").ifBlank { fallbackSessionId },
            credentials = credentials,
            accountUsername = json.optString("accountUsername").ifBlank {
                credentials.username
            },
            expiresAtEpochSeconds = if (
                json.has("expiresAtEpochSeconds") &&
                !json.isNull("expiresAtEpochSeconds")
            ) {
                json.optLong("expiresAtEpochSeconds").takeIf { it > 0L }
            } else {
                null
            },
        )
    }

    private fun legacySessionId(iv: String, ciphertext: String): String =
        UUID.nameUUIDFromBytes(
            "$iv:$ciphertext".toByteArray(Charsets.UTF_8),
        ).toString()

    private fun recoverFromStorageFailureLocked() {
        clearLocked()
        runCatching {
            KeyStore.getInstance(KEYSTORE_PROVIDER).apply {
                load(null)
                if (containsAlias(KEY_ALIAS)) deleteEntry(KEY_ALIAS)
                if (containsAlias(LEGACY_RSA_ALIAS)) deleteEntry(LEGACY_RSA_ALIAS)
            }
        }
    }

    @TargetApi(Build.VERSION_CODES.M)
    private fun getOrCreateModernKey(): SecretKey {
        val keyStore = KeyStore.getInstance(KEYSTORE_PROVIDER).apply { load(null) }
        (keyStore.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }

        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE_PROVIDER).run {
            init(
                KeyGenParameterSpec.Builder(
                    KEY_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
                )
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build(),
            )
            generateKey()
        }
    }

    @Suppress("DEPRECATION")
    private fun getOrCreateLegacyKey(): SecretKey {
        val keyStore = KeyStore.getInstance(KEYSTORE_PROVIDER).apply { load(null) }
        val wrappedKey = preferences.getString(KEY_WRAPPED_LEGACY_KEY, null)
        if (wrappedKey != null && keyStore.containsAlias(LEGACY_RSA_ALIAS)) {
            val privateKey = keyStore.getKey(LEGACY_RSA_ALIAS, null)
            val unwrapCipher = Cipher.getInstance(RSA_TRANSFORMATION)
            unwrapCipher.init(Cipher.DECRYPT_MODE, privateKey)
            return SecretKeySpec(
                unwrapCipher.doFinal(Base64.decode(wrappedKey, Base64.NO_WRAP)),
                AES_ALGORITHM,
            )
        }

        if (!keyStore.containsAlias(LEGACY_RSA_ALIAS)) {
            val start = Calendar.getInstance()
            val end = Calendar.getInstance().apply { add(Calendar.YEAR, 25) }
            val spec = KeyPairGeneratorSpec.Builder(appContext)
                .setAlias(LEGACY_RSA_ALIAS)
                .setSubject(X500Principal("CN=StreamDeck IPTV credentials"))
                .setSerialNumber(BigInteger.ONE)
                .setStartDate(start.time)
                .setEndDate(end.time)
                .build()
            KeyPairGenerator.getInstance(RSA_ALGORITHM, KEYSTORE_PROVIDER).run {
                initialize(spec)
                generateKeyPair()
            }
        }

        val keyBytes = ByteArray(32).also(SecureRandom()::nextBytes)
        val publicKey = keyStore.getCertificate(LEGACY_RSA_ALIAS).publicKey
        val wrapCipher = Cipher.getInstance(RSA_TRANSFORMATION)
        wrapCipher.init(Cipher.ENCRYPT_MODE, publicKey)
        val saved = preferences.edit()
            .putString(
                KEY_WRAPPED_LEGACY_KEY,
                Base64.encodeToString(wrapCipher.doFinal(keyBytes), Base64.NO_WRAP),
            )
            .commit()
        check(saved) { "The legacy credential key could not be saved." }
        return SecretKeySpec(keyBytes, AES_ALGORITHM)
    }

    private companion object {
        val STORAGE_LOCK = Any()
        const val PREFERENCES = "secure_session"
        const val KEY_IV = "iv"
        const val KEY_CIPHERTEXT = "ciphertext"
        const val KEY_LEGACY_IV = "legacy_iv"
        const val KEY_LEGACY_CIPHERTEXT = "legacy_ciphertext"
        const val KEY_WRAPPED_LEGACY_KEY = "legacy_wrapped_key"
        const val KEY_ALIAS = "streamdeck_credentials"
        const val LEGACY_RSA_ALIAS = "streamdeck_credentials_rsa"
        const val KEYSTORE_PROVIDER = "AndroidKeyStore"
        const val AES_ALGORITHM = "AES"
        const val RSA_ALGORITHM = "RSA"
        const val AES_TRANSFORMATION = "AES/GCM/NoPadding"
        const val RSA_TRANSFORMATION = "RSA/ECB/PKCS1Padding"
    }
}

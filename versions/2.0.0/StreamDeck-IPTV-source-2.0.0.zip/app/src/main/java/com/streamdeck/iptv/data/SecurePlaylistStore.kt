package com.streamdeck.iptv.data

import android.annotation.TargetApi
import android.content.Context
import android.os.Build
import android.security.KeyPairGeneratorSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.math.BigInteger
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.SecureRandom
import java.util.Calendar
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import javax.security.auth.x500.X500Principal

/**
 * Encrypted storage for multiple Xtream/M3U account profiles. Passwords never
 * appear in the ordinary preference XML and are not exported unless the user
 * explicitly enables credential export.
 */
class SecurePlaylistStore(context: Context) {
    private val appContext = context.applicationContext
    private val preferences = appContext.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)

    fun load(): List<PlaylistAccount> = synchronized(LOCK) {
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                loadModern() ?: loadLegacy()?.also { accounts ->
                    saveModern(accounts)
                    clearLegacyPayload()
                }
            } else {
                loadLegacy()
            }
        }.getOrElse {
            recover()
            emptyList()
        }.orEmpty()
    }

    fun save(accounts: List<PlaylistAccount>) = synchronized(LOCK) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) saveModern(accounts) else saveLegacy(accounts)
    }

    fun upsert(account: PlaylistAccount): List<PlaylistAccount> = synchronized(LOCK) {
        val accounts = load().filterNot { it.id == account.id }.toMutableList().apply { add(account) }
        save(accounts)
        accounts
    }

    fun remove(id: String): List<PlaylistAccount> = synchronized(LOCK) {
        val accounts = load().filterNot { it.id == id }
        save(accounts)
        accounts
    }

    @TargetApi(Build.VERSION_CODES.M)
    private fun saveModern(accounts: List<PlaylistAccount>) {
        val cipher = Cipher.getInstance(AES_TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateModernKey())
        saveEncrypted(accounts, cipher, KEY_IV, KEY_CIPHERTEXT)
    }

    @TargetApi(Build.VERSION_CODES.M)
    private fun loadModern(): List<PlaylistAccount>? {
        val iv = preferences.getString(KEY_IV, null) ?: return null
        val ciphertext = preferences.getString(KEY_CIPHERTEXT, null) ?: return null
        return decrypt(iv, ciphertext, getOrCreateModernKey())
    }

    private fun saveLegacy(accounts: List<PlaylistAccount>) {
        val cipher = Cipher.getInstance(AES_TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateLegacyKey())
        saveEncrypted(accounts, cipher, KEY_LEGACY_IV, KEY_LEGACY_CIPHERTEXT)
    }

    private fun loadLegacy(): List<PlaylistAccount>? {
        val iv = preferences.getString(KEY_LEGACY_IV, null) ?: return null
        val ciphertext = preferences.getString(KEY_LEGACY_CIPHERTEXT, null) ?: return null
        return decrypt(iv, ciphertext, getOrCreateLegacyKey())
    }

    private fun saveEncrypted(
        accounts: List<PlaylistAccount>,
        cipher: Cipher,
        ivKey: String,
        ciphertextKey: String,
    ) {
        val array = JSONArray()
        accounts.forEach { account ->
            array.put(
                JSONObject()
                    .put("id", account.id)
                    .put("name", account.name)
                    .put("baseUrl", account.baseUrl.normalizeServerUrl())
                    .put("username", account.username)
                    .put("password", account.password)
                    .put("enabled", account.enabled)
                    .put("lastSuccessfulRefreshEpochSeconds", account.lastSuccessfulRefreshEpochSeconds),
            )
        }
        val encrypted = cipher.doFinal(array.toString().toByteArray(Charsets.UTF_8))
        check(
            preferences.edit()
                .putString(ivKey, Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
                .putString(ciphertextKey, Base64.encodeToString(encrypted, Base64.NO_WRAP))
                .commit(),
        ) { "Playlist accounts could not be saved securely." }
    }

    private fun decrypt(iv: String, ciphertext: String, key: SecretKey): List<PlaylistAccount> {
        val cipher = Cipher.getInstance(AES_TRANSFORMATION)
        cipher.init(
            Cipher.DECRYPT_MODE,
            key,
            GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)),
        )
        val array = JSONArray(
            cipher.doFinal(Base64.decode(ciphertext, Base64.NO_WRAP)).toString(Charsets.UTF_8),
        )
        return buildList {
            for (index in 0 until array.length()) {
                val value = array.optJSONObject(index) ?: continue
                val username = value.optString("username")
                val password = value.optString("password")
                if (username.isBlank() || password.isBlank()) continue
                add(
                    PlaylistAccount(
                        id = value.optString("id").ifBlank { java.util.UUID.randomUUID().toString() },
                        name = value.optString("name").ifBlank { username },
                        baseUrl = value.optString("baseUrl").normalizeServerUrl(),
                        username = username,
                        password = password,
                        enabled = value.optBoolean("enabled", true),
                        lastSuccessfulRefreshEpochSeconds = if (
                            value.has("lastSuccessfulRefreshEpochSeconds") &&
                            !value.isNull("lastSuccessfulRefreshEpochSeconds")
                        ) {
                            value.optLong("lastSuccessfulRefreshEpochSeconds").takeIf { it > 0L }
                        } else {
                            null
                        },
                    ),
                )
            }
        }
    }

    @TargetApi(Build.VERSION_CODES.M)
    private fun getOrCreateModernKey(): SecretKey {
        val keyStore = KeyStore.getInstance(KEYSTORE_PROVIDER).apply { load(null) }
        (keyStore.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE_PROVIDER).run {
            init(
                KeyGenParameterSpec.Builder(
                    KEY_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
                )
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build(),
            )
            generateKey()
        }
    }

    @Suppress("DEPRECATION")
    private fun getOrCreateLegacyKey(): SecretKey {
        val keyStore = KeyStore.getInstance(KEYSTORE_PROVIDER).apply { load(null) }
        val wrappedKey = preferences.getString(KEY_WRAPPED_LEGACY_KEY, null)
        if (wrappedKey != null && keyStore.containsAlias(LEGACY_RSA_ALIAS)) {
            val unwrapCipher = Cipher.getInstance(RSA_TRANSFORMATION)
            unwrapCipher.init(Cipher.DECRYPT_MODE, keyStore.getKey(LEGACY_RSA_ALIAS, null))
            return SecretKeySpec(
                unwrapCipher.doFinal(Base64.decode(wrappedKey, Base64.NO_WRAP)),
                AES_ALGORITHM,
            )
        }
        if (!keyStore.containsAlias(LEGACY_RSA_ALIAS)) {
            val start = Calendar.getInstance()
            val end = Calendar.getInstance().apply { add(Calendar.YEAR, 25) }
            val spec = KeyPairGeneratorSpec.Builder(appContext)
                .setAlias(LEGACY_RSA_ALIAS)
                .setSubject(X500Principal("CN=B33R IPTV playlist credentials"))
                .setSerialNumber(BigInteger.valueOf(2L))
                .setStartDate(start.time)
                .setEndDate(end.time)
                .build()
            KeyPairGenerator.getInstance(RSA_ALGORITHM, KEYSTORE_PROVIDER).run {
                initialize(spec)
                generateKeyPair()
            }
        }
        val keyBytes = ByteArray(32).also(SecureRandom()::nextBytes)
        val wrapCipher = Cipher.getInstance(RSA_TRANSFORMATION)
        wrapCipher.init(Cipher.ENCRYPT_MODE, keyStore.getCertificate(LEGACY_RSA_ALIAS).publicKey)
        check(
            preferences.edit()
                .putString(
                    KEY_WRAPPED_LEGACY_KEY,
                    Base64.encodeToString(wrapCipher.doFinal(keyBytes), Base64.NO_WRAP),
                )
                .commit(),
        ) { "Legacy playlist key could not be saved." }
        return SecretKeySpec(keyBytes, AES_ALGORITHM)
    }

    private fun clearLegacyPayload() {
        preferences.edit()
            .remove(KEY_LEGACY_IV)
            .remove(KEY_LEGACY_CIPHERTEXT)
            .remove(KEY_WRAPPED_LEGACY_KEY)
            .apply()
    }

    private fun recover() {
        preferences.edit().clear().commit()
        runCatching {
            KeyStore.getInstance(KEYSTORE_PROVIDER).apply {
                load(null)
                if (containsAlias(KEY_ALIAS)) deleteEntry(KEY_ALIAS)
                if (containsAlias(LEGACY_RSA_ALIAS)) deleteEntry(LEGACY_RSA_ALIAS)
            }
        }
    }

    private companion object {
        val LOCK = Any()
        const val PREFERENCES = "secure_playlists"
        const val KEY_IV = "iv"
        const val KEY_CIPHERTEXT = "ciphertext"
        const val KEY_LEGACY_IV = "legacy_iv"
        const val KEY_LEGACY_CIPHERTEXT = "legacy_ciphertext"
        const val KEY_WRAPPED_LEGACY_KEY = "wrapped_legacy_key"
        const val KEY_ALIAS = "b33r_playlist_credentials"
        const val LEGACY_RSA_ALIAS = "b33r_playlist_credentials_rsa"
        const val KEYSTORE_PROVIDER = "AndroidKeyStore"
        const val AES_ALGORITHM = "AES"
        const val RSA_ALGORITHM = "RSA"
        const val AES_TRANSFORMATION = "AES/GCM/NoPadding"
        const val RSA_TRANSFORMATION = "RSA/ECB/PKCS1Padding"
    }
}

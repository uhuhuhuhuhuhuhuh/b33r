package com.streamdeck.iptv

import android.app.Application
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.streamdeck.iptv.data.AccountExpiredException
import com.streamdeck.iptv.data.AppearancePreferences
import com.streamdeck.iptv.data.B33rPreferences
import com.streamdeck.iptv.data.ChannelCustomization
import com.streamdeck.iptv.data.EpgProgram
import com.streamdeck.iptv.data.FeatureStore
import com.streamdeck.iptv.data.GuideChannel
import com.streamdeck.iptv.data.GuideWindow
import com.streamdeck.iptv.data.ImportedFeatureBackup
import com.streamdeck.iptv.data.MultiviewLayoutState
import com.streamdeck.iptv.data.MultiviewSlot
import com.streamdeck.iptv.data.PlaylistAccount
import com.streamdeck.iptv.data.ProDestination
import com.streamdeck.iptv.data.ProUiState
import com.streamdeck.iptv.data.ProgramReminder
import com.streamdeck.iptv.data.RecordingScheduler
import com.streamdeck.iptv.data.RecordingStatus
import com.streamdeck.iptv.data.ReminderScheduler
import com.streamdeck.iptv.data.ScheduledRecording
import com.streamdeck.iptv.data.SecurePlaylistStore
import com.streamdeck.iptv.data.UserProfile
import com.streamdeck.iptv.data.normalizeServerUrl
import com.streamdeck.iptv.data.AppUpdate
import com.streamdeck.iptv.data.AppUpdateManager
import com.streamdeck.iptv.data.BackgroundStatusStore
import com.streamdeck.iptv.data.Category
import com.streamdeck.iptv.data.ContentKind
import com.streamdeck.iptv.data.CredentialStore
import com.streamdeck.iptv.data.Credentials
import com.streamdeck.iptv.data.LibrarySection
import com.streamdeck.iptv.data.LocalLibraryStore
import com.streamdeck.iptv.data.ResumeEntry
import com.streamdeck.iptv.data.StoredSession
import com.streamdeck.iptv.data.StreamItem
import com.streamdeck.iptv.data.XtreamApi
import com.streamdeck.iptv.data.canBeFavorited
import com.streamdeck.iptv.data.canResume
import com.streamdeck.iptv.data.currentEpochSeconds
import com.streamdeck.iptv.data.localLibraryKey
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlin.coroutines.coroutineContext

data class IptvUiState(
    val checkingSession: Boolean = true,
    val authenticated: Boolean = false,
    val loading: Boolean = false,
    val openingItem: Boolean = false,
    val error: String? = null,
    val accountUsername: String = "",
    val accountExpiresAtEpochSeconds: Long? = null,
    val accountExpired: Boolean = false,
    val section: LibrarySection = LibrarySection.LIVE,
    val categories: List<Category> = emptyList(),
    val selectedCategoryId: String? = null,
    val items: List<StreamItem> = emptyList(),
    val favoriteItems: List<StreamItem> = emptyList(),
    val favoriteKeys: Set<String> = emptySet(),
    val resumeEntries: List<ResumeEntry> = emptyList(),
    val continueWatchingItems: List<StreamItem> = emptyList(),
    val seriesTitle: String? = null,
    val seriesId: String? = null,
    val episodes: List<StreamItem> = emptyList(),
    val searchQueries: Map<String, String> = emptyMap(),
    val playbackUrl: String? = null,
    val playbackSources: List<String> = emptyList(),
    val playbackTitle: String = "",
    val playbackKind: ContentKind? = null,
    val playbackItem: StreamItem? = null,
    val playbackStartPositionMs: Long = 0L,
    val availableUpdate: AppUpdate? = null,
    val updateChecking: Boolean = false,
    val updateDownloading: Boolean = false,
    val updateAwaitingPermission: Boolean = false,
    val updateError: String? = null,
    val updateCheckMessage: String? = null,
    val updateDismissed: Boolean = false,
) {
    val searchKey: String
        get() = seriesId?.let { "episodes:$it" } ?: "section:${section.name}"

    val searchQuery: String
        get() = searchQueries[searchKey].orEmpty()
}

private data class ActiveSession(
    val sessionId: String,
    val credentials: Credentials,
)

class IptvViewModel(application: Application) : AndroidViewModel(application) {
    private val api = XtreamApi()
    private val credentialStore = CredentialStore(application)
    private val localLibraryStore = LocalLibraryStore(application)
    private val featureStore = FeatureStore(application)
    private val playlistStore = SecurePlaylistStore(application)
    private val updateManager = AppUpdateManager(application)
    private val backgroundStatusStore = BackgroundStatusStore(application)
    private var credentials: Credentials? = null
    private var activeSessionId: String? = null
    private var catalogJob: Job? = null
    private var openJob: Job? = null
    private var loginJob: Job? = null
    private var expirationJob: Job? = null
    private var accountRefreshJob: Job? = null
    private var visibleAccountRefreshJob: Job? = null
    private var updateInstallJob: Job? = null
    private var guideJob: Job? = null
    private var globalSearchJob: Job? = null
    private var lastOpenAtElapsedMs: Long = 0L
    private var liveCatalogCache: List<StreamItem> = emptyList()
    private var movieCatalogCache: List<StreamItem> = emptyList()
    private var seriesCatalogCache: List<StreamItem> = emptyList()

    var state by mutableStateOf(IptvUiState())
        private set

    var proState by mutableStateOf(featureStore.loadState(playlistStore.load()))
        private set

    init {
        refreshLocalLibraryState()
        backgroundStatusStore.loadAvailableUpdate()?.let { update ->
            state = state.copy(availableUpdate = update)
        }
        checkForUpdates()
        val savedSession = credentialStore.loadSession()
        if (savedSession != null) {
            val existing = playlistStore.load()
            val matching = existing.firstOrNull {
                it.username == savedSession.credentials.username &&
                    it.baseUrl.normalizeServerUrl() == savedSession.credentials.baseUrl.normalizeServerUrl()
            }
            val account = matching ?: PlaylistAccount(
                name = savedSession.accountUsername.ifBlank { savedSession.credentials.username },
                baseUrl = savedSession.credentials.baseUrl.normalizeServerUrl(),
                username = savedSession.credentials.username,
                password = savedSession.credentials.password,
                lastSuccessfulRefreshEpochSeconds = currentEpochSeconds(),
            )
            val updated = if (matching == null) playlistStore.upsert(account) else existing
            featureStore.saveActivePlaylist(account.id)
            proState = proState.copy(playlists = updated, activePlaylistId = account.id)
        }
        if (savedSession == null) {
            val expiredNotice = backgroundStatusStore.loadExpiredAccountNotice()
            state = state.copy(
                checkingSession = false,
                error = expiredNotice?.let { "Account expired." },
            )
        } else if (savedSession.expired) {
            credentials = savedSession.credentials
            activeSessionId = savedSession.sessionId
            handleAccountExpired(
                username = savedSession.accountUsername,
                expiresAtEpochSeconds = savedSession.expiresAtEpochSeconds,
                expectedSessionId = savedSession.sessionId,
            )
        } else {
            credentials = savedSession.credentials
            activeSessionId = savedSession.sessionId
            state = state.copy(
                checkingSession = false,
                authenticated = true,
                accountUsername = savedSession.accountUsername,
                accountExpiresAtEpochSeconds = savedSession.expiresAtEpochSeconds,
            )
            scheduleExpiration(savedSession.expiresAtEpochSeconds)
            startAccountRefreshLoop()
            refreshAccountInfo(savedSession)
            loadSection(LibrarySection.LIVE)
        }
    }

    private fun refreshAccountInfo(session: StoredSession) {
        visibleAccountRefreshJob?.cancel()
        visibleAccountRefreshJob = viewModelScope.launch {
            refreshAccountInfoOnce(session)
        }
    }

    private suspend fun refreshAccountInfoOnce(session: StoredSession) {
        try {
            val account = api.authenticate(session.credentials, savedSession = true)
            val updatedSession = credentialStore.updateIfCurrent(session, account)
            if (
                updatedSession == null &&
                activeSessionId == session.sessionId &&
                credentials == session.credentials &&
                credentialStore.loadSession() == null
            ) {
                handleSessionInvalidated(session.sessionId)
                return
            }
            if (
                updatedSession != null &&
                activeSessionId == session.sessionId &&
                credentials == session.credentials
            ) {
                backgroundStatusStore.clearExpiredAccountNotice()
                state = state.copy(
                    accountUsername = account.username,
                    accountExpiresAtEpochSeconds = account.expiresAtEpochSeconds,
                )
                scheduleExpiration(account.expiresAtEpochSeconds)
            }
        } catch (error: CancellationException) {
            throw error
        } catch (error: Exception) {
            if (error is AccountExpiredException || session.expired) {
                handleAccountExpired(
                    username = session.accountUsername,
                    expiresAtEpochSeconds = session.expiresAtEpochSeconds,
                    expectedSessionId = session.sessionId,
                )
            }
        }
    }

    private fun checkForUpdates(manual: Boolean = false) {
        if (manual && (state.updateChecking || state.updateDownloading)) return
        if (manual) {
            state = state.copy(
                updateChecking = true,
                updateCheckMessage = null,
                updateError = null,
            )
        }
        viewModelScope.launch {
            runCatching { updateManager.checkForUpdate() }
                .onSuccess { update ->
                    backgroundStatusStore.saveAvailableUpdate(update)
                    state = state.copy(
                        availableUpdate = update,
                        updateChecking = false,
                        updateDismissed = false,
                        updateError = null,
                        updateCheckMessage = if (manual && update == null) {
                            if (BuildConfig.DEBUG) {
                                "This is a preview build. The stable update channel has no newer compatible release."
                            } else {
                                "You're up to date. Version ${BuildConfig.VERSION_NAME} is installed."
                            }
                        } else {
                            null
                        },
                    )
                }
                .onFailure { error ->
                    state = state.copy(
                        updateChecking = false,
                        updateCheckMessage = if (manual) {
                            error.message ?: "Unable to check for updates."
                        } else {
                            state.updateCheckMessage
                        },
                    )
                }
        }
    }

    fun checkForUpdatesManually() {
        checkForUpdates(manual = true)
    }

    fun dismissUpdateCheckMessage() {
        state = state.copy(updateCheckMessage = null)
    }

    fun installAvailableUpdate() {
        val update = state.availableUpdate ?: return
        if (state.updateDownloading || updateInstallJob?.isActive == true) return
        state = state.copy(
            updateDownloading = true,
            updateAwaitingPermission = false,
            updateError = null,
        )
        updateInstallJob = viewModelScope.launch {
            try {
                val apk = updateManager.downloadAndVerify(update)
                val installerOpened = updateManager.openInstallerOrSettings(apk)
                state = state.copy(
                    updateDownloading = false,
                    updateAwaitingPermission = !installerOpened,
                    updateDismissed = installerOpened,
                    updateError = if (installerOpened) {
                        null
                    } else {
                        "Allow b33r IPTV to install updates, then return to continue."
                    },
                )
            } catch (error: CancellationException) {
                state = state.copy(updateDownloading = false)
                throw error
            } catch (error: Exception) {
                state = state.copy(
                    updateDownloading = false,
                    updateError = error.message ?: "The update could not be downloaded.",
                )
            }
        }
    }

    fun resumePendingUpdateInstall() {
        if (!state.updateAwaitingPermission) return
        val installerOpened = runCatching { updateManager.resumePendingInstall() }
            .getOrElse { error ->
                state = state.copy(
                    updateError = error.message ?: "The Android installer could not be opened.",
                )
                false
            }
        if (installerOpened) {
            state = state.copy(
                updateAwaitingPermission = false,
                updateDismissed = true,
                updateError = null,
            )
        }
    }

    fun refreshVisibleAccountInfo() {
        val currentCredentials = credentials ?: return
        val currentSessionId = activeSessionId ?: return
        val session = credentialStore.loadSession()
        if (session == null) {
            val expiredNotice = backgroundStatusStore.loadExpiredAccountNotice()
            if (expiredNotice != null) {
                handleAccountExpired(
                    username = expiredNotice.username,
                    expiresAtEpochSeconds = expiredNotice.expiresAtEpochSeconds,
                    expectedSessionId = currentSessionId,
                    storageAlreadyCleared = true,
                )
            } else {
                handleSessionInvalidated(currentSessionId)
            }
            return
        }
        if (session.sessionId != currentSessionId || session.credentials != currentCredentials) return
        if (session.expired) {
            handleAccountExpired(
                username = session.accountUsername,
                expiresAtEpochSeconds = session.expiresAtEpochSeconds,
                expectedSessionId = session.sessionId,
            )
            return
        }
        state = state.copy(
            accountUsername = session.accountUsername,
            accountExpiresAtEpochSeconds = session.expiresAtEpochSeconds,
            accountExpired = false,
        )
        scheduleExpiration(session.expiresAtEpochSeconds)
        refreshAccountInfo(session)
    }

    fun dismissUpdate() {
        if (!state.updateDownloading) {
            state = state.copy(updateDismissed = true)
        }
    }

    fun login(username: String, password: String) {
        login(
            serverUrl = "http://pro.b33r.top",
            username = username,
            password = password,
            accountName = username,
        )
    }

    fun login(
        serverUrl: String,
        username: String,
        password: String,
        accountName: String = username,
    ) {
        if (state.loading || loginJob?.isActive == true) return
        if (username.isBlank() || password.isBlank()) {
            state = state.copy(error = "Enter both username and password.")
            return
        }
        state = state.copy(loading = true, error = null)
        loginJob = viewModelScope.launch {
            val candidate = Credentials(
                username = username.trim(),
                password = password,
                baseUrl = serverUrl.normalizeServerUrl(),
            )
            try {
                val account = api.authenticate(candidate)
                val storedSession = credentialStore.save(candidate, account)
                val existing = playlistStore.load().firstOrNull {
                    it.username == candidate.username &&
                        it.baseUrl.normalizeServerUrl() == candidate.baseUrl.normalizeServerUrl()
                }
                val playlist = (existing ?: PlaylistAccount(
                    name = accountName.trim().ifBlank { account.username },
                    baseUrl = candidate.baseUrl,
                    username = candidate.username,
                    password = candidate.password,
                )).copy(
                    name = accountName.trim().ifBlank { account.username },
                    baseUrl = candidate.baseUrl,
                    username = candidate.username,
                    password = candidate.password,
                    lastSuccessfulRefreshEpochSeconds = currentEpochSeconds(),
                )
                val playlists = playlistStore.upsert(playlist)
                featureStore.saveActivePlaylist(playlist.id)
                proState = proState.copy(
                    playlists = playlists,
                    activePlaylistId = playlist.id,
                    destination = ProDestination.GUIDE,
                    message = null,
                )
                backgroundStatusStore.clearExpiredAccountNotice()
                credentials = candidate
                activeSessionId = storedSession.sessionId
                state = state.copy(
                    authenticated = true,
                    loading = false,
                    accountUsername = account.username,
                    accountExpiresAtEpochSeconds = account.expiresAtEpochSeconds,
                    accountExpired = false,
                )
                scheduleExpiration(account.expiresAtEpochSeconds)
                startAccountRefreshLoop()
                loadSection(LibrarySection.LIVE)
                loadGuide(force = true)
            } catch (error: CancellationException) {
                state = state.copy(loading = false)
                throw error
            } catch (error: Exception) {
                state = state.copy(
                    loading = false,
                    error = error.message ?: "Login failed.",
                )
            }
        }
    }

    fun switchPlaylist(playlistId: String) {
        val account = playlistStore.load().firstOrNull { it.id == playlistId && it.enabled } ?: return
        login(
            serverUrl = account.baseUrl,
            username = account.username,
            password = account.password,
            accountName = account.name,
        )
    }

    fun savePlaylist(account: PlaylistAccount, activate: Boolean = false) {
        val normalized = account.copy(baseUrl = account.baseUrl.normalizeServerUrl())
        val playlists = playlistStore.upsert(normalized)
        proState = proState.copy(playlists = playlists)
        if (activate) switchPlaylist(normalized.id)
    }

    fun removePlaylist(playlistId: String) {
        val playlists = playlistStore.remove(playlistId)
        val activeId = proState.activePlaylistId.takeUnless { it == playlistId }
        featureStore.saveActivePlaylist(activeId)
        proState = proState.copy(playlists = playlists, activePlaylistId = activeId)
    }

    fun logout() {
        catalogJob?.cancel()
        openJob?.cancel()
        loginJob?.cancel()
        expirationJob?.cancel()
        accountRefreshJob?.cancel()
        visibleAccountRefreshJob?.cancel()
        updateInstallJob?.cancel()
        val sessionId = activeSessionId
        if (sessionId == null) {
            credentialStore.clear()
        } else {
            credentialStore.clearIfCurrent(sessionId)
        }
        backgroundStatusStore.clearExpiredAccountNotice()
        credentials = null
        activeSessionId = null
        state = IptvUiState(checkingSession = false)
        refreshLocalLibraryState()
    }

    fun loadSection(section: LibrarySection) {
        if (
            section == state.section &&
            state.seriesTitle == null &&
            (state.loading || state.items.isNotEmpty())
        ) {
            return
        }
        openJob?.cancel()
        if (section == LibrarySection.FAVORITES || section == LibrarySection.RESUME) {
            catalogJob?.cancel()
            refreshLocalLibraryState()
            state = state.copy(
                section = section,
                loading = false,
                openingItem = false,
                error = null,
                categories = emptyList(),
                selectedCategoryId = null,
                items = applyLocalRules(localItems(section), null),
                seriesTitle = null,
                seriesId = null,
                episodes = emptyList(),
            )
            return
        }
        val session = usableSession() ?: return
        catalogJob?.cancel()
        state = state.copy(
            section = section,
            loading = true,
            openingItem = false,
            error = null,
            categories = emptyList(),
            selectedCategoryId = null,
            items = emptyList(),
            seriesTitle = null,
            seriesId = null,
            episodes = emptyList(),
        )
        catalogJob = viewModelScope.launch {
            try {
                val hiddenCategories = activeProfile().hiddenCategoryIds
                val categories = api.categories(session.credentials, section)
                    .filterNot { it.id in hiddenCategories }
                coroutineContext.ensureActive()
                if (state.section == section && state.selectedCategoryId == null) {
                    state = state.copy(categories = categories)
                }
                val streams = api.streams(session.credentials, section, null)
                coroutineContext.ensureActive()
                val processed = applyLocalRules(streams, null)
                when (section) {
                    LibrarySection.LIVE -> liveCatalogCache = streams
                    LibrarySection.MOVIES -> movieCatalogCache = streams
                    LibrarySection.SERIES -> seriesCatalogCache = streams
                    else -> Unit
                }
                if (state.section == section && state.selectedCategoryId == null) {
                    state = state.copy(
                        loading = false,
                        categories = categories,
                        items = processed,
                    )
                }
            } catch (error: CancellationException) {
                throw error
            } catch (error: Exception) {
                if (error is AccountExpiredException) {
                    handleAccountExpired(
                        username = state.accountUsername,
                        expiresAtEpochSeconds = state.accountExpiresAtEpochSeconds,
                        expectedSessionId = session.sessionId,
                    )
                    return@launch
                }
                if (state.section == section) {
                    state = state.copy(
                        loading = false,
                        error = error.message ?: "Unable to load the catalog.",
                    )
                }
            }
        }
    }

    fun selectCategory(categoryId: String?) {
        if (categoryId == state.selectedCategoryId) return
        if (state.section == LibrarySection.FAVORITES || state.section == LibrarySection.RESUME) return
        val session = usableSession() ?: return
        catalogJob?.cancel()
        val section = state.section
        state = state.copy(
            selectedCategoryId = categoryId,
            loading = true,
            error = null,
            items = emptyList(),
        )
        catalogJob = viewModelScope.launch {
            try {
                val streams = api.streams(session.credentials, section, categoryId)
                coroutineContext.ensureActive()
                val processed = applyLocalRules(streams, categoryId)
                if (section == LibrarySection.LIVE && categoryId == null) liveCatalogCache = streams
                if (state.section == section && state.selectedCategoryId == categoryId) {
                    state = state.copy(loading = false, items = processed)
                }
            } catch (error: CancellationException) {
                throw error
            } catch (error: Exception) {
                if (error is AccountExpiredException) {
                    handleAccountExpired(
                        username = state.accountUsername,
                        expiresAtEpochSeconds = state.accountExpiresAtEpochSeconds,
                        expectedSessionId = session.sessionId,
                    )
                    return@launch
                }
                if (state.section == section && state.selectedCategoryId == categoryId) {
                    state = state.copy(
                        loading = false,
                        error = error.message ?: "Unable to load this category.",
                    )
                }
            }
        }
    }

    fun open(item: StreamItem) {
        if (
            state.loading ||
            state.openingItem ||
            state.playbackUrl != null ||
            openJob?.isActive == true
        ) {
            return
        }
        val now = SystemClock.elapsedRealtime()
        if (now - lastOpenAtElapsedMs < OPEN_ACTION_DEBOUNCE_MS) return
        lastOpenAtElapsedMs = now
        val session = usableSession() ?: return
        val itemToOpen = if (state.section == LibrarySection.RESUME) {
            originalResumeItem(item)
        } else {
            item
        }
        state = state.copy(openingItem = true, error = null)
        if (itemToOpen.kind == ContentKind.SERIES) {
            openJob = viewModelScope.launch {
                try {
                    val episodes = api.episodes(session.credentials, itemToOpen.id)
                    coroutineContext.ensureActive()
                    state = state.copy(
                        openingItem = false,
                        seriesTitle = itemToOpen.name,
                        seriesId = itemToOpen.id,
                        episodes = episodes,
                        error = if (episodes.isEmpty()) {
                            "No episodes were returned for this series."
                        } else {
                            null
                        },
                    )
                } catch (error: CancellationException) {
                    throw error
                } catch (error: Exception) {
                    if (error is AccountExpiredException) {
                        handleAccountExpired(
                            username = state.accountUsername,
                            expiresAtEpochSeconds = state.accountExpiresAtEpochSeconds,
                            expectedSessionId = session.sessionId,
                        )
                        return@launch
                    }
                    state = state.copy(
                        openingItem = false,
                        error = error.message ?: "Unable to load episodes.",
                    )
                }
            }
        } else {
            val playbackSources = api.playbackUrls(session.credentials, itemToOpen)
            val firstSource = playbackSources.firstOrNull()
            if (firstSource == null) {
                state = state.copy(
                    openingItem = false,
                    error = "No playable address was returned for this item.",
                )
                return
            }
            state = state.copy(
                openingItem = false,
                playbackUrl = firstSource,
                playbackSources = playbackSources,
                playbackTitle = itemToOpen.name,
                playbackKind = itemToOpen.kind,
                playbackItem = itemToOpen,
                playbackStartPositionMs = if (itemToOpen.canResume()) {
                    localLibraryStore.resumePositionMs(itemToOpen)
                } else {
                    0L
                },
                error = null,
            )
        }
    }

    fun closeSeries() {
        state = state.copy(
            seriesTitle = null,
            seriesId = null,
            episodes = emptyList(),
            error = null,
        )
    }

    fun updateSearchQuery(query: String) {
        state = state.copy(
            searchQueries = state.searchQueries + (state.searchKey to query),
        )
    }

    fun toggleFavorite(item: StreamItem) {
        if (!item.canBeFavorited()) return
        localLibraryStore.toggleFavorite(item)
        refreshLocalLibraryState()
    }

    fun savePlaybackProgress(item: StreamItem, positionMs: Long, durationMs: Long) {
        if (!item.canResume()) return
        localLibraryStore.saveResumeProgress(item, positionMs, durationMs)
    }

    fun closePlayer() {
        if (state.playbackUrl == null) return
        state = state.copy(
            playbackUrl = null,
            playbackSources = emptyList(),
            playbackTitle = "",
            playbackKind = null,
            playbackItem = null,
            playbackStartPositionMs = 0L,
        )
        refreshLocalLibraryState()
    }

    fun selectDestination(destination: ProDestination) {
        featureStore.saveDestination(destination)
        proState = proState.copy(destination = destination, message = null)
        when (destination) {
            ProDestination.GUIDE -> {
                if (state.section != LibrarySection.LIVE) loadSection(LibrarySection.LIVE)
                loadGuide()
            }
            ProDestination.MOVIES -> loadSection(LibrarySection.MOVIES)
            ProDestination.SERIES -> loadSection(LibrarySection.SERIES)
            ProDestination.FAVORITES -> loadSection(LibrarySection.FAVORITES)
            ProDestination.CONTINUE -> loadSection(LibrarySection.RESUME)
            ProDestination.RECORDINGS -> refreshRecordings()
            ProDestination.SEARCH -> if (proState.globalSearchQuery.isNotBlank()) {
                updateGlobalSearch(proState.globalSearchQuery)
            }
            ProDestination.MULTIVIEW,
            ProDestination.PLAYLISTS,
            ProDestination.PROFILES,
            ProDestination.SETTINGS -> Unit
        }
    }

    fun loadGuide(
        force: Boolean = false,
        categoryId: String? = proState.guideCategoryId,
    ) {
        if (!force && proState.guideLoading) return
        if (!force && proState.guideWindow != null && categoryId == proState.guideCategoryId) return
        val session = usableSession() ?: return
        guideJob?.cancel()
        proState = proState.copy(
            guideLoading = true,
            guideError = null,
            guideCategoryId = categoryId,
        )
        guideJob = viewModelScope.launch {
            try {
                val rawChannels = if (categoryId == null && liveCatalogCache.isNotEmpty()) {
                    liveCatalogCache
                } else {
                    api.streams(session.credentials, LibrarySection.LIVE, categoryId).also {
                        if (categoryId == null) liveCatalogCache = it
                    }
                }
                val channels = applyLocalRules(rawChannels, categoryId).take(MAX_GUIDE_CHANNELS)
                val semaphore = Semaphore(EPG_CONCURRENCY)
                val guideChannels = coroutineScope {
                    channels.map { channel ->
                        async {
                            val programs = semaphore.withPermit {
                                runCatching {
                                    api.shortEpg(session.credentials, channel.id, EPG_PROGRAM_LIMIT)
                                }.getOrDefault(emptyList())
                            }
                            GuideChannel(channel, channel.categoryId, programs)
                        }
                    }.awaitAll()
                }
                coroutineContext.ensureActive()
                val allPrograms = guideChannels.flatMap(GuideChannel::programs)
                val now = currentEpochSeconds()
                val start = (allPrograms.minOfOrNull(EpgProgram::startEpochSeconds)
                    ?.coerceAtMost(now) ?: now) / 1_800L * 1_800L
                val end = maxOf(
                    start + GUIDE_WINDOW_SECONDS,
                    allPrograms.maxOfOrNull(EpgProgram::endEpochSeconds) ?: start + GUIDE_WINDOW_SECONDS,
                )
                proState = proState.copy(
                    guideLoading = false,
                    guideError = null,
                    guideCategoryId = categoryId,
                    guideWindow = GuideWindow(start, end, guideChannels),
                    selectedGuideChannelId = proState.selectedGuideChannelId
                        ?.takeIf { selected -> guideChannels.any { it.item.id == selected } }
                        ?: guideChannels.firstOrNull()?.item?.id,
                    selectedProgramId = null,
                )
            } catch (error: CancellationException) {
                throw error
            } catch (error: Exception) {
                proState = proState.copy(
                    guideLoading = false,
                    guideError = error.message ?: "Unable to load the programme guide.",
                )
            }
        }
    }

    fun selectGuideCategory(categoryId: String?) {
        loadGuide(force = true, categoryId = categoryId)
    }

    fun selectGuideProgram(channelId: String, programId: String?) {
        proState = proState.copy(
            selectedGuideChannelId = channelId,
            selectedProgramId = programId,
        )
    }

    fun playGuideEntry(channel: StreamItem, program: EpgProgram? = null) {
        val session = usableSession() ?: return
        val now = currentEpochSeconds()
        if (program != null && program.endEpochSeconds <= now) {
            val catchup = api.catchupUrl(session.credentials, channel, program)
            if (catchup != null) {
                state = state.copy(
                    playbackUrl = catchup,
                    playbackSources = listOf(catchup),
                    playbackTitle = "${program.title} · ${channel.name}",
                    playbackKind = ContentKind.LIVE,
                    playbackItem = channel,
                    playbackStartPositionMs = 0L,
                    openingItem = false,
                    error = null,
                )
                return
            }
        }
        open(channel)
    }

    fun playbackSourcesFor(item: StreamItem): List<String> =
        credentials?.let { runCatching { api.playbackUrls(it, item) }.getOrDefault(emptyList()) }
            .orEmpty()

    fun addToMultiview(channel: StreamItem) {
        val sources = playbackSourcesFor(channel)
        if (sources.isEmpty()) {
            proState = proState.copy(message = "No playable source is available for ${channel.name}.")
            return
        }
        val current = proState.multiview.slots.filterNot { it.channel.id == channel.id }
        val slots = (current + MultiviewSlot(
            slot = current.size.coerceAtMost(3),
            channel = channel,
            sources = sources,
        )).take(4).mapIndexed { index, slot -> slot.copy(slot = index) }
        proState = proState.copy(
            multiview = proState.multiview.copy(slots = slots),
            destination = ProDestination.MULTIVIEW,
            message = null,
        )
    }

    fun removeFromMultiview(slot: Int) {
        val slots = proState.multiview.slots.filterNot { it.slot == slot }
            .mapIndexed { index, value -> value.copy(slot = index) }
        proState = proState.copy(
            multiview = proState.multiview.copy(
                slots = slots,
                activeAudioSlot = proState.multiview.activeAudioSlot.coerceAtMost(
                    (slots.size - 1).coerceAtLeast(0),
                ),
            ),
        )
    }

    fun setMultiviewAudioSlot(slot: Int) {
        if (proState.multiview.slots.none { it.slot == slot }) return
        proState = proState.copy(
            multiview = proState.multiview.copy(activeAudioSlot = slot),
        )
    }

    fun clearMultiview() {
        proState = proState.copy(multiview = MultiviewLayoutState())
    }

    fun scheduleRecording(channel: StreamItem, program: EpgProgram? = null) {
        val preferences = proState.preferences
        val now = currentEpochSeconds()
        val start = ((program?.startEpochSeconds ?: now) -
            preferences.recordingPaddingStartMinutes * 60L).coerceAtLeast(now)
        val end = (program?.endEpochSeconds ?: now + DEFAULT_RECORDING_SECONDS) +
            preferences.recordingPaddingEndMinutes * 60L
        val recording = ScheduledRecording(
            channel = channel,
            program = program,
            title = program?.title ?: channel.name,
            startEpochSeconds = start,
            endEpochSeconds = end.coerceAtLeast(start + 60L),
            playlistId = proState.activePlaylistId,
        )
        val recordings = listOf(recording) + proState.recordings
        featureStore.saveRecordings(recordings)
        RecordingScheduler.schedule(getApplication<Application>(), recording)
        proState = proState.copy(
            recordings = recordings,
            message = if (start <= now + 2L) "Recording ${recording.title}." else
                "Recording scheduled for ${recording.title}.",
        )
    }

    fun cancelRecording(recordingId: String) {
        RecordingScheduler.cancel(getApplication<Application>(), recordingId)
        val recordings = proState.recordings.map { recording ->
            if (recording.id == recordingId) recording.copy(status = RecordingStatus.CANCELLED)
            else recording
        }
        featureStore.saveRecordings(recordings)
        proState = proState.copy(recordings = recordings)
    }

    fun deleteRecording(recordingId: String) {
        val recording = proState.recordings.firstOrNull { it.id == recordingId }
        recording?.outputPath?.let { path -> runCatching { java.io.File(path).delete() } }
        val recordings = proState.recordings.filterNot { it.id == recordingId }
        featureStore.saveRecordings(recordings)
        proState = proState.copy(recordings = recordings)
    }

    fun refreshRecordings() {
        proState = proState.copy(recordings = featureStore.loadRecordings())
    }

    fun playRecording(recording: ScheduledRecording) {
        val path = recording.outputPath ?: return
        val file = java.io.File(path)
        if (!file.exists()) {
            proState = proState.copy(message = "The recording file is no longer available.")
            return
        }
        val item = recording.channel.copy(
            id = "recording:${recording.id}",
            name = recording.title,
            kind = ContentKind.MOVIE,
            directUrl = file.toURI().toString(),
            subtitle = "Recorded",
        )
        open(item)
    }

    fun toggleReminder(channel: StreamItem, program: EpgProgram) {
        val existing = proState.reminders.firstOrNull {
            it.channel.id == channel.id && it.program.id == program.id
        }
        val reminders = if (existing != null) {
            ReminderScheduler.cancel(getApplication<Application>(), existing.id)
            proState.reminders.filterNot { it.id == existing.id }
        } else {
            val reminder = ProgramReminder(
                channel = channel,
                program = program,
                notifyAtEpochSeconds = (program.startEpochSeconds - 60L).coerceAtLeast(
                    currentEpochSeconds(),
                ),
            )
            ReminderScheduler.schedule(getApplication<Application>(), reminder)
            listOf(reminder) + proState.reminders
        }
        featureStore.saveReminders(reminders)
        proState = proState.copy(reminders = reminders)
    }

    fun updateGlobalSearch(query: String) {
        proState = proState.copy(globalSearchQuery = query)
        globalSearchJob?.cancel()
        val normalized = query.trim()
        if (normalized.length < 2) {
            proState = proState.copy(globalSearchResults = emptyList())
            return
        }
        val session = usableSession() ?: return
        globalSearchJob = viewModelScope.launch {
            try {
                if (liveCatalogCache.isEmpty()) {
                    liveCatalogCache = api.streams(session.credentials, LibrarySection.LIVE, null)
                }
                if (movieCatalogCache.isEmpty()) {
                    movieCatalogCache = api.streams(session.credentials, LibrarySection.MOVIES, null)
                }
                if (seriesCatalogCache.isEmpty()) {
                    seriesCatalogCache = api.streams(session.credentials, LibrarySection.SERIES, null)
                }
                val results = (liveCatalogCache + movieCatalogCache + seriesCatalogCache)
                    .asSequence()
                    .filter { item ->
                        item.name.contains(normalized, ignoreCase = true) ||
                            item.subtitle.contains(normalized, ignoreCase = true)
                    }
                    .distinctBy { it.localLibraryKey() }
                    .take(MAX_GLOBAL_SEARCH_RESULTS)
                    .toList()
                proState = proState.copy(globalSearchResults = applyLocalRules(results, null))
            } catch (error: CancellationException) {
                throw error
            } catch (error: Exception) {
                proState = proState.copy(message = error.message ?: "Search failed.")
            }
        }
    }

    fun updatePreferences(preferences: B33rPreferences) {
        featureStore.savePreferences(preferences)
        proState = proState.copy(preferences = preferences)
        if (proState.destination == ProDestination.GUIDE) loadGuide(force = true)
    }

    fun saveProfile(profile: UserProfile, makeActive: Boolean = false) {
        val profiles = proState.profiles.filterNot { it.id == profile.id } + profile
        val active = if (makeActive) profile.id else proState.activeProfileId
        featureStore.saveProfiles(profiles, active)
        proState = proState.copy(profiles = profiles, activeProfileId = active)
        refreshCurrentContentForProfile()
    }

    fun createProfile(name: String, pin: String?, kidsMode: Boolean) {
        if (name.isBlank()) return
        saveProfile(
            UserProfile(
                name = name.trim(),
                pinHash = pin?.takeIf(String::isNotBlank)?.let(featureStore::hashPin),
                kidsMode = kidsMode,
            ),
            makeActive = true,
        )
    }

    fun activateProfile(profileId: String, pin: String = ""): Boolean {
        val profile = proState.profiles.firstOrNull { it.id == profileId } ?: return false
        if (!featureStore.verifyPin(profile, pin)) return false
        featureStore.saveProfiles(proState.profiles, profile.id)
        proState = proState.copy(activeProfileId = profile.id)
        refreshCurrentContentForProfile()
        return true
    }

    fun deleteProfile(profileId: String) {
        if (profileId == "default" || proState.profiles.size <= 1) return
        val profiles = proState.profiles.filterNot { it.id == profileId }
        val active = proState.activeProfileId.takeUnless { it == profileId } ?: profiles.first().id
        featureStore.saveProfiles(profiles, active)
        proState = proState.copy(profiles = profiles, activeProfileId = active)
        refreshCurrentContentForProfile()
    }

    fun toggleChannelHidden(channel: StreamItem) {
        val current = proState.customizations[channel.id] ?: ChannelCustomization(channel.id)
        val updated = proState.customizations + (channel.id to current.copy(hidden = !current.hidden))
        featureStore.saveCustomizations(updated)
        proState = proState.copy(customizations = updated)
        loadGuide(force = true)
    }

    fun toggleChannelLocked(channel: StreamItem) {
        val profile = activeProfile()
        val locked = profile.lockedChannelIds.toMutableSet().apply {
            if (!add(channel.id)) remove(channel.id)
        }
        saveProfile(profile.copy(lockedChannelIds = locked))
    }

    fun renameChannel(channel: StreamItem, name: String) {
        val current = proState.customizations[channel.id] ?: ChannelCustomization(channel.id)
        val updated = proState.customizations +
            (channel.id to current.copy(customName = name.trim().ifBlank { null }))
        featureStore.saveCustomizations(updated)
        proState = proState.copy(customizations = updated)
        loadGuide(force = true)
    }

    fun exportBackup(includeCredentials: Boolean): String = featureStore.exportBackup(
        state = proState,
        playlists = playlistStore.load(),
        includeCredentials = includeCredentials,
    )

    fun importBackup(text: String): Boolean = runCatching {
        val imported: ImportedFeatureBackup = featureStore.importBackup(text)
        featureStore.applyImportedBackup(imported)
        if (imported.playlists.isNotEmpty()) playlistStore.save(imported.playlists)
        proState = featureStore.loadState(playlistStore.load()).copy(
            message = "Backup restored.",
        )
        refreshCurrentContentForProfile()
    }.fold(
        onSuccess = { true },
        onFailure = { error ->
            proState = proState.copy(message = error.message ?: "The backup file is invalid.")
            false
        },
    )

    fun clearProMessage() {
        proState = proState.copy(message = null)
    }

    fun refreshFeatureState() {
        proState = proState.copy(
            recordings = featureStore.loadRecordings(),
            reminders = featureStore.loadReminders(),
            playlists = playlistStore.load(),
        )
    }

    private fun refreshCurrentContentForProfile() {
        state = state.copy(items = applyLocalRules(state.items, state.selectedCategoryId))
        if (proState.destination == ProDestination.GUIDE) loadGuide(force = true)
    }

    fun clearError() {
        state = state.copy(error = null)
    }

    private fun refreshLocalLibraryState() {
        val favorites = localLibraryStore.favoriteItems()
        val resumeEntries = localLibraryStore.resumeEntries()
        val continueWatchingItems = resumeEntries.map { it.toContinueWatchingItem() }
        state = state.copy(
            favoriteItems = favorites,
            favoriteKeys = favorites.map { it.localLibraryKey() }.toSet(),
            resumeEntries = resumeEntries,
            continueWatchingItems = continueWatchingItems,
            items = when {
                state.seriesTitle != null -> state.items
                state.section == LibrarySection.FAVORITES -> favorites
                state.section == LibrarySection.RESUME -> continueWatchingItems
                else -> state.items
            },
        )
    }

    private fun localItems(section: LibrarySection): List<StreamItem> =
        when (section) {
            LibrarySection.FAVORITES -> state.favoriteItems
            LibrarySection.RESUME -> state.continueWatchingItems
            else -> emptyList()
        }

    private fun originalResumeItem(item: StreamItem): StreamItem =
        state.resumeEntries
            .firstOrNull { it.item.localLibraryKey() == item.localLibraryKey() }
            ?.item
            ?: item

    private fun ResumeEntry.toContinueWatchingItem(): StreamItem {
        val parts = buildList {
            if (item.subtitle.isNotBlank()) add(item.subtitle)
            add("Left off at ${formatPlaybackTimestamp(positionMs)}")
            if (durationMs > 0L) add("of ${formatPlaybackTimestamp(durationMs)}")
        }
        return item.copy(subtitle = parts.joinToString("  •  "))
    }

    private fun formatPlaybackTimestamp(milliseconds: Long): String {
        if (milliseconds <= 0L) return "0:00"
        val totalSeconds = milliseconds / 1_000L
        val hours = totalSeconds / 3_600L
        val minutes = (totalSeconds % 3_600L) / 60L
        val seconds = totalSeconds % 60L
        return if (hours > 0L) {
            "%d:%02d:%02d".format(hours, minutes, seconds)
        } else {
            "%d:%02d".format(minutes, seconds)
        }
    }

    private fun activeProfile(): UserProfile =
        proState.profiles.firstOrNull { it.id == proState.activeProfileId }
            ?: proState.profiles.firstOrNull()
            ?: UserProfile(id = "default", name = "Default")

    private fun applyLocalRules(items: List<StreamItem>, categoryId: String?): List<StreamItem> {
        val customized = items.mapNotNull { item ->
            val customization = proState.customizations[item.id]
            if (customization?.hidden == true) return@mapNotNull null
            item.copy(
                name = customization?.customName ?: item.name,
                imageUrl = customization?.logoUrl ?: item.imageUrl,
                subtitle = customization?.epgChannelId ?: item.subtitle,
            )
        }.sortedWith(
            compareBy<StreamItem> { proState.customizations[it.id]?.order ?: Int.MAX_VALUE }
                .thenBy { it.channelNumber ?: Int.MAX_VALUE }
                .thenBy { it.name.lowercase() },
        )
        return featureStore.filterForProfile(
            items = customized,
            categoryId = categoryId,
            profile = activeProfile(),
            preferences = proState.preferences,
        )
    }

    private fun usableSession(): ActiveSession? {
        val sessionCredentials = credentials ?: return null
        val sessionId = activeSessionId ?: return null
        if (isExpired(state.accountExpiresAtEpochSeconds)) {
            handleAccountExpired(
                username = state.accountUsername.ifBlank { sessionCredentials.username },
                expiresAtEpochSeconds = state.accountExpiresAtEpochSeconds,
                expectedSessionId = sessionId,
            )
            return null
        }
        return ActiveSession(sessionId, sessionCredentials)
    }

    private fun scheduleExpiration(expiresAtEpochSeconds: Long?) {
        expirationJob?.cancel()
        if (expiresAtEpochSeconds == null) return
        val expectedSessionId = activeSessionId ?: return
        val delayMillis = ((expiresAtEpochSeconds - currentEpochSeconds()) * 1_000L).coerceAtLeast(0L)
        expirationJob = viewModelScope.launch {
            delay(delayMillis + 1_000L)
            if (
                activeSessionId == expectedSessionId &&
                isExpired(expiresAtEpochSeconds)
            ) {
                handleAccountExpired(
                    username = state.accountUsername,
                    expiresAtEpochSeconds = expiresAtEpochSeconds,
                    expectedSessionId = expectedSessionId,
                )
            }
        }
    }

    private fun startAccountRefreshLoop() {
        accountRefreshJob?.cancel()
        accountRefreshJob = viewModelScope.launch {
            while (true) {
                delay(ACCOUNT_REFRESH_INTERVAL_MS)
                val session = credentialStore.loadSession()
                if (session == null) {
                    activeSessionId?.let { currentSessionId ->
                        val expiredNotice = backgroundStatusStore.loadExpiredAccountNotice()
                        if (expiredNotice != null) {
                            handleAccountExpired(
                                username = expiredNotice.username,
                                expiresAtEpochSeconds = expiredNotice.expiresAtEpochSeconds,
                                expectedSessionId = currentSessionId,
                                storageAlreadyCleared = true,
                            )
                        } else {
                            handleSessionInvalidated(currentSessionId)
                        }
                    }
                    continue
                }
                if (
                    activeSessionId == session.sessionId &&
                    credentials == session.credentials
                ) {
                    refreshAccountInfoOnce(session)
                }
            }
        }
    }

    private fun handleAccountExpired(
        username: String,
        expiresAtEpochSeconds: Long?,
        expectedSessionId: String,
        storageAlreadyCleared: Boolean = false,
    ) {
        if (activeSessionId != expectedSessionId) return
        val storedSession = credentialStore.loadSession()
        if (storedSession != null && storedSession.sessionId != expectedSessionId) return
        if (
            !storageAlreadyCleared &&
            storedSession != null &&
            !credentialStore.clearIfCurrent(expectedSessionId)
        ) {
            return
        }
        catalogJob?.cancel()
        openJob?.cancel()
        loginJob?.cancel()
        expirationJob?.cancel()
        accountRefreshJob?.cancel()
        visibleAccountRefreshJob?.cancel()
        backgroundStatusStore.saveAccountExpired(username, expiresAtEpochSeconds)
        credentials = null
        activeSessionId = null
        state = IptvUiState(
            checkingSession = false,
            error = "Account expired.",
            accountUsername = username,
            accountExpiresAtEpochSeconds = expiresAtEpochSeconds,
            accountExpired = true,
            availableUpdate = state.availableUpdate,
        )
        refreshLocalLibraryState()
    }

    private fun handleSessionInvalidated(expectedSessionId: String) {
        if (activeSessionId != expectedSessionId) return
        catalogJob?.cancel()
        openJob?.cancel()
        loginJob?.cancel()
        expirationJob?.cancel()
        accountRefreshJob?.cancel()
        visibleAccountRefreshJob?.cancel()
        credentials = null
        activeSessionId = null
        state = IptvUiState(
            checkingSession = false,
            error = "Saved login is no longer available. Please sign in again.",
            availableUpdate = state.availableUpdate,
        )
        refreshLocalLibraryState()
    }

    private fun isExpired(expiresAtEpochSeconds: Long?): Boolean =
        expiresAtEpochSeconds?.let { it <= currentEpochSeconds() } == true

    private companion object {
        const val ACCOUNT_REFRESH_INTERVAL_MS = 5 * 60 * 1_000L
        const val OPEN_ACTION_DEBOUNCE_MS = 650L
        const val MAX_GUIDE_CHANNELS = 140
        const val EPG_CONCURRENCY = 6
        const val EPG_PROGRAM_LIMIT = 16
        const val GUIDE_WINDOW_SECONDS = 6L * 60L * 60L
        const val DEFAULT_RECORDING_SECONDS = 2L * 60L * 60L
        const val MAX_GLOBAL_SEARCH_RESULTS = 300
    }
}

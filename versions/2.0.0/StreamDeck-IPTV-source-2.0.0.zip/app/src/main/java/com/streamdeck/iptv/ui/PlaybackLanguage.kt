package com.streamdeck.iptv.ui

import android.content.Context
import androidx.core.os.ConfigurationCompat
import java.util.Locale

internal data class PlaybackLanguagePreference(
    val media3LanguageTags: List<String>,
    val vlcLanguageTokens: List<String>,
    val trackNameHints: List<String>,
)

internal fun playbackLanguagePreference(context: Context): PlaybackLanguagePreference {
    val configured = ConfigurationCompat.getLocales(context.resources.configuration)
    val locales = mutableListOf<Locale>()
    for (index in 0 until configured.size()) {
        configured[index]?.let { locales += it }
    }
    if (locales.isEmpty()) locales += Locale.getDefault()

    val media3Tags = linkedSetOf<String>()
    val vlcTokens = linkedSetOf<String>()
    val nameHints = linkedSetOf<String>()

    locales.forEach { locale ->
        locale.toLanguageTag()
            .takeIf { it.isNotBlank() && it != "und" }
            ?.let { tag ->
                media3Tags += tag
                vlcTokens += tag
            }
        locale.language
            .takeIf { it.isNotBlank() && it != "und" }
            ?.let { language ->
                media3Tags += language
                vlcTokens += language
                nameHints += language.lowercase(Locale.ROOT)
            }
        runCatching { locale.isO3Language }
            .getOrNull()
            ?.takeIf { it.isNotBlank() && it != "und" }
            ?.let { iso3 ->
                vlcTokens += iso3
                nameHints += iso3.lowercase(Locale.ROOT)
            }
        listOf(
            locale.getDisplayLanguage(Locale.ENGLISH),
            locale.getDisplayLanguage(locale),
        ).forEach { displayName ->
            displayName
                .trim()
                .takeIf { it.length >= 2 }
                ?.let { nameHints += it.lowercase(Locale.ROOT) }
        }
    }

    return PlaybackLanguagePreference(
        media3LanguageTags = media3Tags.toList(),
        vlcLanguageTokens = vlcTokens.toList(),
        trackNameHints = nameHints.toList(),
    )
}

internal fun preferredVlcTrackId(
    choices: List<Pair<Int, String>>,
    preference: PlaybackLanguagePreference,
): Int? {
    for (hint in preference.trackNameHints) {
        val expression = if (hint.length <= 3) {
            Regex("(^|[^a-z])${Regex.escape(hint)}([^a-z]|$)")
        } else {
            null
        }
        choices.firstOrNull { (_, name) ->
            val normalized = name.lowercase(Locale.ROOT)
            expression?.containsMatchIn(normalized) ?: normalized.contains(hint)
        }?.let { return it.first }
    }
    return null
}

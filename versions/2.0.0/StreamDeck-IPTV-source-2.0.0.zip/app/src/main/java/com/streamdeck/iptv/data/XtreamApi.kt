package com.streamdeck.iptv.data

import android.net.Uri
import android.util.Base64
import android.util.JsonReader
import android.util.JsonToken
import com.streamdeck.iptv.BuildConfig
import java.io.ByteArrayOutputStream
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.ResponseBody
import org.json.JSONObject
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class XtreamApi {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()
    private val catalogParseMutex = Mutex()

    suspend fun authenticate(
        credentials: Credentials,
        savedSession: Boolean = false,
    ): AccountInfo {
        val response = requestObject(
            credentials = credentials,
            accessDeniedMeansExpired = savedSession,
        )
        val userInfo = response.optJSONObject("user_info")
            ?: throw XtreamException("The provider returned an invalid login response.")
        val authenticated = userInfo.optInt("auth", 0) == 1
        val status = userInfo.optString("status")
        if (!authenticated || (status.isNotBlank() && !status.equals("Active", ignoreCase = true))) {
            val message = userInfo.optString("message")
            if (
                shouldTreatAuthenticationFailureAsExpired(
                    status = status,
                    message = message,
                    expiresAtEpochSeconds = parseExpiration(userInfo),
                )
            ) {
                throw AccountExpiredException()
            }
            throw XtreamException(
                message.ifBlank { "Username or password is incorrect." },
            )
        }
        val account = AccountInfo(
            username = userInfo.optString("username").ifBlank { credentials.username },
            expiresAtEpochSeconds = parseExpiration(userInfo),
        )
        if (account.expired) throw AccountExpiredException()
        return account
    }

    suspend fun categories(
        credentials: Credentials,
        section: LibrarySection,
    ): List<Category> {
        val action = when (section) {
            LibrarySection.LIVE -> "get_live_categories"
            LibrarySection.MOVIES -> "get_vod_categories"
            LibrarySection.SERIES -> "get_series_categories"
            LibrarySection.FAVORITES,
            LibrarySection.RESUME -> throw XtreamException("This section is stored on this device.")
        }
        return requestArray(credentials, action = action, parseObject = ::parseCategory)
    }

    suspend fun streams(
        credentials: Credentials,
        section: LibrarySection,
        categoryId: String?,
    ): List<StreamItem> {
        val action = when (section) {
            LibrarySection.LIVE -> "get_live_streams"
            LibrarySection.MOVIES -> "get_vod_streams"
            LibrarySection.SERIES -> "get_series"
            LibrarySection.FAVORITES,
            LibrarySection.RESUME -> throw XtreamException("This section is stored on this device.")
        }
        return requestArray(credentials, action, categoryId) { reader ->
            parseStream(reader, section)
        }
    }

    suspend fun episodes(credentials: Credentials, seriesId: String): List<StreamItem> {
        val response = requestObject(credentials, action = "get_series_info", seriesId = seriesId)
        return withContext(Dispatchers.Default) {
            val episodes = response.optJSONObject("episodes") ?: return@withContext emptyList()
            val seriesCover = response.optJSONObject("info")?.optString("cover").orEmpty()
            val results = mutableListOf<StreamItem>()
            episodes.keys().asSequence()
                .sortedWith(compareBy({ it.toIntOrNull() ?: Int.MAX_VALUE }, { it }))
                .forEach { season ->
                    ensureActive()
                    val seasonEpisodes = episodes.optJSONArray(season) ?: return@forEach
                    for (index in 0 until seasonEpisodes.length()) {
                        ensureActive()
                        val episode = seasonEpisodes.optJSONObject(index) ?: continue
                        val info = episode.optJSONObject("info")
                        val number = episode.optString("episode_num", "${index + 1}")
                        results += StreamItem(
                            id = episode.optString("id"),
                            name = episode.optString("title", "Episode $number"),
                            kind = ContentKind.EPISODE,
                            extension = safeExtension(
                                episode.optString(
                                    "container_extension",
                                    info?.optString("container_extension", "mp4") ?: "mp4",
                                ),
                                "mp4",
                            ),
                            subtitle = "Season $season  •  Episode $number",
                            imageUrl = info?.optString("movie_image").orEmpty().ifBlank { seriesCover },
                            directUrl = episode.optString("direct_source"),
                        )
                    }
                }
            results.filter { it.id.isNotBlank() }
        }
    }


    suspend fun shortEpg(
        credentials: Credentials,
        streamId: String,
        limit: Int = 12,
    ): List<EpgProgram> {
        val response = requestObject(
            credentials = credentials,
            action = "get_short_epg",
            streamId = streamId,
            limit = limit.coerceIn(1, 50),
        )
        val array = response.optJSONArray("epg_list") ?: return emptyList()
        return withContext(Dispatchers.Default) {
            buildList {
                for (index in 0 until array.length()) {
                    ensureActive()
                    val value = array.optJSONObject(index) ?: continue
                    val start = value.optLong("start_timestamp").takeIf { it > 0L }
                        ?: parseEpgDate(value.optString("start"))
                        ?: continue
                    val end = value.optLong("stop_timestamp").takeIf { it > start }
                        ?: parseEpgDate(value.optString("end"))
                        ?: continue
                    if (end <= start) continue
                    val title = decodeEpgText(value.optString("title"))
                        .ifBlank { "Untitled programme" }
                    val description = decodeEpgText(value.optString("description"))
                    add(
                        EpgProgram(
                            id = value.optString("id").ifBlank { "$streamId:$start" },
                            channelStreamId = streamId,
                            title = title,
                            description = description,
                            startEpochSeconds = start,
                            endEpochSeconds = end,
                            hasArchive = value.optInt("has_archive", 0) == 1,
                        ),
                    )
                }
            }.sortedBy(EpgProgram::startEpochSeconds)
        }
    }

    fun catchupUrl(
        credentials: Credentials,
        channel: StreamItem,
        program: EpgProgram,
    ): String? {
        if (!channel.hasArchive && !program.hasArchive) return null
        val durationMinutes = ((program.endEpochSeconds - program.startEpochSeconds) / 60L)
            .coerceAtLeast(1L)
        val start = SimpleDateFormat("yyyy-MM-dd:HH-mm", Locale.US)
            .format(Date(program.startEpochSeconds * 1_000L))
        val extension = safeExtension(channel.extension.ifBlank { "ts" }, "ts")
        return "${credentials.baseUrl.normalizeServerUrl()}/timeshift/" +
            "${Uri.encode(credentials.username)}/${Uri.encode(credentials.password)}/" +
            "$durationMinutes/$start/${Uri.encode(channel.id)}.$extension"
    }

    fun playbackUrls(credentials: Credentials, item: StreamItem): List<String> {
        val directUrl = item.directUrl.trim()
        val validDirectUrl = if (
            directUrl.startsWith("https://", ignoreCase = true) ||
            directUrl.startsWith("http://", ignoreCase = true) ||
            directUrl.startsWith("rtsp://", ignoreCase = true) ||
            directUrl.startsWith("rtmp://", ignoreCase = true) ||
            directUrl.startsWith("file://", ignoreCase = true) ||
            directUrl.startsWith("content://", ignoreCase = true)
        ) {
            directUrl
        } else {
            null
        }

        val path = when (item.kind) {
            ContentKind.LIVE -> "live"
            ContentKind.MOVIE -> "movie"
            ContentKind.EPISODE -> "series"
            ContentKind.SERIES -> error("A series must be resolved to an episode before playback.")
        }
        val extension = safeExtension(item.extension, if (item.kind == ContentKind.LIVE) "ts" else "mp4")
        val canonicalUrl = "${credentials.baseUrl.normalizeServerUrl()}/$path/" +
            "${Uri.encode(credentials.username)}/${Uri.encode(credentials.password)}/" +
            "${Uri.encode(item.id)}.$extension"
        return if (
            validDirectUrl?.startsWith("file://", true) == true ||
            validDirectUrl?.startsWith("content://", true) == true
        ) {
            listOf(validDirectUrl)
        } else {
            listOfNotNull(canonicalUrl, validDirectUrl).distinct()
        }
    }

    fun playbackUrl(credentials: Credentials, item: StreamItem): String =
        playbackUrls(credentials, item).first()

    private suspend fun <T> requestArray(
        credentials: Credentials,
        action: String,
        categoryId: String? = null,
        parseObject: (JsonReader) -> T?,
    ): List<T> = catalogParseMutex.withLock {
        executeRequest(
            credentials = credentials,
            action = action,
            categoryId = categoryId,
            accessDeniedMeansExpired = true,
        ) { response ->
            val body = response.body
                ?: throw XtreamException("The provider returned an empty catalog response.")
            val contentLength = body.contentLength()
            if (contentLength > MAX_CATALOG_RESPONSE_BYTES) {
                throw XtreamException("This catalog is too large for this device.")
            }
            val results = ArrayList<T>()
            try {
                InputStreamReader(
                    BoundedInputStream(body.byteStream(), MAX_CATALOG_RESPONSE_BYTES),
                    Charsets.UTF_8,
                ).use { input ->
                    JsonReader(input).use { reader ->
                        reader.isLenient = true
                        if (reader.peek() != JsonToken.BEGIN_ARRAY) {
                            throw XtreamException("The provider returned an invalid catalog response.")
                        }
                        reader.beginArray()
                        while (reader.hasNext()) {
                            ensureActive()
                            if (results.size >= MAX_CATALOG_ITEMS) {
                                throw XtreamException("This catalog has too many items for this device.")
                            }
                            if (reader.peek() == JsonToken.BEGIN_OBJECT) {
                                parseObject(reader)?.let(results::add)
                            } else {
                                reader.skipValue()
                            }
                        }
                        reader.endArray()
                    }
                }
            } catch (error: CancellationException) {
                throw error
            } catch (error: XtreamException) {
                throw error
            } catch (_: Exception) {
                ensureActive()
                throw XtreamException("The provider returned an invalid catalog response.")
            }
            results
        }
    }

    private suspend fun requestObject(
        credentials: Credentials,
        action: String? = null,
        seriesId: String? = null,
        streamId: String? = null,
        limit: Int? = null,
        accessDeniedMeansExpired: Boolean = true,
    ): JSONObject = withContext(Dispatchers.Default) {
        val body = requestText(
            credentials = credentials,
            action = action,
            seriesId = seriesId,
            streamId = streamId,
            limit = limit,
            accessDeniedMeansExpired = accessDeniedMeansExpired,
        )
        ensureActive()
        runCatching { JSONObject(body) }
            .getOrElse { throw XtreamException("The provider returned an invalid response.") }
    }

    private suspend fun requestText(
        credentials: Credentials,
        action: String? = null,
        categoryId: String? = null,
        seriesId: String? = null,
        streamId: String? = null,
        limit: Int? = null,
        accessDeniedMeansExpired: Boolean,
    ): String = executeRequest(
        credentials = credentials,
        action = action,
        categoryId = categoryId,
        seriesId = seriesId,
        streamId = streamId,
        limit = limit,
        accessDeniedMeansExpired = accessDeniedMeansExpired,
    ) { response ->
        readBoundedText(
            body = response.body
                ?: throw XtreamException("The provider returned an empty response."),
            maxBytes = MAX_OBJECT_RESPONSE_BYTES,
        )
    }

    private suspend fun <T> executeRequest(
        credentials: Credentials,
        action: String? = null,
        categoryId: String? = null,
        seriesId: String? = null,
        streamId: String? = null,
        limit: Int? = null,
        accessDeniedMeansExpired: Boolean,
        transform: CoroutineScope.(Response) -> T,
    ): T = suspendCancellableCoroutine { continuation ->
        val query = buildList {
            add("username=${encode(credentials.username)}")
            add("password=${encode(credentials.password)}")
            action?.let { add("action=${encode(it)}") }
            categoryId?.let { add("category_id=${encode(it)}") }
            seriesId?.let { add("series_id=${encode(it)}") }
            streamId?.let { add("stream_id=${encode(it)}") }
            limit?.let { add("limit=${it.coerceIn(1, 100)}") }
        }.joinToString("&")
        val request = Request.Builder()
            .url("${credentials.baseUrl.normalizeServerUrl()}/player_api.php?$query")
            .header("Accept", "application/json")
            .header("User-Agent", "StreamDeckIPTV/1.0 Android")
            .get()
            .build()
        val call = client.newCall(request)
        continuation.invokeOnCancellation { call.cancel() }
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (!continuation.isActive) return
                continuation.resumeWithException(XtreamNetworkException())
            }

            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (!continuation.isActive) return
                    val requestScope = CoroutineScope(continuation.context)
                    try {
                        requestScope.ensureActive()
                        if (!response.isSuccessful) {
                            val errorBody = response.body?.let {
                                requestScope.readBoundedText(it, MAX_ERROR_RESPONSE_BYTES)
                            }.orEmpty()
                            throw providerError(
                                code = response.code,
                                body = errorBody,
                                accessDeniedMeansExpired = accessDeniedMeansExpired,
                                notFoundMeansInvalidCredentials =
                                    action == null && !accessDeniedMeansExpired,
                            )
                        }
                        val result = requestScope.transform(response)
                        if (continuation.isActive) continuation.resume(result)
                    } catch (error: CancellationException) {
                        if (continuation.isActive) continuation.cancel(error)
                    } catch (error: XtreamException) {
                        if (continuation.isActive) continuation.resumeWithException(error)
                    } catch (_: IOException) {
                        if (continuation.isActive) {
                            continuation.resumeWithException(XtreamNetworkException())
                        }
                    } catch (_: Exception) {
                        if (continuation.isActive) {
                            continuation.resumeWithException(
                                XtreamException("The provider returned an invalid response."),
                            )
                        }
                    }
                }
            }
        })
    }

    private fun CoroutineScope.readBoundedText(
        body: ResponseBody,
        maxBytes: Long,
    ): String {
        val contentLength = body.contentLength()
        if (contentLength > maxBytes) {
            throw XtreamException("The provider response is too large for this device.")
        }
        val output = ByteArrayOutputStream(
            contentLength
                .takeIf { it in 1..maxBytes }
                ?.toInt()
                ?: DEFAULT_RESPONSE_BUFFER_BYTES,
        )
        body.byteStream().use { input ->
            val buffer = ByteArray(RESPONSE_READ_BUFFER_BYTES)
            var total = 0L
            while (true) {
                ensureActive()
                val read = input.read(buffer)
                if (read < 0) break
                total += read
                if (total > maxBytes) {
                    throw XtreamException("The provider response is too large for this device.")
                }
                output.write(buffer, 0, read)
            }
        }
        return output.toString(Charsets.UTF_8.name())
    }

    private fun parseCategory(reader: JsonReader): Category? {
        var id = ""
        var name = "Untitled"
        reader.beginObject()
        while (reader.hasNext()) {
            when (reader.nextName()) {
                "category_id" -> id = reader.nextScalarString()
                "category_name" -> name = reader.nextScalarString().ifBlank { "Untitled" }
                else -> reader.skipValue()
            }
        }
        reader.endObject()
        return if (id.isBlank()) null else Category(id, name)
    }

    private fun parseStream(reader: JsonReader, section: LibrarySection): StreamItem? {
        var id = ""
        var name = ""
        var extension = ""
        var year = ""
        var rating = ""
        var epgChannelId = ""
        var releaseDate = ""
        var imageUrl = ""
        var cover = ""
        var directUrl = ""
        var categoryId: String? = null
        var channelNumber: Int? = null
        var hasArchive = false
        var archiveDurationDays = 0
        reader.beginObject()
        while (reader.hasNext()) {
            when (reader.nextName()) {
                "stream_id" -> if (section != LibrarySection.SERIES) {
                    id = reader.nextScalarString()
                } else {
                    reader.skipValue()
                }
                "series_id" -> if (section == LibrarySection.SERIES) {
                    id = reader.nextScalarString()
                } else {
                    reader.skipValue()
                }
                "name" -> name = reader.nextScalarString()
                "container_extension" -> extension = reader.nextScalarString()
                "year" -> year = reader.nextScalarString()
                "rating" -> rating = reader.nextScalarString()
                "epg_channel_id" -> epgChannelId = reader.nextScalarString()
                "releaseDate" -> releaseDate = reader.nextScalarString()
                "stream_icon" -> imageUrl = reader.nextScalarString()
                "cover" -> cover = reader.nextScalarString()
                "direct_source" -> directUrl = reader.nextScalarString()
                "category_id" -> categoryId = reader.nextScalarString().ifBlank { null }
                "num" -> channelNumber = reader.nextScalarString().toIntOrNull()
                "tv_archive" -> hasArchive = reader.nextScalarString() == "1"
                "tv_archive_duration" -> archiveDurationDays = reader.nextScalarString().toIntOrNull() ?: 0
                else -> reader.skipValue()
            }
        }
        reader.endObject()
        if (id.isBlank()) return null
        return when (section) {
            LibrarySection.LIVE -> StreamItem(
                id = id,
                name = name.ifBlank { "Untitled channel" },
                kind = ContentKind.LIVE,
                extension = safeExtension(extension.ifBlank { "ts" }, "ts"),
                subtitle = epgChannelId,
                imageUrl = imageUrl,
                directUrl = directUrl,
                categoryId = categoryId,
                channelNumber = channelNumber,
                hasArchive = hasArchive,
                archiveDurationDays = archiveDurationDays,
            )
            LibrarySection.MOVIES -> StreamItem(
                id = id,
                name = name.ifBlank { "Untitled movie" },
                kind = ContentKind.MOVIE,
                extension = safeExtension(extension.ifBlank { "mp4" }, "mp4"),
                subtitle = listOf(year, rating)
                    .filter { it.isNotBlank() && it != "0" }
                    .joinToString("  •  "),
                imageUrl = imageUrl,
                directUrl = directUrl,
            )
            LibrarySection.SERIES -> StreamItem(
                id = id,
                name = name.ifBlank { "Untitled series" },
                kind = ContentKind.SERIES,
                subtitle = releaseDate.ifBlank { year },
                imageUrl = cover,
            )
            LibrarySection.FAVORITES,
            LibrarySection.RESUME -> throw XtreamException("This section is stored on this device.")
        }
    }

    private fun JsonReader.nextScalarString(): String =
        when (peek()) {
            JsonToken.STRING,
            JsonToken.NUMBER -> nextString()
            JsonToken.BOOLEAN -> nextBoolean().toString()
            JsonToken.NULL -> {
                nextNull()
                ""
            }
            else -> {
                skipValue()
                ""
            }
        }

    private fun encode(value: String): String = URLEncoder.encode(value, Charsets.UTF_8.name())

    private fun safeExtension(value: String, fallback: String): String =
        value.lowercase().replace(Regex("[^a-z0-9]"), "").ifBlank { fallback }

    private fun parseExpiration(userInfo: JSONObject): Long? {
        if (!userInfo.has("exp_date") || userInfo.isNull("exp_date")) return null
        return when (val value = userInfo.opt("exp_date")) {
            is Number -> value.toLong()
            is String -> value.trim().takeUnless {
                it.isBlank() || it.equals("null", ignoreCase = true)
            }?.toLongOrNull()
            else -> null
        }?.takeIf { it > 0L }
    }


    private fun decodeEpgText(value: String): String {
        val trimmed = value.trim()
        if (trimmed.isBlank()) return ""
        return runCatching {
            val decoded = Base64.decode(trimmed, Base64.DEFAULT).toString(Charsets.UTF_8).trim()
            decoded.takeIf { it.isNotBlank() && decoded.none { ch -> ch == '\u0000' } } ?: trimmed
        }.getOrDefault(trimmed)
    }

    private fun parseEpgDate(value: String): Long? {
        val trimmed = value.trim()
        if (trimmed.isBlank()) return null
        val patterns = listOf("yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd'T'HH:mm:ss", "yyyyMMddHHmmss Z")
        for (pattern in patterns) {
            val parsed = runCatching {
                SimpleDateFormat(pattern, Locale.US).parse(trimmed)?.time?.div(1_000L)
            }.getOrNull()
            if (parsed != null) return parsed
        }
        return null
    }

    private fun providerError(
        code: Int,
        body: String,
        accessDeniedMeansExpired: Boolean,
        notFoundMeansInvalidCredentials: Boolean,
    ): XtreamException {
        val errorMessage = runCatching {
            JSONObject(body).optString("error")
        }.getOrDefault("")
        if (errorMessage.equals("Account expired", ignoreCase = true)) {
            return AccountExpiredException()
        }
        if (
            accessDeniedMeansExpired &&
            (
                code == HttpURLConnection.HTTP_FORBIDDEN ||
                    code == HttpURLConnection.HTTP_UNAUTHORIZED
                )
        ) {
            return AccountExpiredException()
        }
        if (code == 408 || code == 429 || code in 500..599) {
            return XtreamNetworkException()
        }
        if (code == HttpURLConnection.HTTP_FORBIDDEN) {
            return XtreamException("Access was forbidden. The account may be expired.")
        }
        if (code == HttpURLConnection.HTTP_UNAUTHORIZED) {
            return XtreamException("Username or password is incorrect, or the account has expired.")
        }
        if (code == HttpURLConnection.HTTP_NOT_FOUND && notFoundMeansInvalidCredentials) {
            return XtreamException("Username or password is incorrect.")
        }
        return XtreamException("Provider request failed (HTTP $code).")
    }

    private companion object {
        const val MAX_CATALOG_ITEMS = 40_000
        const val MAX_CATALOG_RESPONSE_BYTES = 32L * 1024L * 1024L
        const val MAX_OBJECT_RESPONSE_BYTES = 24L * 1024L * 1024L
        const val MAX_ERROR_RESPONSE_BYTES = 64L * 1024L
        const val DEFAULT_RESPONSE_BUFFER_BYTES = 8 * 1024
        const val RESPONSE_READ_BUFFER_BYTES = 8 * 1024
    }
}

private class BoundedInputStream(
    input: InputStream,
    private val maxBytes: Long,
) : FilterInputStream(input) {
    private var bytesRead = 0L

    override fun read(): Int {
        val value = super.read()
        if (value >= 0) recordRead(1)
        return value
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        val read = super.read(buffer, offset, length)
        if (read > 0) recordRead(read)
        return read
    }

    private fun recordRead(count: Int) {
        bytesRead += count
        if (bytesRead > maxBytes) {
            throw XtreamException("This catalog is too large for this device.")
        }
    }
}

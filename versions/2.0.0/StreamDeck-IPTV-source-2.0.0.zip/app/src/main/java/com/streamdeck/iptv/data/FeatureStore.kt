package com.streamdeck.iptv.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.util.Locale

class FeatureStore(context: Context) {
    private val preferences = context.applicationContext.getSharedPreferences(
        "b33r_pro_features",
        Context.MODE_PRIVATE,
    )

    fun loadState(playlists: List<PlaylistAccount> = emptyList()): ProUiState {
        val profiles = loadProfiles().ifEmpty {
            listOf(UserProfile(id = "default", name = "Default"))
        }
        val activeProfile = preferences.getString(KEY_ACTIVE_PROFILE, null)
            ?.takeIf { id -> profiles.any { it.id == id } }
            ?: profiles.first().id
        return ProUiState(
            destination = runCatching {
                ProDestination.valueOf(
                    preferences.getString(KEY_DESTINATION, ProDestination.GUIDE.name)
                        ?: ProDestination.GUIDE.name,
                )
            }.getOrDefault(ProDestination.GUIDE),
            recordings = loadRecordings(),
            reminders = loadReminders(),
            profiles = profiles,
            activeProfileId = activeProfile,
            playlists = playlists,
            activePlaylistId = preferences.getString(KEY_ACTIVE_PLAYLIST, null),
            preferences = loadPreferences(),
            customizations = loadCustomizations(),
        )
    }

    fun saveDestination(destination: ProDestination) {
        preferences.edit().putString(KEY_DESTINATION, destination.name).apply()
    }

    fun savePreferences(value: B33rPreferences) {
        preferences.edit().putString(KEY_PREFERENCES, value.toJson().toString()).apply()
    }

    fun loadPreferences(): B33rPreferences =
        preferences.getString(KEY_PREFERENCES, null)
            ?.let { runCatching { preferencesFromJson(JSONObject(it)) }.getOrNull() }
            ?: B33rPreferences()

    fun saveProfiles(profiles: List<UserProfile>, activeId: String) {
        val json = JSONArray()
        profiles.forEach { json.put(it.toJson()) }
        preferences.edit()
            .putString(KEY_PROFILES, json.toString())
            .putString(KEY_ACTIVE_PROFILE, activeId)
            .apply()
    }

    fun loadProfiles(): List<UserProfile> = parseArray(KEY_PROFILES, ::profileFromJson)

    fun saveActivePlaylist(id: String?) {
        preferences.edit().putString(KEY_ACTIVE_PLAYLIST, id).apply()
    }

    fun saveRecordings(recordings: List<ScheduledRecording>) {
        val json = JSONArray()
        recordings.forEach { json.put(it.toJson()) }
        preferences.edit().putString(KEY_RECORDINGS, json.toString()).apply()
    }

    fun loadRecordings(): List<ScheduledRecording> =
        parseArray(KEY_RECORDINGS, ::recordingFromJson)

    fun saveReminders(reminders: List<ProgramReminder>) {
        val json = JSONArray()
        reminders.forEach { json.put(it.toJson()) }
        preferences.edit().putString(KEY_REMINDERS, json.toString()).apply()
    }

    fun loadReminders(): List<ProgramReminder> = parseArray(KEY_REMINDERS, ::reminderFromJson)

    fun saveCustomizations(customizations: Map<String, ChannelCustomization>) {
        val json = JSONArray()
        customizations.values.forEach { json.put(it.toJson()) }
        preferences.edit().putString(KEY_CUSTOMIZATIONS, json.toString()).apply()
    }

    fun loadCustomizations(): Map<String, ChannelCustomization> =
        parseArray(KEY_CUSTOMIZATIONS, ::customizationFromJson).associateBy { it.streamId }

    fun exportBackup(
        state: ProUiState,
        playlists: List<PlaylistAccount>,
        includeCredentials: Boolean,
    ): String {
        val root = JSONObject()
            .put("schemaVersion", 2)
            .put("exportedAtEpochSeconds", currentEpochSeconds())
            .put("preferences", state.preferences.toJson())
            .put("activeProfileId", state.activeProfileId)
            .put("activePlaylistId", state.activePlaylistId)
        root.put("profiles", JSONArray().apply { state.profiles.forEach { put(it.toJson()) } })
        root.put("recordings", JSONArray().apply { state.recordings.forEach { put(it.toJson()) } })
        root.put("reminders", JSONArray().apply { state.reminders.forEach { put(it.toJson()) } })
        root.put(
            "customizations",
            JSONArray().apply { state.customizations.values.forEach { put(it.toJson()) } },
        )
        root.put(
            "playlists",
            JSONArray().apply {
                playlists.forEach { account ->
                    put(
                        JSONObject()
                            .put("id", account.id)
                            .put("name", account.name)
                            .put("baseUrl", account.baseUrl)
                            .put("username", account.username)
                            .put("password", if (includeCredentials) account.password else "")
                            .put("enabled", account.enabled)
                            .put("lastSuccessfulRefreshEpochSeconds", account.lastSuccessfulRefreshEpochSeconds),
                    )
                }
            },
        )
        return root.toString(2)
    }

    fun importBackup(jsonText: String): ImportedFeatureBackup {
        val root = JSONObject(jsonText)
        val profiles = root.optJSONArray("profiles").toObjectList(::profileFromJson)
            .ifEmpty { listOf(UserProfile(id = "default", name = "Default")) }
        val preferencesValue = root.optJSONObject("preferences")
            ?.let(::preferencesFromJson)
            ?: B33rPreferences()
        val recordings = root.optJSONArray("recordings").toObjectList(::recordingFromJson)
        val reminders = root.optJSONArray("reminders").toObjectList(::reminderFromJson)
        val customizations = root.optJSONArray("customizations")
            .toObjectList(::customizationFromJson)
            .associateBy { it.streamId }
        val playlists = root.optJSONArray("playlists").toObjectList { objectValue ->
            PlaylistAccount(
                id = objectValue.optString("id").ifBlank { java.util.UUID.randomUUID().toString() },
                name = objectValue.optString("name").ifBlank { "Playlist" },
                baseUrl = objectValue.optString("baseUrl").normalizeServerUrl(),
                username = objectValue.optString("username"),
                password = objectValue.optString("password"),
                enabled = objectValue.optBoolean("enabled", true),
                lastSuccessfulRefreshEpochSeconds = objectValue.optNullableLong(
                    "lastSuccessfulRefreshEpochSeconds",
                ),
            )
        }.filter { it.username.isNotBlank() }
        val activeProfileId = root.optString("activeProfileId")
            .takeIf { id -> profiles.any { it.id == id } }
            ?: profiles.first().id
        return ImportedFeatureBackup(
            profiles = profiles,
            activeProfileId = activeProfileId,
            activePlaylistId = root.optString("activePlaylistId").ifBlank { null },
            preferences = preferencesValue,
            recordings = recordings,
            reminders = reminders,
            customizations = customizations,
            playlists = playlists,
        )
    }

    fun applyImportedBackup(value: ImportedFeatureBackup) {
        saveProfiles(value.profiles, value.activeProfileId)
        savePreferences(value.preferences)
        saveRecordings(value.recordings)
        saveReminders(value.reminders)
        saveCustomizations(value.customizations)
        saveActivePlaylist(value.activePlaylistId)
    }

    fun hashPin(pin: String): String = MessageDigest.getInstance("SHA-256")
        .digest("b33r-profile:$pin".toByteArray(Charsets.UTF_8))
        .joinToString("") { byte -> "%02x".format(byte) }

    fun verifyPin(profile: UserProfile, pin: String): Boolean =
        profile.pinHash == null || profile.pinHash == hashPin(pin)

    fun filterForProfile(
        items: List<StreamItem>,
        categoryId: String?,
        profile: UserProfile,
        preferences: B33rPreferences,
    ): List<StreamItem> {
        if (categoryId != null && categoryId in profile.hiddenCategoryIds) return emptyList()
        val adultFiltering = preferences.parental.adultNameFiltering || profile.kidsMode
        return items.filter { item ->
            item.id !in profile.hiddenChannelIds &&
                item.id !in profile.lockedChannelIds &&
                (!adultFiltering || !looksAdult(item.name) && !looksAdult(item.subtitle))
        }
    }

    private fun looksAdult(value: String): Boolean {
        val normalized = value.lowercase(Locale.ROOT)
        return ADULT_TERMS.any { term -> normalized.contains(term) }
    }

    private fun <T> parseArray(key: String, mapper: (JSONObject) -> T): List<T> {
        val array = preferences.getString(key, null)
            ?.let { runCatching { JSONArray(it) }.getOrNull() }
            ?: return emptyList()
        return array.toObjectList(mapper)
    }

    private companion object {
        const val KEY_DESTINATION = "destination"
        const val KEY_PREFERENCES = "preferences"
        const val KEY_PROFILES = "profiles"
        const val KEY_ACTIVE_PROFILE = "active_profile"
        const val KEY_ACTIVE_PLAYLIST = "active_playlist"
        const val KEY_RECORDINGS = "recordings"
        const val KEY_REMINDERS = "reminders"
        const val KEY_CUSTOMIZATIONS = "customizations"
        val ADULT_TERMS = setOf(
            "adult", "xxx", "18+", "porn", "erotic", "playboy", "hustler", "brazzers",
        )
    }
}

data class ImportedFeatureBackup(
    val profiles: List<UserProfile>,
    val activeProfileId: String,
    val activePlaylistId: String?,
    val preferences: B33rPreferences,
    val recordings: List<ScheduledRecording>,
    val reminders: List<ProgramReminder>,
    val customizations: Map<String, ChannelCustomization>,
    val playlists: List<PlaylistAccount>,
)

private fun B33rPreferences.toJson() = JSONObject()
    .put("playback", JSONObject()
        .put("engine", playback.engine.name)
        .put("bufferSeconds", playback.bufferSeconds)
        .put("timeshiftMinutes", playback.timeshiftMinutes)
        .put("matchFrameRate", playback.matchFrameRate)
        .put("preferHardwareDecoding", playback.preferHardwareDecoding)
        .put("passthroughAudio", playback.passthroughAudio)
        .put("audioDelayMs", playback.audioDelayMs)
        .put("subtitleDelayMs", playback.subtitleDelayMs)
        .put("subtitleScalePercent", playback.subtitleScalePercent)
        .put("preferDeviceLanguage", playback.preferDeviceLanguage)
        .put("autoPlayNextEpisode", playback.autoPlayNextEpisode)
        .put("externalPlayerPackage", playback.externalPlayerPackage))
    .put("appearance", JSONObject()
        .put("guideDensity", appearance.guideDensity.name)
        .put("showChannelNumbers", appearance.showChannelNumbers)
        .put("showChannelLogos", appearance.showChannelLogos)
        .put("use24HourClock", appearance.use24HourClock)
        .put("animationsEnabled", appearance.animationsEnabled)
        .put("previewEnabled", appearance.previewEnabled)
        .put("accentArgb", appearance.accentArgb))
    .put("parental", JSONObject()
        .put("adultNameFiltering", parental.adultNameFiltering)
        .put("requirePinForSettings", parental.requirePinForSettings)
        .put("requirePinForLockedContent", parental.requirePinForLockedContent))
    .put("recordingPaddingStartMinutes", recordingPaddingStartMinutes)
    .put("recordingPaddingEndMinutes", recordingPaddingEndMinutes)

private fun preferencesFromJson(root: JSONObject): B33rPreferences {
    val playback = root.optJSONObject("playback") ?: JSONObject()
    val appearance = root.optJSONObject("appearance") ?: JSONObject()
    val parental = root.optJSONObject("parental") ?: JSONObject()
    return B33rPreferences(
        playback = PlaybackPreferences(
            engine = runCatching {
                PlayerEnginePreference.valueOf(playback.optString("engine"))
            }.getOrDefault(PlayerEnginePreference.AUTOMATIC),
            bufferSeconds = playback.optInt("bufferSeconds", 18).coerceIn(3, 120),
            timeshiftMinutes = playback.optInt("timeshiftMinutes", 30).coerceIn(0, 180),
            matchFrameRate = playback.optBoolean("matchFrameRate", true),
            preferHardwareDecoding = playback.optBoolean("preferHardwareDecoding", true),
            passthroughAudio = playback.optBoolean("passthroughAudio", false),
            audioDelayMs = playback.optInt("audioDelayMs", 0).coerceIn(-5_000, 5_000),
            subtitleDelayMs = playback.optInt("subtitleDelayMs", 0).coerceIn(-10_000, 10_000),
            subtitleScalePercent = playback.optInt("subtitleScalePercent", 100).coerceIn(50, 200),
            preferDeviceLanguage = playback.optBoolean("preferDeviceLanguage", true),
            autoPlayNextEpisode = playback.optBoolean("autoPlayNextEpisode", true),
            externalPlayerPackage = playback.optString("externalPlayerPackage").ifBlank { null },
        ),
        appearance = AppearancePreferences(
            guideDensity = runCatching {
                GuideDensity.valueOf(appearance.optString("guideDensity"))
            }.getOrDefault(GuideDensity.COMPACT),
            showChannelNumbers = appearance.optBoolean("showChannelNumbers", true),
            showChannelLogos = appearance.optBoolean("showChannelLogos", true),
            use24HourClock = appearance.optBoolean("use24HourClock", false),
            animationsEnabled = appearance.optBoolean("animationsEnabled", true),
            previewEnabled = appearance.optBoolean("previewEnabled", true),
            accentArgb = appearance.optLong("accentArgb", 0xFFF2A900),
        ),
        parental = ParentalPreferences(
            adultNameFiltering = parental.optBoolean("adultNameFiltering", true),
            requirePinForSettings = parental.optBoolean("requirePinForSettings", false),
            requirePinForLockedContent = parental.optBoolean("requirePinForLockedContent", true),
        ),
        recordingPaddingStartMinutes = root.optInt("recordingPaddingStartMinutes", 2)
            .coerceIn(0, 30),
        recordingPaddingEndMinutes = root.optInt("recordingPaddingEndMinutes", 5)
            .coerceIn(0, 60),
    )
}

private fun UserProfile.toJson() = JSONObject()
    .put("id", id)
    .put("name", name)
    .put("pinHash", pinHash)
    .put("kidsMode", kidsMode)
    .put("lockedChannelIds", lockedChannelIds.toJsonArray())
    .put("lockedCategoryIds", lockedCategoryIds.toJsonArray())
    .put("hiddenChannelIds", hiddenChannelIds.toJsonArray())
    .put("hiddenCategoryIds", hiddenCategoryIds.toJsonArray())

private fun profileFromJson(root: JSONObject) = UserProfile(
    id = root.optString("id").ifBlank { java.util.UUID.randomUUID().toString() },
    name = root.optString("name").ifBlank { "Profile" },
    pinHash = root.optString("pinHash").ifBlank { null },
    kidsMode = root.optBoolean("kidsMode", false),
    lockedChannelIds = root.optJSONArray("lockedChannelIds").toStringSet(),
    lockedCategoryIds = root.optJSONArray("lockedCategoryIds").toStringSet(),
    hiddenChannelIds = root.optJSONArray("hiddenChannelIds").toStringSet(),
    hiddenCategoryIds = root.optJSONArray("hiddenCategoryIds").toStringSet(),
)

private fun ScheduledRecording.toJson() = JSONObject()
    .put("id", id)
    .put("channel", channel.toJson())
    .put("program", program?.toJson())
    .put("title", title)
    .put("startEpochSeconds", startEpochSeconds)
    .put("endEpochSeconds", endEpochSeconds)
    .put("status", status.name)
    .put("playlistId", playlistId)
    .put("outputPath", outputPath)
    .put("errorMessage", errorMessage)
    .put("createdAtEpochSeconds", createdAtEpochSeconds)

private fun recordingFromJson(root: JSONObject) = ScheduledRecording(
    id = root.optString("id").ifBlank { java.util.UUID.randomUUID().toString() },
    channel = streamFromJson(root.getJSONObject("channel")),
    program = root.optJSONObject("program")?.let(::epgFromJson),
    title = root.optString("title").ifBlank { "Recording" },
    startEpochSeconds = root.optLong("startEpochSeconds"),
    endEpochSeconds = root.optLong("endEpochSeconds"),
    status = runCatching { RecordingStatus.valueOf(root.optString("status")) }
        .getOrDefault(RecordingStatus.SCHEDULED),
    playlistId = root.optString("playlistId").ifBlank { null },
    outputPath = root.optString("outputPath").ifBlank { null },
    errorMessage = root.optString("errorMessage").ifBlank { null },
    createdAtEpochSeconds = root.optLong("createdAtEpochSeconds", currentEpochSeconds()),
)

private fun ProgramReminder.toJson() = JSONObject()
    .put("id", id)
    .put("channel", channel.toJson())
    .put("program", program.toJson())
    .put("notifyAtEpochSeconds", notifyAtEpochSeconds)

private fun reminderFromJson(root: JSONObject) = ProgramReminder(
    id = root.optString("id").ifBlank { java.util.UUID.randomUUID().toString() },
    channel = streamFromJson(root.getJSONObject("channel")),
    program = epgFromJson(root.getJSONObject("program")),
    notifyAtEpochSeconds = root.optLong("notifyAtEpochSeconds"),
)

private fun ChannelCustomization.toJson() = JSONObject()
    .put("streamId", streamId)
    .put("customName", customName)
    .put("customGroup", customGroup)
    .put("hidden", hidden)
    .put("order", order)
    .put("logoUrl", logoUrl)
    .put("epgChannelId", epgChannelId)
    .put("epgOffsetMinutes", epgOffsetMinutes)

private fun customizationFromJson(root: JSONObject) = ChannelCustomization(
    streamId = root.getString("streamId"),
    customName = root.optString("customName").ifBlank { null },
    customGroup = root.optString("customGroup").ifBlank { null },
    hidden = root.optBoolean("hidden", false),
    order = if (root.has("order") && !root.isNull("order")) root.optInt("order") else null,
    logoUrl = root.optString("logoUrl").ifBlank { null },
    epgChannelId = root.optString("epgChannelId").ifBlank { null },
    epgOffsetMinutes = root.optInt("epgOffsetMinutes", 0),
)

private fun StreamItem.toJson() = JSONObject()
    .put("id", id)
    .put("name", name)
    .put("kind", kind.name)
    .put("extension", extension)
    .put("subtitle", subtitle)
    .put("imageUrl", imageUrl)
    .put("directUrl", directUrl)
    .put("categoryId", categoryId)
    .put("channelNumber", channelNumber)
    .put("hasArchive", hasArchive)
    .put("archiveDurationDays", archiveDurationDays)

private fun streamFromJson(root: JSONObject) = StreamItem(
    id = root.optString("id"),
    name = root.optString("name"),
    kind = runCatching { ContentKind.valueOf(root.optString("kind")) }
        .getOrDefault(ContentKind.LIVE),
    extension = root.optString("extension"),
    subtitle = root.optString("subtitle"),
    imageUrl = root.optString("imageUrl"),
    directUrl = root.optString("directUrl"),
    categoryId = root.optString("categoryId").ifBlank { null },
    channelNumber = if (root.has("channelNumber") && !root.isNull("channelNumber")) {
        root.optInt("channelNumber")
    } else {
        null
    },
    hasArchive = root.optBoolean("hasArchive", false),
    archiveDurationDays = root.optInt("archiveDurationDays", 0),
)

private fun EpgProgram.toJson() = JSONObject()
    .put("id", id)
    .put("channelStreamId", channelStreamId)
    .put("title", title)
    .put("description", description)
    .put("startEpochSeconds", startEpochSeconds)
    .put("endEpochSeconds", endEpochSeconds)
    .put("hasArchive", hasArchive)

private fun epgFromJson(root: JSONObject) = EpgProgram(
    id = root.optString("id"),
    channelStreamId = root.optString("channelStreamId"),
    title = root.optString("title"),
    description = root.optString("description"),
    startEpochSeconds = root.optLong("startEpochSeconds"),
    endEpochSeconds = root.optLong("endEpochSeconds"),
    hasArchive = root.optBoolean("hasArchive", false),
)

private fun Set<String>.toJsonArray() = JSONArray().apply { forEach(::put) }

private fun JSONArray?.toStringSet(): Set<String> {
    if (this == null) return emptySet()
    return buildSet {
        for (index in 0 until length()) {
            optString(index).takeIf(String::isNotBlank)?.let(::add)
        }
    }
}

private fun <T> JSONArray?.toObjectList(mapper: (JSONObject) -> T): List<T> {
    if (this == null) return emptyList()
    return buildList {
        for (index in 0 until length()) {
            optJSONObject(index)?.let { objectValue ->
                runCatching { mapper(objectValue) }.getOrNull()?.let(::add)
            }
        }
    }
}

private fun JSONObject.optNullableLong(key: String): Long? =
    if (has(key) && !isNull(key)) optLong(key).takeIf { it > 0L } else null

internal fun String.normalizeServerUrl(): String {
    val raw = trim().trimEnd('/')
    if (raw.isBlank()) return "http://pro.b33r.top"
    return if (raw.startsWith("http://", true) || raw.startsWith("https://", true)) {
        raw
    } else {
        "http://$raw"
    }
}

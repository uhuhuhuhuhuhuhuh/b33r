@file:androidx.media3.common.util.UnstableApi

package com.streamdeck.iptv.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.ManageAccounts
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.FileProvider
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil3.compose.AsyncImage
import com.streamdeck.iptv.IptvUiState
import com.streamdeck.iptv.data.AppearancePreferences
import com.streamdeck.iptv.data.B33rPreferences
import com.streamdeck.iptv.data.Category
import com.streamdeck.iptv.data.ContentKind
import com.streamdeck.iptv.data.EpgProgram
import com.streamdeck.iptv.data.GuideChannel
import com.streamdeck.iptv.data.GuideDensity
import com.streamdeck.iptv.data.GuideWindow
import com.streamdeck.iptv.data.MultiviewSlot
import com.streamdeck.iptv.data.ParentalPreferences
import com.streamdeck.iptv.data.PlaybackPreferences
import com.streamdeck.iptv.data.PlaylistAccount
import com.streamdeck.iptv.data.ProDestination
import com.streamdeck.iptv.data.ProUiState
import com.streamdeck.iptv.data.RecordingStatus
import com.streamdeck.iptv.data.ScheduledRecording
import com.streamdeck.iptv.data.StreamItem
import com.streamdeck.iptv.data.UserProfile
import com.streamdeck.iptv.data.currentEpochSeconds
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.max
import kotlin.math.min

internal val primaryDestinations = listOf(
    ProDestination.GUIDE,
    ProDestination.MOVIES,
    ProDestination.SERIES,
    ProDestination.FAVORITES,
    ProDestination.CONTINUE,
)

internal val utilityDestinations = listOf(
    ProDestination.RECORDINGS,
    ProDestination.MULTIVIEW,
    ProDestination.SEARCH,
    ProDestination.PLAYLISTS,
    ProDestination.PROFILES,
    ProDestination.SETTINGS,
)

@Composable
internal fun ProNavigationRail(
    selected: ProDestination,
    onSelect: (ProDestination) -> Unit,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val responsive = rememberResponsiveLayout()
    NavigationRail(
        modifier = modifier
            .fillMaxHeight()
            .width(if (responsive.isTelevision) 104.dp else 92.dp),
        containerColor = Color(0xFF0D0D0D),
        header = {
            Surface(
                modifier = Modifier.padding(vertical = 10.dp).size(46.dp),
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.primary,
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text("B33R", color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Black, fontSize = 10.sp)
                }
            }
        },
    ) {
        (primaryDestinations + utilityDestinations).forEach { destination ->
            NavigationRailItem(
                selected = selected == destination,
                onClick = { onSelect(destination) },
                icon = { Icon(destination.icon(), contentDescription = null) },
                label = { Text(destination.shortTitle(), maxLines = 1, fontSize = 9.sp) },
            )
        }
        Spacer(Modifier.weight(1f))
        NavigationRailItem(
            selected = false,
            onClick = onLogout,
            icon = { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null) },
            label = { Text("Logout", fontSize = 9.sp) },
        )
    }
}

@Composable
internal fun ProBottomNavigation(
    selected: ProDestination,
    onSelect: (ProDestination) -> Unit,
) {
    val destinations = listOf(
        ProDestination.GUIDE,
        ProDestination.MOVIES,
        ProDestination.SERIES,
        ProDestination.SEARCH,
        ProDestination.SETTINGS,
    )
    NavigationBar(containerColor = Color(0xFF111111)) {
        destinations.forEach { destination ->
            NavigationBarItem(
                selected = selected == destination,
                onClick = { onSelect(destination) },
                icon = { Icon(destination.icon(), contentDescription = null) },
                label = { Text(destination.shortTitle(), maxLines = 1) },
            )
        }
    }
}

@Composable
internal fun GuideScreen(
    state: IptvUiState,
    proState: ProUiState,
    onCategory: (String?) -> Unit,
    onSelect: (String, String?) -> Unit,
    onPlay: (StreamItem, EpgProgram?) -> Unit,
    onFavorite: (StreamItem) -> Unit,
    onRecord: (StreamItem, EpgProgram?) -> Unit,
    onReminder: (StreamItem, EpgProgram) -> Unit,
    onMultiview: (StreamItem) -> Unit,
    onHide: (StreamItem) -> Unit,
    onLock: (StreamItem) -> Unit,
    onRefresh: () -> Unit,
    playbackSources: (StreamItem) -> List<String>,
    modifier: Modifier = Modifier,
) {
    val responsive = rememberResponsiveLayout()
    val guide = proState.guideWindow
    val selectedChannel = guide?.channels?.firstOrNull { it.item.id == proState.selectedGuideChannelId }
        ?: guide?.channels?.firstOrNull()
    val selectedProgram = selectedChannel?.programs?.firstOrNull { it.id == proState.selectedProgramId }
        ?: selectedChannel?.programs?.firstOrNull { it.isLiveNow }
        ?: selectedChannel?.programs?.firstOrNull()
    var contextTarget by remember { mutableStateOf<Pair<GuideChannel, EpgProgram?>?>(null) }

    Column(modifier.fillMaxSize().background(Color(0xFF080808))) {
        GuideHero(
            channel = selectedChannel?.item,
            program = selectedProgram,
            sources = selectedChannel?.item?.let(playbackSources).orEmpty(),
            previewEnabled = proState.preferences.appearance.previewEnabled,
            onPlay = { selectedChannel?.let { onPlay(it.item, selectedProgram) } },
            onRecord = { selectedChannel?.let { onRecord(it.item, selectedProgram) } },
            onMultiview = { selectedChannel?.let { onMultiview(it.item) } },
            modifier = Modifier.fillMaxWidth().height(if (responsive.isTelevision) 178.dp else 132.dp),
        )
        if (proState.guideLoading && guide == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else if (guide == null) {
            EmptyFeatureState(
                title = proState.guideError ?: "Programme guide unavailable",
                action = "Refresh guide",
                onAction = onRefresh,
                modifier = Modifier.fillMaxSize(),
            )
        } else if (responsive.isTelevision) {
            TvGuideGrid(
                categories = state.categories,
                selectedCategoryId = proState.guideCategoryId,
                guide = guide,
                selectedChannelId = selectedChannel?.item?.id,
                selectedProgramId = selectedProgram?.id,
                appearance = proState.preferences.appearance,
                onCategory = onCategory,
                onSelect = onSelect,
                onPlay = onPlay,
                onContext = { channel, program -> contextTarget = channel to program },
                modifier = Modifier.weight(1f),
            )
        } else {
            MobileGuideList(
                categories = state.categories,
                selectedCategoryId = proState.guideCategoryId,
                guide = guide,
                onCategory = onCategory,
                onSelect = onSelect,
                onPlay = onPlay,
                onContext = { channel, program -> contextTarget = channel to program },
                modifier = Modifier.weight(1f),
            )
        }
    }

    contextTarget?.let { (channel, program) ->
        GuideContextDialog(
            channel = channel.item,
            program = program,
            favorite = state.favoriteKeys.contains(channel.item.localLibraryKeyCompat()),
            reminderSet = program != null && proState.reminders.any {
                it.channel.id == channel.item.id && it.program.id == program.id
            },
            onDismiss = { contextTarget = null },
            onPlay = { contextTarget = null; onPlay(channel.item, program) },
            onFavorite = { onFavorite(channel.item) },
            onRecord = { onRecord(channel.item, program) },
            onReminder = if (program != null) {{ onReminder(channel.item, program) }} else null,
            onMultiview = { contextTarget = null; onMultiview(channel.item) },
            onHide = { contextTarget = null; onHide(channel.item) },
            onLock = { contextTarget = null; onLock(channel.item) },
        )
    }
}

@Composable
private fun GuideHero(
    channel: StreamItem?,
    program: EpgProgram?,
    sources: List<String>,
    previewEnabled: Boolean,
    onPlay: () -> Unit,
    onRecord: () -> Unit,
    onMultiview: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(modifier = modifier, color = Color(0xFF111111), tonalElevation = 4.dp) {
        Row(Modifier.fillMaxSize().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color.Black),
                contentAlignment = Alignment.Center,
            ) {
                if (previewEnabled && sources.isNotEmpty()) {
                    InlineMedia3Preview(sources.first(), muted = true, modifier = Modifier.fillMaxSize())
                } else if (channel?.imageUrl?.isNotBlank() == true) {
                    AsyncImage(
                        model = channel.imageUrl,
                        contentDescription = null,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize().padding(12.dp),
                    )
                } else {
                    Icon(Icons.Default.LiveTv, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(46.dp))
                }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(channel?.name ?: "Live TV", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(program?.title ?: "Select a channel", fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (program != null) {
                    Text(
                        "${formatGuideTime(program.startEpochSeconds, false)} – ${formatGuideTime(program.endEpochSeconds, false)}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    LinearProgressIndicator(
                        progress = { program.progress() },
                        modifier = Modifier.fillMaxWidth().height(3.dp),
                    )
                    Text(program.description, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 12.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick = onPlay, enabled = channel != null) {
                        Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(4.dp)); Text("Play")
                    }
                    OutlinedButton(onClick = onRecord, enabled = channel != null) {
                        Icon(Icons.Default.RadioButtonChecked, null); Spacer(Modifier.width(4.dp)); Text("Record")
                    }
                    OutlinedButton(onClick = onMultiview, enabled = channel != null) {
                        Icon(Icons.Default.GridView, null); Spacer(Modifier.width(4.dp)); Text("Multiview")
                    }
                }
            }
        }
    }
}

@Composable
private fun TvGuideGrid(
    categories: List<Category>,
    selectedCategoryId: String?,
    guide: GuideWindow,
    selectedChannelId: String?,
    selectedProgramId: String?,
    appearance: AppearancePreferences,
    onCategory: (String?) -> Unit,
    onSelect: (String, String?) -> Unit,
    onPlay: (StreamItem, EpgProgram?) -> Unit,
    onContext: (GuideChannel, EpgProgram?) -> Unit,
    modifier: Modifier = Modifier,
) {
    val rowHeight = when (appearance.guideDensity) {
        GuideDensity.COMPACT -> 58.dp
        GuideDensity.BALANCED -> 70.dp
        GuideDensity.COMFORTABLE -> 84.dp
    }
    val channelWidth = 230.dp
    val groupWidth = 178.dp
    val pixelsPerMinute = 3.1f
    val totalMinutes = ((guide.endEpochSeconds - guide.startEpochSeconds) / 60f).coerceAtLeast(180f)
    val timelineWidth = (totalMinutes * pixelsPerMinute).dp
    var offsetDp by remember(guide.startEpochSeconds, guide.endEpochSeconds) { mutableFloatStateOf(0f) }
    val density = LocalDensity.current

    Row(
        modifier
            .pointerInput(timelineWidth) {
                detectHorizontalDragGestures { change, dragAmount ->
                    change.consume()
                    val maxOffset = max(0f, timelineWidth.value - 640f)
                    offsetDp = (offsetDp - dragAmount / density.density).coerceIn(0f, maxOffset)
                }
            },
    ) {
        LazyColumn(
            modifier = Modifier.width(groupWidth).fillMaxHeight().background(Color(0xFF0E0E0E)),
            contentPadding = PaddingValues(8.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp),
        ) {
            item {
                FilterChip(
                    selected = selectedCategoryId == null,
                    onClick = { onCategory(null) },
                    label = { Text("All channels") },
                )
            }
            items(categories, key = Category::id) { category ->
                FilterChip(
                    selected = selectedCategoryId == category.id,
                    onClick = { onCategory(category.id) },
                    label = { Text(category.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                )
            }
        }
        Column(Modifier.weight(1f).clip(RoundedCornerShape(topStart = 8.dp))) {
            Row(Modifier.height(38.dp).background(Color(0xFF191919))) {
                Box(Modifier.width(channelWidth).fillMaxHeight().padding(horizontal = 10.dp), contentAlignment = Alignment.CenterStart) {
                    Text("Channels", fontWeight = FontWeight.Bold)
                }
                Box(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(2.dp))) {
                    GuideTimeHeader(guide, timelineWidth, offsetDp)
                }
            }
            LazyColumn(Modifier.fillMaxSize()) {
                items(guide.channels, key = { it.item.id }) { channel ->
                    Row(Modifier.height(rowHeight).background(if (selectedChannelId == channel.item.id) Color(0xFF191919) else Color(0xFF101010))) {
                        ChannelGuideCell(
                            channel = channel.item,
                            selected = selectedChannelId == channel.item.id,
                            showNumber = appearance.showChannelNumbers,
                            showLogo = appearance.showChannelLogos,
                            modifier = Modifier.width(channelWidth).fillMaxHeight(),
                            onClick = { onSelect(channel.item.id, channel.programs.firstOrNull { it.isLiveNow }?.id) },
                            onLongClick = { onContext(channel, null) },
                        )
                        Box(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(2.dp))) {
                            GuideProgramRow(
                                channel = channel,
                                guide = guide,
                                timelineWidth = timelineWidth,
                                offsetDp = offsetDp,
                                selectedProgramId = selectedProgramId,
                                onSelect = onSelect,
                                onPlay = onPlay,
                                onContext = onContext,
                            )
                        }
                    }
                    HorizontalDivider(color = Color(0xFF242424), thickness = 1.dp)
                }
            }
        }
    }
}

@Composable
private fun GuideTimeHeader(guide: GuideWindow, timelineWidth: Dp, offsetDp: Float) {
    Box(Modifier.width(timelineWidth).fillMaxHeight().offset(x = (-offsetDp).dp)) {
        var time = guide.startEpochSeconds
        while (time <= guide.endEpochSeconds) {
            val x = ((time - guide.startEpochSeconds) / 60f * 3.1f).dp
            Text(
                formatGuideTime(time, false),
                modifier = Modifier.offset(x = x).padding(start = 4.dp, top = 9.dp),
                color = if (time <= currentEpochSeconds() && currentEpochSeconds() < time + 1_800L) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 11.sp,
            )
            time += 1_800L
        }
    }
}

@Composable
private fun GuideProgramRow(
    channel: GuideChannel,
    guide: GuideWindow,
    timelineWidth: Dp,
    offsetDp: Float,
    selectedProgramId: String?,
    onSelect: (String, String?) -> Unit,
    onPlay: (StreamItem, EpgProgram?) -> Unit,
    onContext: (GuideChannel, EpgProgram?) -> Unit,
) {
    Box(Modifier.width(timelineWidth).fillMaxHeight().offset(x = (-offsetDp).dp)) {
        if (channel.programs.isEmpty()) {
            Surface(
                modifier = Modifier.offset(x = 0.dp).width(320.dp).fillMaxHeight().padding(3.dp),
                color = Color(0xFF1A1A1A),
                shape = RoundedCornerShape(6.dp),
            ) { Box(contentAlignment = Alignment.CenterStart) { Text("No guide data", Modifier.padding(10.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) } }
        }
        channel.programs.forEach { program ->
            val startMinutes = (program.startEpochSeconds - guide.startEpochSeconds) / 60f
            val durationMinutes = (program.endEpochSeconds - program.startEpochSeconds) / 60f
            val x = (startMinutes * 3.1f).dp
            val width = max(64f, durationMinutes * 3.1f).dp
            var focused by remember(program.id) { mutableStateOf(false) }
            val selected = selectedProgramId == program.id
            Surface(
                modifier = Modifier
                    .offset(x = x)
                    .width(width)
                    .fillMaxHeight()
                    .padding(3.dp)
                    .onFocusChanged { focused = it.isFocused }
                    .combinedClickable(
                        onClick = { onSelect(channel.item.id, program.id) },
                        onDoubleClick = { onPlay(channel.item, program) },
                        onLongClick = { onContext(channel, program) },
                    ),
                color = when {
                    focused -> MaterialTheme.colorScheme.primary
                    selected -> MaterialTheme.colorScheme.primary.copy(alpha = 0.28f)
                    program.isLiveNow -> Color(0xFF342611)
                    else -> Color(0xFF1C1C1C)
                },
                contentColor = if (focused) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                shape = RoundedCornerShape(6.dp),
                border = if (focused || selected) BorderStroke(1.dp, MaterialTheme.colorScheme.primary) else null,
            ) {
                Column(Modifier.padding(horizontal = 8.dp, vertical = 5.dp)) {
                    Text(program.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    Text(
                        "${formatGuideTime(program.startEpochSeconds, false)} – ${formatGuideTime(program.endEpochSeconds, false)}",
                        maxLines = 1,
                        color = if (focused) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 9.sp,
                    )
                    if (program.isLiveNow) LinearProgressIndicator(progress = { program.progress() }, modifier = Modifier.fillMaxWidth().height(2.dp))
                }
            }
        }
    }
}

@Composable
private fun ChannelGuideCell(
    channel: StreamItem,
    selected: Boolean,
    showNumber: Boolean,
    showLogo: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
) {
    var focused by remember(channel.id) { mutableStateOf(false) }
    Surface(
        modifier = modifier
            .padding(3.dp)
            .onFocusChanged { focused = it.isFocused }
            .combinedClickable(onClick = onClick, onDoubleClick = onClick, onLongClick = onLongClick),
        color = when {
            focused -> Color(0xFFF4F4F4)
            selected -> Color(0xFF282828)
            else -> Color.Transparent
        },
        contentColor = if (focused) Color.Black else Color.White,
        shape = RoundedCornerShape(6.dp),
    ) {
        Row(Modifier.fillMaxSize().padding(horizontal = 7.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (showNumber) Text((channel.channelNumber ?: 0).takeIf { it > 0 }?.toString().orEmpty(), fontSize = 10.sp, modifier = Modifier.width(26.dp), color = if (focused) Color.DarkGray else MaterialTheme.colorScheme.onSurfaceVariant)
            if (showLogo) {
                Box(Modifier.size(38.dp), contentAlignment = Alignment.Center) {
                    if (channel.imageUrl.isNotBlank()) AsyncImage(channel.imageUrl, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                    else Icon(Icons.Default.LiveTv, null, tint = MaterialTheme.colorScheme.primary)
                }
            }
            Text(channel.name, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium, fontSize = 12.sp)
        }
    }
}

@Composable
private fun MobileGuideList(
    categories: List<Category>,
    selectedCategoryId: String?,
    guide: GuideWindow,
    onCategory: (String?) -> Unit,
    onSelect: (String, String?) -> Unit,
    onPlay: (StreamItem, EpgProgram?) -> Unit,
    onContext: (GuideChannel, EpgProgram?) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier) {
        LazyRow(contentPadding = PaddingValues(10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            item { FilterChip(selectedCategoryId == null, { onCategory(null) }, { Text("All") }) }
            items(categories, key = Category::id) { category ->
                FilterChip(selectedCategoryId == category.id, { onCategory(category.id) }, { Text(category.name, maxLines = 1) })
            }
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            items(guide.channels, key = { it.item.id }) { channel ->
                val now = channel.programs.firstOrNull { it.isLiveNow }
                val next = channel.programs.firstOrNull { it.startEpochSeconds >= (now?.endEpochSeconds ?: currentEpochSeconds()) }
                Card(
                    modifier = Modifier.fillMaxWidth().combinedClickable(
                        onClick = { onSelect(channel.item.id, now?.id) },
                        onDoubleClick = { onPlay(channel.item, now) },
                        onLongClick = { onContext(channel, now) },
                    ),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF181818)),
                ) {
                    Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        AsyncImage(channel.item.imageUrl, null, Modifier.size(50.dp), contentScale = ContentScale.Fit)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(channel.item.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(now?.title ?: "No current programme", maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.primary)
                            if (now != null) LinearProgressIndicator(progress = { now.progress() }, Modifier.fillMaxWidth().height(2.dp))
                            next?.let { Text("Next: ${it.title}", maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        }
                        IconButton(onClick = { onPlay(channel.item, now) }) { Icon(Icons.Default.PlayArrow, "Play") }
                    }
                }
            }
        }
    }
}

@Composable
private fun GuideContextDialog(
    channel: StreamItem,
    program: EpgProgram?,
    favorite: Boolean,
    reminderSet: Boolean,
    onDismiss: () -> Unit,
    onPlay: () -> Unit,
    onFavorite: () -> Unit,
    onRecord: () -> Unit,
    onReminder: (() -> Unit)?,
    onMultiview: () -> Unit,
    onHide: () -> Unit,
    onLock: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(program?.title ?: channel.name) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                program?.let { Text(it.description, maxLines = 4, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                ContextAction("Play", Icons.Default.PlayArrow, onPlay)
                ContextAction(if (favorite) "Remove favorite" else "Add favorite", Icons.Default.Favorite, onFavorite)
                ContextAction("Record", Icons.Default.RadioButtonChecked, onRecord)
                onReminder?.let { ContextAction(if (reminderSet) "Remove reminder" else "Set reminder", Icons.Default.Notifications, it) }
                ContextAction("Add to multiview", Icons.Default.GridView, onMultiview)
                ContextAction("Lock for this profile", Icons.Default.Lock, onLock)
                ContextAction("Hide channel", Icons.Default.Block, onHide)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}

@Composable
private fun ContextAction(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    TextButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Icon(icon, null); Spacer(Modifier.width(8.dp)); Text(label, Modifier.weight(1f))
    }
}

@Composable
internal fun RecordingsScreen(
    recordings: List<ScheduledRecording>,
    onPlay: (ScheduledRecording) -> Unit,
    onCancel: (String) -> Unit,
    onDelete: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    FeatureHeader("Recordings", "Scheduled and saved programmes")
    if (recordings.isEmpty()) {
        EmptyFeatureState("No recordings yet", "Open the guide to schedule one", {}, modifier)
        return
    }
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(recordings, key = ScheduledRecording::id) { recording ->
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF181818))) {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.RadioButtonChecked, null, tint = when (recording.status) {
                        RecordingStatus.RECORDING -> Color.Red
                        RecordingStatus.COMPLETE -> Color.Green
                        RecordingStatus.FAILED -> MaterialTheme.colorScheme.error
                        else -> MaterialTheme.colorScheme.primary
                    })
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(recording.title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            "${recording.channel.name} · ${recording.status.name.lowercase().replaceFirstChar(Char::uppercase)}",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                        )
                        Text(
                            "${formatGuideDateTime(recording.startEpochSeconds)} – ${formatGuideTime(recording.endEpochSeconds, false)}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        recording.errorMessage?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 11.sp) }
                    }
                    if (recording.status == RecordingStatus.COMPLETE) {
                        IconButton(onClick = { onPlay(recording) }) { Icon(Icons.Default.PlayArrow, "Play") }
                    }
                    if (recording.status == RecordingStatus.SCHEDULED || recording.status == RecordingStatus.RECORDING) {
                        IconButton(onClick = { onCancel(recording.id) }) { Icon(Icons.Default.Cancel, "Cancel") }
                    }
                    IconButton(onClick = { onDelete(recording.id) }) { Icon(Icons.Default.Delete, "Delete") }
                }
            }
        }
    }
}

@Composable
internal fun MultiviewScreen(
    slots: List<MultiviewSlot>,
    activeAudioSlot: Int,
    onAudioSlot: (Int) -> Unit,
    onRemove: (Int) -> Unit,
    onClear: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier.fillMaxSize().background(Color.Black)) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Multiview", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("${slots.size}/4 streams", color = MaterialTheme.colorScheme.onSurfaceVariant)
            TextButton(onClick = onClear, enabled = slots.isNotEmpty()) { Text("Clear") }
        }
        if (slots.isEmpty()) {
            EmptyFeatureState("No multiview channels", "Long-press a guide programme and choose Add to multiview", {}, Modifier.weight(1f))
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(if (slots.size == 1) 1 else 2),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(6.dp),
            ) {
                gridItems(slots, key = MultiviewSlot::slot) { slot ->
                    Box(Modifier.padding(4.dp).aspectRatio(16f / 9f).clip(RoundedCornerShape(8.dp)).background(Color(0xFF111111))) {
                        InlineMedia3Preview(
                            url = slot.sources.first(),
                            muted = activeAudioSlot != slot.slot,
                            modifier = Modifier.fillMaxSize().clickable { onAudioSlot(slot.slot) },
                        )
                        Surface(
                            Modifier.align(Alignment.TopStart).padding(6.dp),
                            color = if (activeAudioSlot == slot.slot) MaterialTheme.colorScheme.primary else Color(0xCC000000),
                            shape = RoundedCornerShape(5.dp),
                        ) { Text(slot.channel.name, Modifier.padding(horizontal = 7.dp, vertical = 4.dp), maxLines = 1, fontSize = 10.sp, color = if (activeAudioSlot == slot.slot) MaterialTheme.colorScheme.onPrimary else Color.White) }
                        IconButton(onClick = { onRemove(slot.slot) }, modifier = Modifier.align(Alignment.TopEnd)) {
                            Icon(Icons.Default.Delete, "Remove", tint = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
internal fun GlobalSearchScreen(
    query: String,
    results: List<StreamItem>,
    onQuery: (String) -> Unit,
    onOpen: (StreamItem) -> Unit,
    onFavorite: (StreamItem) -> Unit,
    favoriteKeys: Set<String>,
    modifier: Modifier = Modifier,
) {
    Column(modifier.fillMaxSize().padding(12.dp)) {
        FeatureHeader("Search everything", "Live channels, movies, and series")
        OutlinedTextField(
            value = query,
            onValueChange = onQuery,
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Search all playlists") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            singleLine = true,
        )
        Spacer(Modifier.height(10.dp))
        if (query.trim().length < 2) {
            EmptyFeatureState("Type at least two characters", "Search", {}, Modifier.weight(1f))
        } else if (results.isEmpty()) {
            EmptyFeatureState("No matches", "Clear", { onQuery("") }, Modifier.weight(1f))
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(150.dp),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(vertical = 8.dp),
            ) {
                gridItems(results, key = { "${it.kind}:${it.id}" }) { item ->
                    SearchResultCard(item, favoriteKeys.contains(item.localLibraryKeyCompat()), { onFavorite(item) }, { onOpen(item) })
                }
            }
        }
    }
}

@Composable
private fun SearchResultCard(item: StreamItem, favorite: Boolean, onFavorite: () -> Unit, onOpen: () -> Unit) {
    Card(onClick = onOpen, modifier = Modifier.padding(5.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF181818))) {
        Box(Modifier.fillMaxWidth().aspectRatio(if (item.kind == ContentKind.LIVE) 16f / 9f else 2f / 3f).background(Color(0xFF202020))) {
            AsyncImage(item.imageUrl, null, Modifier.fillMaxSize(), contentScale = if (item.kind == ContentKind.LIVE) ContentScale.Fit else ContentScale.Crop)
            IconButton(onClick = onFavorite, Modifier.align(Alignment.TopEnd)) { Icon(Icons.Default.Favorite, null, tint = if (favorite) MaterialTheme.colorScheme.primary else Color.White) }
        }
        Text(item.name, Modifier.padding(8.dp), maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
    }
}

@Composable
internal fun PlaylistsScreen(
    playlists: List<PlaylistAccount>,
    activeId: String?,
    onSave: (PlaylistAccount, Boolean) -> Unit,
    onActivate: (String) -> Unit,
    onRemove: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    var editing by remember { mutableStateOf<PlaylistAccount?>(null) }
    var creating by remember { mutableStateOf(false) }
    Column(modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { FeatureHeader("Playlists", "Unlimited Xtream accounts and providers") }
            Button(onClick = { creating = true }) { Icon(Icons.Default.Add, null); Text("Add") }
        }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(playlists, key = PlaylistAccount::id) { account ->
                Card(colors = CardDefaults.cardColors(containerColor = if (account.id == activeId) Color(0xFF2A2415) else Color(0xFF181818))) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.PlaylistPlay, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(account.name, fontWeight = FontWeight.Bold)
                            Text(account.baseUrl, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(account.username, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (account.id != activeId) TextButton(onClick = { onActivate(account.id) }) { Text("Use") }
                        IconButton(onClick = { editing = account }) { Icon(Icons.Default.Edit, "Edit") }
                        IconButton(onClick = { onRemove(account.id) }) { Icon(Icons.Default.Delete, "Delete") }
                    }
                }
            }
        }
    }
    if (creating || editing != null) {
        PlaylistEditorDialog(
            account = editing,
            onDismiss = { creating = false; editing = null },
            onSave = { account, activate -> creating = false; editing = null; onSave(account, activate) },
        )
    }
}

@Composable
private fun PlaylistEditorDialog(account: PlaylistAccount?, onDismiss: () -> Unit, onSave: (PlaylistAccount, Boolean) -> Unit) {
    var name by remember(account?.id) { mutableStateOf(account?.name.orEmpty()) }
    var server by remember(account?.id) { mutableStateOf(account?.baseUrl ?: "http://pro.b33r.top") }
    var username by remember(account?.id) { mutableStateOf(account?.username.orEmpty()) }
    var password by remember(account?.id) { mutableStateOf(account?.password.orEmpty()) }
    var activate by remember { mutableStateOf(account == null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (account == null) "Add playlist" else "Edit playlist") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true)
                OutlinedTextField(server, { server = it }, label = { Text("Server URL") }, singleLine = true)
                OutlinedTextField(username, { username = it }, label = { Text("Username") }, singleLine = true)
                OutlinedTextField(password, { password = it }, label = { Text("Password") }, singleLine = true)
                Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(activate, { activate = it }); Text("Activate after saving") }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        PlaylistAccount(
                            id = account?.id ?: UUID.randomUUID().toString(),
                            name = name.ifBlank { username },
                            baseUrl = server,
                            username = username,
                            password = password,
                            enabled = account?.enabled ?: true,
                        ),
                        activate,
                    )
                },
                enabled = server.isNotBlank() && username.isNotBlank() && password.isNotBlank(),
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
internal fun ProfilesScreen(
    profiles: List<UserProfile>,
    activeId: String,
    onCreate: (String, String?, Boolean) -> Unit,
    onActivate: (String, String) -> Boolean,
    onDelete: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    var createDialog by remember { mutableStateOf(false) }
    var unlockProfile by remember { mutableStateOf<UserProfile?>(null) }
    Column(modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { FeatureHeader("Profiles", "Separate restrictions and viewing spaces") }
            Button(onClick = { createDialog = true }) { Icon(Icons.Default.Add, null); Text("New") }
        }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(profiles, key = UserProfile::id) { profile ->
                Card(
                    onClick = {
                        if (profile.pinHash == null) onActivate(profile.id, "") else unlockProfile = profile
                    },
                    colors = CardDefaults.cardColors(containerColor = if (profile.id == activeId) Color(0xFF2A2415) else Color(0xFF181818)),
                ) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (profile.pinHash != null) Icons.Default.Lock else Icons.Default.Person, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(profile.name, fontWeight = FontWeight.Bold)
                            Text(if (profile.kidsMode) "Kids mode" else "Standard profile", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (profile.id == activeId) Icon(Icons.Default.Check, "Active", tint = Color.Green)
                        if (profile.id != "default") IconButton(onClick = { onDelete(profile.id) }) { Icon(Icons.Default.Delete, "Delete") }
                    }
                }
            }
        }
    }
    if (createDialog) ProfileCreateDialog({ createDialog = false }, { name, pin, kids -> createDialog = false; onCreate(name, pin, kids) })
    unlockProfile?.let { profile -> PinDialog(profile.name, { unlockProfile = null }) { pin -> if (onActivate(profile.id, pin)) unlockProfile = null } }
}

@Composable
private fun ProfileCreateDialog(onDismiss: () -> Unit, onCreate: (String, String?, Boolean) -> Unit) {
    var name by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var kids by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create profile") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("Profile name") }, singleLine = true)
            OutlinedTextField(pin, { pin = it.filter(Char::isDigit).take(6) }, label = { Text("Optional PIN") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true)
            Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(kids, { kids = it }); Text("Kids mode") }
        } },
        confirmButton = { Button(onClick = { onCreate(name, pin.ifBlank { null }, kids) }, enabled = name.isNotBlank()) { Text("Create") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun PinDialog(name: String, onDismiss: () -> Unit, onSubmit: (String) -> Unit) {
    var pin by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Unlock $name") },
        text = { OutlinedTextField(pin, { pin = it.filter(Char::isDigit).take(6) }, label = { Text("PIN") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true) },
        confirmButton = { Button(onClick = { onSubmit(pin) }) { Text("Unlock") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
internal fun SettingsScreen(
    preferences: B33rPreferences,
    onUpdate: (B33rPreferences) -> Unit,
    onExport: (Boolean) -> String,
    onImport: (String) -> Boolean,
    onCheckForUpdates: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    var includeCredentials by remember { mutableStateOf(false) }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } }
                .getOrNull()?.let(onImport)
        }
    }
    fun shareBackup() {
        val file = File(context.cacheDir, "B33R-IPTV-backup.json")
        file.writeText(onExport(includeCredentials))
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.updates", file)
        context.startActivity(
            Intent.createChooser(
                Intent(Intent.ACTION_SEND).apply {
                    type = "application/json"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                },
                "Share B33R backup",
            ),
        )
    }
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { FeatureHeader("Settings", "Playback, guide, recording, and appearance") }
        item { SettingsSection("Playback") {
            SettingSlider("Buffer", "${preferences.playback.bufferSeconds} seconds", preferences.playback.bufferSeconds.toFloat(), 3f..120f) {
                onUpdate(preferences.copy(playback = preferences.playback.copy(bufferSeconds = it.toInt())))
            }
            SettingSlider("Timeshift", if (preferences.playback.timeshiftMinutes == 0) "Off" else "${preferences.playback.timeshiftMinutes} minutes", preferences.playback.timeshiftMinutes.toFloat(), 0f..180f) {
                onUpdate(preferences.copy(playback = preferences.playback.copy(timeshiftMinutes = it.toInt())))
            }
            SettingSwitch("Match display frame rate", preferences.playback.matchFrameRate) { onUpdate(preferences.copy(playback = preferences.playback.copy(matchFrameRate = it))) }
            SettingSwitch("Prefer hardware decoding", preferences.playback.preferHardwareDecoding) { onUpdate(preferences.copy(playback = preferences.playback.copy(preferHardwareDecoding = it))) }
            SettingSwitch("Audio passthrough", preferences.playback.passthroughAudio) { onUpdate(preferences.copy(playback = preferences.playback.copy(passthroughAudio = it))) }
            SettingSwitch("Use device audio/subtitle language", preferences.playback.preferDeviceLanguage) { onUpdate(preferences.copy(playback = preferences.playback.copy(preferDeviceLanguage = it))) }
            SettingSlider("Subtitle size", "${preferences.playback.subtitleScalePercent}%", preferences.playback.subtitleScalePercent.toFloat(), 50f..200f) { onUpdate(preferences.copy(playback = preferences.playback.copy(subtitleScalePercent = it.toInt()))) }
        } }
        item { SettingsSection("Guide and appearance") {
            Text("Guide density", fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                GuideDensity.entries.forEach { density -> FilterChip(preferences.appearance.guideDensity == density, { onUpdate(preferences.copy(appearance = preferences.appearance.copy(guideDensity = density))) }, { Text(density.name.lowercase().replaceFirstChar(Char::uppercase)) }) }
            }
            SettingSwitch("Channel numbers", preferences.appearance.showChannelNumbers) { onUpdate(preferences.copy(appearance = preferences.appearance.copy(showChannelNumbers = it))) }
            SettingSwitch("Channel logos", preferences.appearance.showChannelLogos) { onUpdate(preferences.copy(appearance = preferences.appearance.copy(showChannelLogos = it))) }
            SettingSwitch("Live guide preview", preferences.appearance.previewEnabled) { onUpdate(preferences.copy(appearance = preferences.appearance.copy(previewEnabled = it))) }
            SettingSwitch("24-hour clock", preferences.appearance.use24HourClock) { onUpdate(preferences.copy(appearance = preferences.appearance.copy(use24HourClock = it))) }
            SettingSwitch("Animations", preferences.appearance.animationsEnabled) { onUpdate(preferences.copy(appearance = preferences.appearance.copy(animationsEnabled = it))) }
        } }
        item { SettingsSection("Parental controls") {
            SettingSwitch("Automatically filter adult names", preferences.parental.adultNameFiltering) { onUpdate(preferences.copy(parental = preferences.parental.copy(adultNameFiltering = it))) }
            SettingSwitch("PIN for settings", preferences.parental.requirePinForSettings) { onUpdate(preferences.copy(parental = preferences.parental.copy(requirePinForSettings = it))) }
            SettingSwitch("PIN for locked content", preferences.parental.requirePinForLockedContent) { onUpdate(preferences.copy(parental = preferences.parental.copy(requirePinForLockedContent = it))) }
        } }
        item { SettingsSection("Recording") {
            SettingSlider("Start padding", "${preferences.recordingPaddingStartMinutes} min", preferences.recordingPaddingStartMinutes.toFloat(), 0f..30f) { onUpdate(preferences.copy(recordingPaddingStartMinutes = it.toInt())) }
            SettingSlider("End padding", "${preferences.recordingPaddingEndMinutes} min", preferences.recordingPaddingEndMinutes.toFloat(), 0f..60f) { onUpdate(preferences.copy(recordingPaddingEndMinutes = it.toInt())) }
        } }
        item { SettingsSection("Backup and maintenance") {
            Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(includeCredentials, { includeCredentials = it }); Text("Include encrypted-account credentials in exported JSON") }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = ::shareBackup) { Icon(Icons.Default.Backup, null); Text("Export") }
                OutlinedButton(onClick = { importLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) }) { Icon(Icons.Default.Restore, null); Text("Import") }
                OutlinedButton(onClick = onCheckForUpdates) { Icon(Icons.Default.Tune, null); Text("Updates") }
            }
        } }
    }
}

@Composable
private fun SettingsSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF181818))) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text(title, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            content()
        }
    }
}

@Composable
private fun SettingSwitch(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f))
        Switch(checked, onChange)
    }
}

@Composable
private fun SettingSlider(title: String, valueLabel: String, value: Float, range: ClosedFloatingPointRange<Float>, onValue: (Float) -> Unit) {
    Column {
        Row { Text(title, Modifier.weight(1f)); Text(valueLabel, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        Slider(value, onValue, valueRange = range)
    }
}

@Composable
private fun InlineMedia3Preview(url: String, muted: Boolean, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val player = remember(url) {
        ExoPlayer.Builder(context).build().apply {
            repeatMode = Player.REPEAT_MODE_ONE
            volume = if (muted) 0f else 1f
            setMediaItem(MediaItem.fromUri(url))
            prepare()
            playWhenReady = true
        }
    }
    LaunchedEffect(muted) { player.volume = if (muted) 0f else 1f }
    DisposableEffect(player) { onDispose { player.release() } }
    AndroidView(
        factory = {
            PlayerView(it).apply {
                useController = false
                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                this.player = player
            }
        },
        update = { it.player = player },
        modifier = modifier,
    )
}

@Composable
private fun FeatureHeader(title: String, subtitle: String) {
    Column {
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
    }
}

@Composable
private fun EmptyFeatureState(title: String, action: String, onAction: () -> Unit, modifier: Modifier = Modifier) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            if (action.isNotBlank()) OutlinedButton(onClick = onAction) { Text(action) }
        }
    }
}

private fun ProDestination.icon() = when (this) {
    ProDestination.GUIDE -> Icons.Default.LiveTv
    ProDestination.MOVIES -> Icons.Default.Movie
    ProDestination.SERIES -> Icons.Default.VideoLibrary
    ProDestination.FAVORITES -> Icons.Default.Favorite
    ProDestination.CONTINUE -> Icons.Default.History
    ProDestination.RECORDINGS -> Icons.Default.RadioButtonChecked
    ProDestination.MULTIVIEW -> Icons.Default.GridView
    ProDestination.SEARCH -> Icons.Default.Search
    ProDestination.PLAYLISTS -> Icons.Default.PlaylistPlay
    ProDestination.PROFILES -> Icons.Default.ManageAccounts
    ProDestination.SETTINGS -> Icons.Default.Settings
}

private fun ProDestination.shortTitle() = when (this) {
    ProDestination.CONTINUE -> "Continue"
    ProDestination.RECORDINGS -> "Record"
    ProDestination.MULTIVIEW -> "Multi"
    ProDestination.PLAYLISTS -> "Lists"
    ProDestination.PROFILES -> "Profiles"
    else -> title
}

private fun formatGuideTime(epochSeconds: Long, use24Hour: Boolean): String =
    SimpleDateFormat(if (use24Hour) "HH:mm" else "h:mm a", Locale.getDefault())
        .format(Date(epochSeconds * 1_000L))

private fun formatGuideDateTime(epochSeconds: Long): String =
    SimpleDateFormat("MMM d · h:mm a", Locale.getDefault()).format(Date(epochSeconds * 1_000L))

private fun StreamItem.localLibraryKeyCompat(): String = "${kind.name}:$id"

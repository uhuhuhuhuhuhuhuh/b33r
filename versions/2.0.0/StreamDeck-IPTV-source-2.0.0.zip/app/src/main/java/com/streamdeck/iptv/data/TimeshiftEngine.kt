package com.streamdeck.iptv.data

import android.content.Context
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request

/**
 * Small local rolling-HLS proxy for MPEG-TS live streams. It lets Media3 pause
 * and seek within a configurable buffer without exposing the provider URL to
 * another application. HLS/DASH sources continue using provider catch-up.
 */
class TimeshiftEngine(
    context: Context,
    private val upstreamUrl: String,
    bufferMinutes: Int,
) : AutoCloseable {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val running = AtomicBoolean(false)
    private val directory = File(context.cacheDir, "timeshift-${System.nanoTime()}").apply { mkdirs() }
    private val segments = CopyOnWriteArrayList<Segment>()
    private val maxSegments = (bufferMinutes.coerceIn(1, 180) * 15).coerceAtLeast(15)
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()
    private var server: ServerSocket? = null
    private var captureJob: Job? = null
    private var serverJob: Job? = null

    val playlistUrl: String
        get() = "http://127.0.0.1:${server?.localPort ?: 0}/index.m3u8"

    fun start(): String {
        if (running.compareAndSet(false, true)) {
            server = ServerSocket(0, 8, InetAddress.getByName("127.0.0.1"))
            captureJob = scope.launch { captureLoop() }
            serverJob = scope.launch { serveLoop() }
        }
        return playlistUrl
    }

    private suspend fun captureLoop() {
        while (scope.isActive && running.get()) {
            try {
                val request = Request.Builder()
                    .url(upstreamUrl)
                    .header("User-Agent", "B33R-IPTV/2.0")
                    .build()
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) error("Timeshift source returned ${response.code}")
                    val body = response.body ?: error("Timeshift source was empty")
                    BufferedInputStream(body.byteStream(), 256 * 1024).use { input ->
                        var sequence = segments.lastOrNull()?.sequence?.plus(1) ?: 0L
                        while (scope.isActive && running.get()) {
                            val file = File(directory, "segment-$sequence.ts")
                            val started = System.nanoTime()
                            var bytes = 0L
                            BufferedOutputStream(FileOutputStream(file), 256 * 1024).use { output ->
                                val buffer = ByteArray(TS_PACKET_SIZE * 512)
                                while (scope.isActive && running.get()) {
                                    val read = input.read(buffer)
                                    if (read < 0) break
                                    val aligned = read - (read % TS_PACKET_SIZE)
                                    if (aligned > 0) {
                                        output.write(buffer, 0, aligned)
                                        bytes += aligned
                                    }
                                    val elapsedMs = (System.nanoTime() - started) / 1_000_000L
                                    if (elapsedMs >= SEGMENT_DURATION_MS || bytes >= MAX_SEGMENT_BYTES) break
                                }
                                output.flush()
                            }
                            if (file.length() <= 0L) {
                                file.delete()
                                break
                            }
                            val duration = ((System.nanoTime() - started) / 1_000_000_000.0)
                                .coerceAtLeast(0.25)
                            segments += Segment(sequence, file, duration)
                            sequence++
                            trimOldSegments()
                        }
                    }
                }
            } catch (_: Exception) {
                delay(1_500L)
            }
        }
    }

    private fun trimOldSegments() {
        while (segments.size > maxSegments) {
            val removed = segments.removeAt(0)
            removed.file.delete()
        }
    }

    private suspend fun serveLoop() {
        val socket = server ?: return
        while (scope.isActive && running.get()) {
            val clientSocket = runCatching { socket.accept() }.getOrNull() ?: break
            scope.launch { handle(clientSocket) }
        }
    }

    private fun handle(socket: Socket) {
        socket.use { clientSocket ->
            clientSocket.soTimeout = 5_000
            val input = clientSocket.getInputStream().bufferedReader(Charsets.US_ASCII)
            val requestLine = input.readLine().orEmpty()
            while (true) {
                val line = input.readLine() ?: break
                if (line.isBlank()) break
            }
            val path = requestLine.split(' ').getOrNull(1).orEmpty().substringBefore('?')
            val output = BufferedOutputStream(clientSocket.getOutputStream())
            when {
                path == "/index.m3u8" -> writePlaylist(output)
                path.startsWith("/segment-") && path.endsWith(".ts") -> writeSegment(output, path.removePrefix("/"))
                else -> writeStatus(output, 404, "Not Found")
            }
            output.flush()
        }
    }

    private fun writePlaylist(output: BufferedOutputStream) {
        val snapshot = segments.toList()
        val firstSequence = snapshot.firstOrNull()?.sequence ?: 0L
        val targetDuration = snapshot.maxOfOrNull { kotlin.math.ceil(it.durationSeconds).toInt() }
            ?.coerceAtLeast(1) ?: 4
        val text = buildString {
            appendLine("#EXTM3U")
            appendLine("#EXT-X-VERSION:3")
            appendLine("#EXT-X-TARGETDURATION:$targetDuration")
            appendLine("#EXT-X-MEDIA-SEQUENCE:$firstSequence")
            appendLine("#EXT-X-PLAYLIST-TYPE:EVENT")
            snapshot.forEach { segment ->
                appendLine("#EXTINF:${"%.3f".format(java.util.Locale.US, segment.durationSeconds)},")
                appendLine(segment.file.name)
            }
        }.toByteArray(Charsets.UTF_8)
        writeHeaders(output, 200, "OK", "application/vnd.apple.mpegurl", text.size.toLong())
        output.write(text)
    }

    private fun writeSegment(output: BufferedOutputStream, name: String) {
        val file = segments.firstOrNull { it.file.name == name }?.file
        if (file == null || !file.exists()) {
            writeStatus(output, 404, "Not Found")
            return
        }
        writeHeaders(output, 200, "OK", "video/mp2t", file.length())
        FileInputStream(file).use { it.copyTo(output, 128 * 1024) }
    }

    private fun writeStatus(output: BufferedOutputStream, status: Int, reason: String) {
        val body = "$status $reason".toByteArray(Charsets.UTF_8)
        writeHeaders(output, status, reason, "text/plain", body.size.toLong())
        output.write(body)
    }

    private fun writeHeaders(
        output: BufferedOutputStream,
        status: Int,
        reason: String,
        contentType: String,
        length: Long,
    ) {
        val header = buildString {
            append("HTTP/1.1 $status $reason\r\n")
            append("Content-Type: $contentType\r\n")
            append("Content-Length: $length\r\n")
            append("Cache-Control: no-store\r\n")
            append("Access-Control-Allow-Origin: *\r\n")
            append("Connection: close\r\n\r\n")
        }
        output.write(header.toByteArray(Charsets.US_ASCII))
    }

    override fun close() {
        if (!running.compareAndSet(true, false)) return
        runCatching { server?.close() }
        captureJob?.cancel()
        serverJob?.cancel()
        scope.cancel()
        directory.deleteRecursively()
    }

    private data class Segment(
        val sequence: Long,
        val file: File,
        val durationSeconds: Double,
    )

    private companion object {
        const val TS_PACKET_SIZE = 188
        const val SEGMENT_DURATION_MS = 4_000L
        const val MAX_SEGMENT_BYTES = 8L * 1024L * 1024L
    }
}

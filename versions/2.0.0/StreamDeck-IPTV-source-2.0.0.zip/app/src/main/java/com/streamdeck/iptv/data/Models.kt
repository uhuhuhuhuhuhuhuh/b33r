package com.streamdeck.iptv.data

data class Credentials(
    val username: String,
    val password: String,
    val baseUrl: String = "http://pro.b33r.top",
)

data class AccountInfo(
    val username: String,
    val expiresAtEpochSeconds: Long?,
) {
    val expired: Boolean
        get() = expiresAtEpochSeconds?.let { it <= currentEpochSeconds() } == true
}

data class StoredSession(
    val sessionId: String,
    val credentials: Credentials,
    val accountUsername: String,
    val expiresAtEpochSeconds: Long?,
) {
    val expired: Boolean
        get() = expiresAtEpochSeconds?.let { it <= currentEpochSeconds() } == true
}

data class Category(
    val id: String,
    val name: String,
)

enum class ContentKind { LIVE, MOVIE, SERIES, EPISODE }

data class StreamItem(
    val id: String,
    val name: String,
    val kind: ContentKind,
    val extension: String = "",
    val subtitle: String = "",
    val imageUrl: String = "",
    val directUrl: String = "",
    val categoryId: String? = null,
    val channelNumber: Int? = null,
    val hasArchive: Boolean = false,
    val archiveDurationDays: Int = 0,
)

enum class LibrarySection(val title: String) {
    LIVE("Live TV"),
    MOVIES("Movies"),
    SERIES("Series"),
    FAVORITES("Favorites"),
    RESUME("Continue Watching"),
}

data class ResumeEntry(
    val item: StreamItem,
    val positionMs: Long,
    val durationMs: Long,
    val updatedAtEpochSeconds: Long,
)

fun StreamItem.localLibraryKey(): String = "${kind.name}:$id"

fun StreamItem.canBeFavorited(): Boolean =
    kind == ContentKind.LIVE || kind == ContentKind.MOVIE || kind == ContentKind.SERIES

fun StreamItem.canResume(): Boolean =
    kind == ContentKind.MOVIE || kind == ContentKind.EPISODE

open class XtreamException(message: String) : Exception(message)

class AccountExpiredException : XtreamException("Account expired.")

class XtreamNetworkException :
    XtreamException("Unable to connect. Check the device network and try again.")

fun currentEpochSeconds(): Long = System.currentTimeMillis() / 1_000L

internal fun shouldTreatAuthenticationFailureAsExpired(
    status: String,
    message: String,
    expiresAtEpochSeconds: Long?,
    nowEpochSeconds: Long = currentEpochSeconds(),
): Boolean =
    status.equals("Expired", ignoreCase = true) ||
        message.contains("expired", ignoreCase = true) ||
        expiresAtEpochSeconds?.let { it <= nowEpochSeconds } == true

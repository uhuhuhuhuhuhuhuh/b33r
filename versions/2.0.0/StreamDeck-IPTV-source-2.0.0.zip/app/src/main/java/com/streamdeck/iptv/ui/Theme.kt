package com.streamdeck.iptv.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color

@Composable
fun StreamDeckTheme(
    accentArgb: Long = 0xFFF2A900,
    content: @Composable () -> Unit,
) {
    val accent = Color(accentArgb.toULong())
    val colors = remember(accentArgb) {
        darkColorScheme(
            primary = accent,
            onPrimary = Color(0xFF101010),
            secondary = accent.copy(alpha = 0.78f),
            background = Color(0xFF080808),
            onBackground = Color(0xFFF5F5F5),
            surface = Color(0xFF151515),
            onSurface = Color(0xFFF5F5F5),
            surfaceVariant = Color(0xFF282828),
            onSurfaceVariant = Color(0xFFAAAAAA),
            outline = Color(0xFF3D3D3D),
            error = Color(0xFFFFB4AB),
        )
    }
    MaterialTheme(colorScheme = colors, content = content)
}
